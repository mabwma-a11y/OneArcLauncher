package com.onearc.launcher.data

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.Resources
import android.graphics.drawable.Drawable
import androidx.core.content.res.ResourcesCompat
import org.xmlpull.v1.XmlPullParser
import org.xmlpull.v1.XmlPullParserFactory
import java.io.InputStream

/**
 * Rileva tutti gli Icon Pack compatibili installati sul Galaxy (Play Store / ADW / Nova / Lawnchair)
 * e risolve le icone leggendo appfilter.xml.
 */
class IconPackManager(private val context: Context) {

    private var loadedPackPackage: String = ""
    private var packResources: Resources? = null
    private val componentMap = mutableMapOf<String, String>()
    private val packageFallbackMap = mutableMapOf<String, String>()

    fun getInstalledIconPacks(): List<IconPackInfo> {
        val pm = context.packageManager
        val actions = listOf(
            "org.adw.launcher.THEMES",
            "com.novalauncher.THEME",
            "com.teslacoilsw.launcher.THEME",
            "com.anddoes.launcher.THEME",
            "com.gau.go.launcherex.theme"
        )
        val seen = linkedMapOf<String, IconPackInfo>()

        for (action in actions) {
            val intent = Intent(action)
            val resolved = runCatching {
                pm.queryIntentActivities(intent, PackageManager.GET_META_DATA)
            }.getOrDefault(emptyList())

            for (ri in resolved) {
                val pkg = ri.activityInfo?.packageName ?: continue
                if (pkg == context.packageName || seen.containsKey(pkg)) continue
                val label = ri.loadLabel(pm)?.toString() ?: pkg
                seen[pkg] = IconPackInfo(packageName = pkg, label = label)
            }
        }
        return seen.values.sortedBy { it.label.lowercase() }
    }

    fun loadPack(packPackage: String) {
        if (packPackage == loadedPackPackage) return
        loadedPackPackage = packPackage
        componentMap.clear()
        packageFallbackMap.clear()
        packResources = null

        if (packPackage.isBlank()) return

        val res = runCatching {
            context.packageManager.getResourcesForApplication(packPackage)
        }.getOrNull() ?: return

        packResources = res

        // 1. Prova res/xml/appfilter.xml
        val xmlId = res.getIdentifier("appfilter", "xml", packPackage)
        if (xmlId != 0) {
            runCatching {
                res.getXml(xmlId).use { parser -> parseAppFilter(parser) }
            }
        }

        // 2. Fallback: assets/appfilter.xml
        if (componentMap.isEmpty()) {
            runCatching {
                val stream: InputStream = res.assets.open("appfilter.xml")
                stream.use { input ->
                    val factory = XmlPullParserFactory.newInstance()
                    val parser = factory.newPullParser()
                    parser.setInput(input, "UTF-8")
                    parseAppFilter(parser)
                }
            }
        }
    }

    fun getIconDrawable(componentName: ComponentName): Drawable? {
        val res = packResources ?: return null
        val pkg = loadedPackPackage
        if (pkg.isBlank()) return null

        val fullKey = "ComponentInfo{${componentName.packageName}/${componentName.className}}"
        val shortKey = "ComponentInfo{${componentName.flattenToShortString()}}"
        val drawableName = componentMap[fullKey]
            ?: componentMap[shortKey]
            ?: packageFallbackMap[componentName.packageName]
            ?: return null

        val drawableId = res.getIdentifier(drawableName, "drawable", pkg)
        if (drawableId == 0) return null
        return runCatching {
            ResourcesCompat.getDrawable(res, drawableId, null)
        }.getOrNull()
    }

    private fun parseAppFilter(parser: XmlPullParser) {
        var eventType = parser.eventType
        while (eventType != XmlPullParser.END_DOCUMENT) {
            if (eventType == XmlPullParser.START_TAG && parser.name == "item") {
                val comp = parser.getAttributeValue(null, "component")
                val drawable = parser.getAttributeValue(null, "drawable")
                if (!comp.isNullOrBlank() && !drawable.isNullOrBlank()) {
                    componentMap[comp] = drawable
                    val inside = comp.removePrefix("ComponentInfo{").removeSuffix("}")
                    val pkg = inside.substringBefore("/", "")
                    if (pkg.isNotBlank() && !packageFallbackMap.containsKey(pkg)) {
                        packageFallbackMap[pkg] = drawable
                    }
                }
            }
            eventType = parser.next()
        }
    }
}
