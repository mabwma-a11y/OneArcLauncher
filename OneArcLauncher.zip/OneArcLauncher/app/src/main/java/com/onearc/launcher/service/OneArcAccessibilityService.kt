package com.onearc.launcher.service

import android.accessibilityservice.AccessibilityService
import android.content.ComponentName
import android.content.Context
import android.provider.Settings
import android.view.accessibility.AccessibilityEvent
import java.lang.ref.WeakReference

/**
 * Servizio di accessibilita opzionale:
 * - Swipe verso il basso nella zona pollice -> apre la tendina notifiche Samsung
 * - Doppio tap sullo sfondo -> blocca lo schermo senza premere il tasto fisico
 */
class OneArcAccessibilityService : AccessibilityService() {

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = WeakReference(this)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Non legge ne elabora alcun contenuto dello schermo
    }

    override fun onInterrupt() = Unit

    override fun onDestroy() {
        super.onDestroy()
        if (instance?.get() == this) {
            instance = null
        }
    }

    companion object {
        private var instance: WeakReference<OneArcAccessibilityService>? = null

        fun isEnabled(context: Context): Boolean {
            val enabledServices = Settings.Secure.getString(
                context.contentResolver,
                Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
            ) ?: return false
            val expected = ComponentName(context, OneArcAccessibilityService::class.java)
            return enabledServices.contains(expected.flattenToString()) ||
                enabledServices.contains(expected.flattenToShortString())
        }

        fun expandNotificationShade(): Boolean {
            return instance?.get()?.performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS) ?: false
        }

        fun lockScreen(): Boolean {
            return instance?.get()?.performGlobalAction(GLOBAL_ACTION_LOCK_SCREEN) ?: false
        }
    }
}
