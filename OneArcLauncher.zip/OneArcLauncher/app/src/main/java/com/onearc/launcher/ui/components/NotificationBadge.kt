package com.onearc.launcher.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.onearc.launcher.data.BadgeStyle
import com.onearc.launcher.ui.theme.ExpressiveMotion
import com.onearc.launcher.ui.theme.ExpressiveShapes
import com.onearc.launcher.ui.theme.LocalLedPalette

@Composable
fun NotificationCounterBadge(
    count: Int,
    style: BadgeStyle,
    useLedColor: Boolean,
    modifier: Modifier = Modifier
) {
    val led = LocalLedPalette.current
    val show = count > 0 && style != BadgeStyle.HIDDEN

    AnimatedVisibility(
        visible = show,
        modifier = modifier,
        enter = scaleIn(animationSpec = ExpressiveMotion.spatialFast()) + fadeIn(),
        exit = scaleOut(animationSpec = ExpressiveMotion.spatialFast()) + fadeOut()
    ) {
        val accent = if (useLedColor) led.primary else Color(0xFFFF4D6D)

        if (style == BadgeStyle.LED_DOT) {
            Box(
                modifier = Modifier
                    .size(12.dp)
                    .clip(CircleShape)
                    .background(accent)
                    .border(1.5.dp, Color(0xFF05070D), CircleShape)
            )
        } else {
            val label = if (count > 99) "99+" else count.toString()
            Box(
                modifier = Modifier
                    .defaultMinSize(minWidth = 22.dp, minHeight = 22.dp)
                    .clip(ExpressiveShapes.BadgePill)
                    .background(Color(0xFF060911).copy(alpha = 0.92f))
                    .border(1.4.dp, accent, ExpressiveShapes.BadgePill)
                    .padding(horizontal = 6.dp, vertical = 2.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = label,
                    style = MaterialTheme.typography.labelSmall,
                    color = accent,
                    maxLines = 1
                )
            }
        }
    }
}
