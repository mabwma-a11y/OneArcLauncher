package com.onearc.launcher.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import com.onearc.launcher.ui.theme.ExpressiveMotion
import com.onearc.launcher.ui.theme.ExpressiveShapes

/**
 * Contatore notifiche Material 3 Expressive con animazione elastica
 * e colori dinamici adattati allo sfondo del Galaxy.
 */
@Composable
fun NotificationCounterBadge(
    count: Int,
    modifier: Modifier = Modifier
) {
    AnimatedVisibility(
        visible = count > 0,
        modifier = modifier,
        enter = scaleIn(animationSpec = ExpressiveMotion.spatialFast()) + fadeIn(),
        exit = scaleOut(animationSpec = ExpressiveMotion.spatialFast()) + fadeOut()
    ) {
        val label = if (count > 99) "99+" else count.toString()
        Box(
            modifier = Modifier
                .defaultMinSize(minWidth = 22.dp, minHeight = 22.dp)
                .clip(ExpressiveShapes.BadgePill)
                .background(MaterialTheme.colorScheme.errorContainer)
                .border(
                    width = 1.5.dp,
                    color = MaterialTheme.colorScheme.surface,
                    shape = ExpressiveShapes.BadgePill
                )
                .padding(horizontal = 6.dp, vertical = 2.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onErrorContainer,
                maxLines = 1
            )
        }
    }
}
