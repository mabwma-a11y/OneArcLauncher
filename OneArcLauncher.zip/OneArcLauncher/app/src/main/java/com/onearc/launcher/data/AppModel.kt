package com.onearc.launcher.data

import android.content.ComponentName
import android.content.pm.ShortcutInfo
import android.os.UserHandle
import androidx.compose.runtime.Immutable
import androidx.compose.ui.graphics.ImageBitmap

enum class LauncherMode {
    NORMAL,
    WORK
}

enum class Handedness {
    RIGHT,
    LEFT
}

@Immutable
data class AppEntry(
    val packageName: String,
    val activityName: String,
    val label: String,
    val componentName: ComponentName,
    val userHandle: UserHandle,
    val icon: ImageBitmap?
) {
    val id: String get() = "$packageName/$activityName"
    val sectionLetter: Char
        get() {
            val first = label.trim().firstOrNull()?.uppercaseChar() ?: '#'
            return if (first in 'A'..'Z') first else '#'
        }
}

@Immutable
data class AppShortcutItem(
    val id: String,
    val label: String,
    val shortcutInfo: ShortcutInfo
)

data class LauncherPrefs(
    val handedness: Handedness = Handedness.RIGHT,
    val arcPackagesNormal: List<String> = emptyList(),
    val arcPackagesWork: List<String> = emptyList(),
    val hiddenPackages: Set<String> = emptySet(),
    val monochromeIcons: Boolean = false,
    val doubleTapToLock: Boolean = true,
    val autoFocusSearch: Boolean = false,
    val amoledWorkBackground: Boolean = true,
    val privacyFallbackDimmer: Boolean = true,
    val privacySettingKey: String = "privacy_display_mode"
)
