package com.onearc.launcher.data

import android.content.ComponentName
import android.content.pm.ShortcutInfo
import android.os.UserHandle
import androidx.compose.runtime.Immutable
import androidx.compose.ui.graphics.ImageBitmap

enum class LauncherMode { NORMAL, WORK }

enum class Handedness { RIGHT, LEFT }

enum class IconShapeStyle(val displayName: String) {
    SQUIRCLE("Squircle"),
    CIRCLE("Cerchio"),
    ROUNDED("Arrotondato"),
    TEARDROP("Goccia"),
    HEXAGON("Esagono"),
    OCTAGON("Ottagono"),
    DIAMOND("Diamante"),
    NONE("Libera")
}

enum class IconColorMode(val displayName: String) {
    ORIGINAL("Originale"),
    MONOCHROME("Mono"),
    WALLPAPER_TINT("Tinta LED"),
    NEON_DUOTONE("Neon Duo")
}

enum class IconContainerStyle(val displayName: String) {
    DARK_GLASS_LED("Vetro + LED"),
    DARK_GLASS("Solo Vetro"),
    LED_OUTLINE_ONLY("Solo Bordo LED"),
    TRANSPARENT("Nessuno")
}

enum class LedAnimationMode(val displayName: String) {
    FLOW("Flusso"),
    PULSE("Respiro"),
    STATIC("Statico")
}

enum class BadgeStyle(val displayName: String) {
    COUNT("Numero"),
    LED_DOT("Punto LED"),
    HIDDEN("Nascosto")
}

enum class CustomIconType {
    DEFAULT,
    GALLERY_IMAGE,
    MINIMAL_GLYPH
}

@Immutable
data class AppCustomization(
    val customLabel: String? = null,
    val iconType: CustomIconType = CustomIconType.DEFAULT,
    val iconValue: String? = null, // Percorso file PNG per GALLERY_IMAGE o chiave per MINIMAL_GLYPH
    val customLedColorArgb: Long? = null // null = segue i colori dello sfondo
)

@Immutable
data class IconPackInfo(
    val packageName: String,
    val label: String
)

@Immutable
data class AppEntry(
    val packageName: String,
    val activityName: String,
    val label: String,
    val componentName: ComponentName,
    val userHandle: UserHandle,
    val icon: ImageBitmap?,
    val customGlyphKey: String? = null,
    val customLedColorArgb: Long? = null
) {
    val id: String get() = "$packageName/$activityName"
    val sectionLetter: Char
        get() {
            val first = label.trim().firstOrNull()?.uppercaseChar() ?: '#'
            return if (first in 'A'..'Z') first else '#'
        }
}

@Immutable
data class AppShortcutItem(
    val id: String,
    val label: String,
    val shortcutInfo: ShortcutInfo
)

@Immutable
data class LauncherPrefs(
    // Ergonomia e layout
    val handedness: Handedness = Handedness.RIGHT,
    val arcPackagesNormal: List<String> = emptyList(),
    val arcPackagesWork: List<String> = emptyList(),
    val hiddenPackages: Set<String> = emptySet(),
    val arcIconCount: Int = 5, // 4..7
    val arcCurvatureDp: Float = 22f, // 0..36

    // Grafica Vetro Scuro & LED
    val ledAnimationMode: LedAnimationMode = LedAnimationMode.FLOW,
    val ledGlowIntensity: Float = 0.85f, // 0f..1.4f
    val ledBorderWidthDp: Float = 1.8f, // 0.8..3.5
    val darkGlassOpacity: Float = 0.62f, // 0.25..0.92
    val perIconLedEnabled: Boolean = true,

    // Personalizzazione totale icone
    val selectedIconPackPackage: String = "", // "" = icone di sistema
    val iconShape: IconShapeStyle = IconShapeStyle.SQUIRCLE,
    val iconContainerStyle: IconContainerStyle = IconContainerStyle.DARK_GLASS_LED,
    val iconColorMode: IconColorMode = IconColorMode.ORIGINAL,
    val iconSizeDp: Float = 54f, // 40..68
    val iconInnerScale: Float = 0.72f, // 0.50..1.05
    val iconSaturation: Float = 1.0f, // 0f..1.5f
    val iconOpacity: Float = 1.0f, // 0.45..1.0f
    val showArcLabels: Boolean = true,
    val showDrawerLabels: Boolean = true,
    val labelTextSizeSp: Float = 11f, // 9..15

    // Badge notifiche
    val badgeStyle: BadgeStyle = BadgeStyle.COUNT,
    val badgeUseLedColor: Boolean = true,

    // Personalizzazioni per singola app
    val appCustomizations: Map<String, AppCustomization> = emptyMap(),

    // Gesture, Lavoro & Sistema
    val doubleTapToLock: Boolean = true,
    val autoFocusSearch: Boolean = false,
    val amoledWorkBackground: Boolean = true,
    val privacyFallbackDimmer: Boolean = true,
    val privacySettingKey: String = "privacy_display_mode",
    val askDefaultLauncherOnStart: Boolean = true
)
