package com.onearc.launcher.ui.components

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Image
import androidx.compose.material.icons.rounded.Restore
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.onearc.launcher.data.AppCustomization
import com.onearc.launcher.data.AppEntry
import com.onearc.launcher.data.CustomIconType
import com.onearc.launcher.data.LauncherPrefs
import com.onearc.launcher.ui.theme.ExpressiveShapes
import com.onearc.launcher.ui.theme.LocalLedPalette

private val PresetLedColors: List<Pair<String, Long?>> = listOf(
    "Sfondo" to null,
    "Ciano" to 0xFF00E5FF,
    "Menta" to 0xFF00FFA3,
    "Viola" to 0xFFBB86FC,
    "Magenta" to 0xFFFF2E93,
    "Arancio" to 0xFFFF8A00,
    "Oro" to 0xFFFFD60A,
    "Bianco" to 0xFFFFFFFF
)

/**
 * Editor completo per personalizzare una SINGOLA app:
 * - Rinomina etichetta
 * - Scegli immagine dalla Galleria del telefono
 * - Scegli un glifo minimal integrato
 * - Scegli colore LED dedicato o sincronizzato allo sfondo
 * - Ripristina default
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun IconCustomizeSheet(
    app: AppEntry,
    prefs: LauncherPrefs,
    existing: AppCustomization?,
    onSave: (AppCustomization?) -> Unit,
    onPickGalleryImage: (Uri) -> Unit,
    onDismiss: () -> Unit
) {
    val led = LocalLedPalette.current
    var labelText by remember(app.packageName) { mutableStateOf(existing?.customLabel ?: app.label) }
    var selectedType by remember(app.packageName, existing) {
        mutableStateOf(existing?.iconType ?: CustomIconType.DEFAULT)
    }
    var selectedValue by remember(app.packageName, existing) {
        mutableStateOf(existing?.iconValue)
    }
    var selectedLedArgb by remember(app.packageName, existing) {
        mutableStateOf(existing?.customLedColorArgb)
    }

    val imagePicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri ->
        if (uri != null) {
            onPickGalleryImage(uri)
        }
    }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        shape = ExpressiveShapes.SheetTop,
        containerColor = Color(0xFF0A0E17)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 22.dp, vertical = 10.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text(
                text = "Personalizza App",
                style = MaterialTheme.typography.headlineMedium,
                color = Color.White
            )

            // Anteprima live con bordo LED
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .ledGlassSurface(
                        shape = ExpressiveShapes.CardExpressive,
                        glassOpacity = prefs.darkGlassOpacity,
                        borderWidth = prefs.ledBorderWidthDp.dp,
                        glowIntensity = prefs.ledGlowIntensity,
                        animationMode = prefs.ledAnimationMode
                    )
                    .padding(vertical = 20.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    OneArcIconVisual(
                        label = labelText.ifBlank { app.label },
                        iconBitmap = if (selectedType == CustomIconType.MINIMAL_GLYPH) null else app.icon,
                        customGlyphKey = if (selectedType == CustomIconType.MINIMAL_GLYPH) selectedValue else null,
                        customLedColorArgb = selectedLedArgb,
                        prefs = prefs,
                        sizeOverride = 68.dp
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = labelText.ifBlank { app.label },
                        style = MaterialTheme.typography.titleMedium,
                        color = Color.White
                    )
                }
            }

            // Rinomina app
            OutlinedTextField(
                value = labelText,
                onValueChange = { labelText = it },
                label = { Text("Nome visualizzato") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )

            // Sorgente icona: Galleria o Default
            Text(
                text = "Immagine personalizzata",
                style = MaterialTheme.typography.labelLarge,
                color = led.primary
            )
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                FilledTonalButton(
                    onClick = { imagePicker.launch("image/*") },
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Rounded.Image, contentDescription = null)
                    Spacer(modifier = Modifier.size(6.dp))
                    Text("Da Galleria")
                }
                FilledTonalButton(
                    onClick = {
                        selectedType = CustomIconType.DEFAULT
                        selectedValue = null
                    },
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Rounded.Restore, contentDescription = null)
                    Spacer(modifier = Modifier.size(6.dp))
                    Text("Icona App")
                }
            }

            // Glifi minimal integrati
            Text(
                text = "Icone minimali LED integrate",
                style = MaterialTheme.typography.labelLarge,
                color = led.primary
            )
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                contentPadding = PaddingValues(vertical = 4.dp)
            ) {
                items(MinimalGlyphRegistry.glyphs) { (key, vector) ->
                    val isSelected = selectedType == CustomIconType.MINIMAL_GLYPH && selectedValue == key
                    Box(
                        modifier = Modifier
                            .size(52.dp)
                            .clip(CircleShape)
                            .background(if (isSelected) led.primary.copy(alpha = 0.24f) else Color.White.copy(alpha = 0.06f))
                            .border(
                                width = if (isSelected) 1.8.dp else 1.dp,
                                color = if (isSelected) led.primary else Color.White.copy(alpha = 0.16f),
                                shape = CircleShape
                            )
                            .clickable {
                                selectedType = CustomIconType.MINIMAL_GLYPH
                                selectedValue = key
                            },
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = vector,
                            contentDescription = key,
                            tint = if (isSelected) led.primary else Color.White
                        )
                    }
                }
            }

            // Colore LED dedicato
            Text(
                text = "Colore bordo LED per questa icona",
                style = MaterialTheme.typography.labelLarge,
                color = led.primary
            )
            LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                items(PresetLedColors) { (name, argb) ->
                    val isSelected = selectedLedArgb == argb
                    val swatch = argb?.let { Color(it.toInt()) } ?: led.primary
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.clickable { selectedLedArgb = argb }
                    ) {
                        Box(
                            modifier = Modifier
                                .size(38.dp)
                                .clip(CircleShape)
                                .background(swatch)
                                .border(
                                    width = if (isSelected) 3.dp else 1.dp,
                                    color = if (isSelected) Color.White else Color.White.copy(alpha = 0.3f),
                                    shape = CircleShape
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            if (argb == null) {
                                Icon(
                                    imageVector = Icons.Rounded.AutoAwesome,
                                    contentDescription = null,
                                    tint = Color(0xFF041018),
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = name,
                            style = MaterialTheme.typography.labelSmall,
                            color = if (isSelected) Color.White else Color.White.copy(alpha = 0.6f)
                        )
                    }
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                TextButton(
                    onClick = {
                        onSave(null)
                        onDismiss()
                    }
                ) {
                    Text("Ripristina", color = Color(0xFFFF6B6B))
                }

                Button(
                    onClick = {
                        val trimmed = labelText.trim().takeIf { it.isNotEmpty() && it != app.label }
                        onSave(
                            AppCustomization(
                                customLabel = trimmed,
                                iconType = selectedType,
                                iconValue = selectedValue,
                                customLedColorArgb = selectedLedArgb
                            )
                        )
                        onDismiss()
                    },
                    shape = ExpressiveShapes.Pill,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = led.primary,
                        contentColor = Color(0xFF041018)
                    )
                ) {
                    Text("Salva modifiche")
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}
