package com.onearc.launcher.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.GenericShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Bolt
import androidx.compose.material.icons.rounded.CalendarToday
import androidx.compose.material.icons.rounded.CameraAlt
import androidx.compose.material.icons.rounded.Chat
import androidx.compose.material.icons.rounded.DirectionsCar
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.Email
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Image
import androidx.compose.material.icons.rounded.Language
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.Notifications
import androidx.compose.material.icons.rounded.Phone
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.Shield
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material.icons.rounded.Work
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.drawOutline
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.onearc.launcher.data.IconShapeStyle
import com.onearc.launcher.data.LedAnimationMode
import com.onearc.launcher.system.LedPalette
import com.onearc.launcher.ui.theme.LocalLedPalette
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/**
 * Restituisce la forma geometrica corrispondente allo stile icona scelto dall'utente.
 */
fun resolveIconShape(style: IconShapeStyle): Shape = when (style) {
    IconShapeStyle.SQUIRCLE -> RoundedCornerShape(percent = 32)
    IconShapeStyle.CIRCLE -> CircleShape
    IconShapeStyle.ROUNDED -> RoundedCornerShape(percent = 20)
    IconShapeStyle.TEARDROP -> RoundedCornerShape(
        topStartPercent = 50,
        topEndPercent = 50,
        bottomEndPercent = 14,
        bottomStartPercent = 50
    )
    IconShapeStyle.HEXAGON -> polygonShape(sides = 6, rotationDeg = -90f)
    IconShapeStyle.OCTAGON -> polygonShape(sides = 8, rotationDeg = -22.5f)
    IconShapeStyle.DIAMOND -> RoundedCornerShape(
        topStartPercent = 48,
        topEndPercent = 16,
        bottomEndPercent = 48,
        bottomStartPercent = 16
    )
    IconShapeStyle.NONE -> RoundedCornerShape(0.dp)
}

private fun polygonShape(sides: Int, rotationDeg: Float): Shape = GenericShape { size, _ ->
    val cx = size.width / 2f
    val cy = size.height / 2f
    val r = minOf(cx, cy) * 0.96f
    val path = Path()
    for (i in 0 until sides) {
        val angle = Math.toRadians((rotationDeg + i * (360.0 / sides)))
        val px = cx + (r * cos(angle)).toFloat()
        val py = cy + (r * sin(angle)).toFloat()
        if (i == 0) path.moveTo(px, py) else path.lineTo(px, py)
    }
    path.close()
    addPath(path)
}

/**
 * Modifier centrale dello stile LED + Vetro Scuro Trasparente di OneArc:
 * - Disegna un pannello scuro traslucido (dark smoked glass)
 * - Applica un alone esterno morbido a piu livelli (glow GPU-friendly a 120Hz)
 * - Disegna un filamento LED nitido che segue i colori reali estratti dallo sfondo Galaxy
 * - Supporta 3 modalita: Flusso rotante (FLOW), Respiro (PULSE), Statico (STATIC).
 */
@Composable
fun Modifier.ledGlassSurface(
    shape: Shape,
    glassOpacity: Float = 0.62f,
    borderWidth: Dp = 1.8.dp,
    glowIntensity: Float = 0.85f,
    animationMode: LedAnimationMode = LedAnimationMode.FLOW,
    drawBackground: Boolean = true,
    drawLedBorder: Boolean = true,
    overrideAccentColor: Color? = null,
    palette: LedPalette = LocalLedPalette.current
): Modifier {
    val ledColors = if (overrideAccentColor != null) {
        listOf(
            overrideAccentColor,
            overrideAccentColor.copy(alpha = 0.72f),
            Color.White.copy(alpha = 0.9f),
            overrideAccentColor
        )
    } else {
        listOf(palette.primary, palette.secondary, palette.tertiary, palette.primary)
    }

    val infiniteTransition = rememberInfiniteTransition(label = "ledAnim")

    val flowAngleDeg by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 5200, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "ledFlowAngle"
    )

    val pulseFactor by infiniteTransition.animateFloat(
        initialValue = 0.55f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 2200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "ledPulse"
    )

    val activeAngle = if (animationMode == LedAnimationMode.FLOW) flowAngleDeg else 35f
    val activeGlow = when (animationMode) {
        LedAnimationMode.PULSE -> glowIntensity * pulseFactor
        else -> glowIntensity
    }

    return this.drawBehind {
        val outline = shape.createOutline(size, layoutDirection, this)
        val w = size.width
        val h = size.height
        val rad = (activeAngle * PI / 180.0)
        val dx = (cos(rad) * w * 0.65f).toFloat()
        val dy = (sin(rad) * h * 0.65f).toFloat()
        val start = Offset(w / 2f - dx, h / 2f - dy)
        val end = Offset(w / 2f + dx, h / 2f + dy)

        // 1. Vetro scuro traslucido (dark smoked glass) con lieve riflesso interno in alto
        if (drawBackground) {
            val darkGlassBase = Color(0xFF05070D).copy(alpha = glassOpacity.coerceIn(0f, 0.96f))
            val subtleGlassSheen = Brush.verticalGradient(
                colors = listOf(
                    Color.White.copy(alpha = (0.06f * glassOpacity).coerceAtMost(0.08f)),
                    darkGlassBase,
                    Color(0xFF020307).copy(alpha = (glassOpacity + 0.08f).coerceAtMost(0.96f))
                )
            )
            drawOutline(outline = outline, color = darkGlassBase)
            drawOutline(outline = outline, brush = subtleGlassSheen)
        }

        // 2. Rifinitura LED (Glow diffuso + Filamento principale + Specular highlight)
        if (drawLedBorder) {
            val strokePx = borderWidth.toPx().coerceAtLeast(1f)
            val ledBrush = Brush.linearGradient(
                colors = ledColors,
                start = start,
                end = end
            )

            if (activeGlow > 0.05f) {
                drawOutline(
                    outline = outline,
                    brush = ledBrush,
                    alpha = (0.11f * activeGlow).coerceAtMost(0.28f),
                    style = Stroke(width = strokePx * 5.2f)
                )
                drawOutline(
                    outline = outline,
                    brush = ledBrush,
                    alpha = (0.22f * activeGlow).coerceAtMost(0.45f),
                    style = Stroke(width = strokePx * 3.0f)
                )
                drawOutline(
                    outline = outline,
                    brush = ledBrush,
                    alpha = (0.42f * activeGlow).coerceAtMost(0.68f),
                    style = Stroke(width = strokePx * 1.8f)
                )
            }

            // Filamento LED nitido
            drawOutline(
                outline = outline,
                brush = ledBrush,
                alpha = 0.95f,
                style = Stroke(width = strokePx)
            )

            // Micro-filo bianco brillante centrale stile tubo neon LED
            drawOutline(
                outline = outline,
                color = Color.White.copy(alpha = (0.28f * activeGlow.coerceAtLeast(0.4f)).coerceAtMost(0.45f)),
                style = Stroke(width = (strokePx * 0.36f).coerceAtLeast(0.7f))
            )
        }
    }
}

/**
 * Libreria di icone vettoriali minimali integrate per personalizzare qualsiasi app senza Icon Pack.
 */
object MinimalGlyphRegistry {
    val glyphs: List<Pair<String, ImageVector>> = listOf(
        "phone" to Icons.Rounded.Phone,
        "chat" to Icons.Rounded.Chat,
        "camera" to Icons.Rounded.CameraAlt,
        "music" to Icons.Rounded.MusicNote,
        "work" to Icons.Rounded.Work,
        "calendar" to Icons.Rounded.CalendarToday,
        "mail" to Icons.Rounded.Email,
        "web" to Icons.Rounded.Language,
        "car" to Icons.Rounded.DirectionsCar,
        "home" to Icons.Rounded.Home,
        "notes" to Icons.Rounded.Edit,
        "photo" to Icons.Rounded.Image,
        "folder" to Icons.Rounded.Folder,
        "shield" to Icons.Rounded.Shield,
        "bolt" to Icons.Rounded.Bolt,
        "star" to Icons.Rounded.Star,
        "heart" to Icons.Rounded.Favorite,
        "sparkle" to Icons.Rounded.AutoAwesome,
        "bell" to Icons.Rounded.Notifications,
        "lock" to Icons.Rounded.Lock,
        "search" to Icons.Rounded.Search,
        "settings" to Icons.Rounded.Settings
    )

    fun resolve(key: String?): ImageVector? = glyphs.firstOrNull { it.first == key }?.second
}
