package com.onearc.launcher.ui.theme

import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.unit.dp

/**
 * Token fisici ispirati a Material 3 Expressive & One UI 120Hz.
 * - Spatial springs: con leggero overshoot elastico per movimento icone e pillole.
 * - Effects springs: smorzamento critico senza rimbalzo per colori, opacita e sfondi.
 */
object ExpressiveMotion {
    // Icona che reagisce al pollice sull'arco o ritorna in sede dopo la chiusura di un'app
    fun <T> spatialFast() = spring<T>(
        dampingRatio = 0.68f,
        stiffness = 780f
    )

    // Transizioni tra modalita Normale / Lavoro, apertura drawer, espansione pillole
    fun <T> spatialDefault() = spring<T>(
        dampingRatio = 0.76f,
        stiffness = 460f
    )

    // Ritorno fluido dell'icona stile Samsung Home
    fun <T> iconReturnSpring() = spring<T>(
        dampingRatio = 0.62f,
        stiffness = 380f
    )

    // Cambio colori Dynamic / sfocatura / scrim AMOLED
    fun <T> effectsDefault() = spring<T>(
        dampingRatio = Spring.DampingRatioNoBouncy,
        stiffness = 500f
    )
}

object ExpressiveShapes {
    val Pill = CircleShape
    val CardExpressive = RoundedCornerShape(32.dp)
    val DockContainer = RoundedCornerShape(36.dp)
    val IconSquircle = RoundedCornerShape(22.dp)
    val BadgePill = RoundedCornerShape(50)
    val SheetTop = RoundedCornerShape(topStart = 36.dp, topEnd = 36.dp)
}
