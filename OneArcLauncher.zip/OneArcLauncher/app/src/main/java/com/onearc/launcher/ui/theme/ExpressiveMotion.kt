package com.onearc.launcher.ui.theme

import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.unit.dp

object ExpressiveMotion {
    fun <T> spatialFast() = spring<T>(
        dampingRatio = 0.68f,
        stiffness = 780f
    )

    fun <T> spatialDefault() = spring<T>(
        dampingRatio = 0.76f,
        stiffness = 460f
    )

    fun <T> iconReturnSpring() = spring<T>(
        dampingRatio = 0.60f,
        stiffness = 380f
    )

    fun <T> effectsDefault() = spring<T>(
        dampingRatio = Spring.DampingRatioNoBouncy,
        stiffness = 500f
    )
}

object ExpressiveShapes {
    val Pill = CircleShape
    val CardExpressive = RoundedCornerShape(28.dp)
    val DockContainer = RoundedCornerShape(36.dp)
    val IconSquircle = RoundedCornerShape(22.dp)
    val BadgePill = RoundedCornerShape(50)
    val SheetTop = RoundedCornerShape(topStart = 34.dp, topEnd = 34.dp)
}
