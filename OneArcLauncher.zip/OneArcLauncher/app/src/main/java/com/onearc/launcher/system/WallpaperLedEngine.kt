package com.onearc.launcher.system

import android.app.WallpaperColors
import android.app.WallpaperManager
import android.content.Context
import android.os.Handler
import android.os.Looper
import androidx.compose.runtime.Immutable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import android.graphics.Color as AndroidColor

@Immutable
data class LedPalette(
    val primary: Color = Color(0xFF4CC9F0),
    val secondary: Color = Color(0xFF80FFDB),
    val tertiary: Color = Color(0xFF7209B7)
) {
    fun asGradientList(): List<Color> = listOf(primary, secondary, tertiary, primary)
}

/**
 * Estrae i colori dominanti direttamente dallo sfondo del Galaxy tramite WallpaperColors API
 * (senza permessi di archiviazione) e li amplifica in tonalita LED luminose su vetro scuro.
 * Si aggiorna in tempo reale non appena cambi lo sfondo sul telefono.
 */
class WallpaperLedEngine(context: Context) {

    private val wallpaperManager = context.getSystemService(Context.WALLPAPER_SERVICE) as WallpaperManager
    private val _palette = MutableStateFlow(LedPalette())
    val palette: StateFlow<LedPalette> = _palette.asStateFlow()

    private val listener = WallpaperManager.OnColorsChangedListener { colors, which ->
        if ((which and WallpaperManager.FLAG_SYSTEM) != 0) {
            updateFromWallpaperColors(colors)
        }
    }

    init {
        refreshNow()
        runCatching {
            wallpaperManager.addOnColorsChangedListener(listener, Handler(Looper.getMainLooper()))
        }
    }

    fun refreshNow() {
        val current = runCatching {
            wallpaperManager.getWallpaperColors(WallpaperManager.FLAG_SYSTEM)
        }.getOrNull()
        updateFromWallpaperColors(current)
    }

    fun release() {
        runCatching {
            wallpaperManager.removeOnColorsChangedListener(listener)
        }
    }

    private fun updateFromWallpaperColors(colors: WallpaperColors?) {
        if (colors == null) return
        val p = boostToLedLuminance(Color(colors.primaryColor.toArgb()))
        val s = colors.secondaryColor?.let { boostToLedLuminance(Color(it.toArgb())) }
            ?: shiftHue(p, 38f)
        val t = colors.tertiaryColor?.let { boostToLedLuminance(Color(it.toArgb())) }
            ?: shiftHue(p, -42f)

        _palette.value = LedPalette(primary = p, secondary = s, tertiary = t)
    }

    companion object {
        /**
         * Mantiene la tinta esatta dello sfondo ma assicura luminosita e saturazione
         * da vero filamento LED anche se lo sfondo e molto scuro o molto desaturato.
         */
        fun boostToLedLuminance(color: Color): Color {
            val hsv = FloatArray(3)
            AndroidColor.colorToHSV(color.toArgb(), hsv)
            // Se lo sfondo e quasi neutro (bianco/nero/grigio), crea un LED ghiaccio elegante
            if (hsv[1] < 0.08f) {
                hsv[1] = 0.14f
                hsv[2] = hsv[2].coerceIn(0.78f, 0.98f)
            } else {
                hsv[1] = hsv[1].coerceIn(0.62f, 1.0f)
                hsv[2] = hsv[2].coerceIn(0.84f, 1.0f)
            }
            return Color(AndroidColor.HSVToColor(hsv))
        }

        fun shiftHue(color: Color, deltaDegrees: Float): Color {
            val hsv = FloatArray(3)
            AndroidColor.colorToHSV(color.toArgb(), hsv)
            hsv[0] = (hsv[0] + deltaDegrees + 360f) % 360f
            hsv[1] = hsv[1].coerceIn(0.65f, 1.0f)
            hsv[2] = hsv[2].coerceIn(0.84f, 1.0f)
            return Color(AndroidColor.HSVToColor(hsv))
        }
    }
}
