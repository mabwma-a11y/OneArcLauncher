package com.onearc.launcher.ui.components

import android.graphics.Rect
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.PushPin
import androidx.compose.material.icons.rounded.Shortcut
import androidx.compose.material.icons.rounded.VisibilityOff
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import com.onearc.launcher.data.AppEntry
import com.onearc.launcher.data.AppShortcutItem
import com.onearc.launcher.data.LauncherPrefs
import com.onearc.launcher.ui.theme.ExpressiveShapes
import com.onearc.launcher.ui.theme.LocalLedPalette

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppContextSheet(
    app: AppEntry,
    prefs: LauncherPrefs,
    isPinnedInArc: Boolean,
    shortcuts: List<AppShortcutItem>,
    onCustomizeIcon: () -> Unit,
    onTogglePin: () -> Unit,
    onLaunchShortcut: (AppShortcutItem, Rect?) -> Unit,
    onHideApp: () -> Unit,
    onAppInfo: () -> Unit,
    onUninstall: () -> Unit,
    onDismiss: () -> Unit
) {
    val led = LocalLedPalette.current

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        shape = ExpressiveShapes.SheetTop,
        containerColor = Color(0xFF0A0E17)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .padding(horizontal = 20.dp, vertical = 8.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.padding(bottom = 14.dp)
            ) {
                OneArcIconVisual(
                    label = app.label,
                    iconBitmap = app.icon,
                    customGlyphKey = app.customGlyphKey,
                    customLedColorArgb = app.customLedColorArgb,
                    prefs = prefs,
                    sizeOverride = 46.dp
                )
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(text = app.label, style = MaterialTheme.typography.titleMedium, color = Color.White)
                    Text(
                        text = app.packageName,
                        style = MaterialTheme.typography.labelSmall,
                        color = Color.White.copy(alpha = 0.55f)
                    )
                }
            }

            if (shortcuts.isNotEmpty()) {
                Text(
                    text = "Azioni rapide",
                    style = MaterialTheme.typography.labelSmall,
                    color = led.primary,
                    modifier = Modifier.padding(bottom = 6.dp)
                )
                shortcuts.forEach { sc ->
                    ContextRowItem(
                        icon = Icons.Rounded.Shortcut,
                        tint = led.secondary,
                        label = sc.label,
                        onClick = { onLaunchShortcut(sc, null) }
                    )
                }
                HorizontalDivider(
                    color = Color.White.copy(alpha = 0.1f),
                    modifier = Modifier.padding(vertical = 8.dp)
                )
            }

            ContextRowItem(
                icon = Icons.Rounded.Edit,
                tint = led.primary,
                label = "Personalizza icona, nome e LED",
                onClick = onCustomizeIcon
            )
            ContextRowItem(
                icon = Icons.Rounded.PushPin,
                tint = Color.White,
                label = if (isPinnedInArc) "Rimuovi dall'Arco rapido" else "Fissa nell'Arco rapido",
                onClick = onTogglePin
            )
            ContextRowItem(
                icon = Icons.Rounded.VisibilityOff,
                tint = Color.White.copy(alpha = 0.85f),
                label = "Nascondi dal drawer",
                onClick = onHideApp
            )
            ContextRowItem(
                icon = Icons.Rounded.Info,
                tint = Color.White.copy(alpha = 0.85f),
                label = "Informazioni app",
                onClick = onAppInfo
            )
            ContextRowItem(
                icon = Icons.Rounded.DeleteOutline,
                tint = Color(0xFFFF6B6B),
                label = "Disinstalla",
                onClick = onUninstall
            )

            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}

@Composable
private fun ContextRowItem(
    icon: ImageVector,
    tint: Color,
    label: String,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(vertical = 12.dp, horizontal = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Icon(imageVector = icon, contentDescription = null, tint = tint)
        Text(text = label, style = MaterialTheme.typography.bodyLarge, color = Color.White)
    }
}
