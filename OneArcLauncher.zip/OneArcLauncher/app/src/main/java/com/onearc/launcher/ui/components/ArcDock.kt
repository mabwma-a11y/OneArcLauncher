package com.onearc.launcher.ui.components

import android.graphics.Rect
import android.view.HapticFeedbackConstants
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.ColorMatrix
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.boundsInRoot
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import com.onearc.launcher.data.AppEntry
import com.onearc.launcher.data.Handedness
import com.onearc.launcher.ui.theme.ExpressiveMotion
import com.onearc.launcher.ui.theme.ExpressiveShapes
import kotlin.math.roundToInt

/**
 * Arco ergonomico monomano nella zona del pollice:
 * - Le 5 app descrivono una curva naturale (destrimano o mancino).
 * - Supporta tap diretto, scorrimento continuo col pollice (scrubbing) con feedback aptico
 *   e pressione prolungata per azioni rapide.
 * - Salva i bounds reali di ogni icona per l'effetto espansione stile One UI all'apertura
 *   e riproduce un rimbalzo elastico di rientro al ritorno in Home.
 */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun ArcDock(
    apps: List<AppEntry>,
    badgeCounts: Map<String, Int>,
    handedness: Handedness,
    monochromeIcons: Boolean,
    lastLaunchedPackage: String?,
    returnPulseToken: Int,
    onLaunchApp: (AppEntry, Rect?) -> Unit,
    onLongPressApp: (AppEntry) -> Unit,
    modifier: Modifier = Modifier
) {
    val view = LocalView.current
    val itemBounds = remember { mutableStateMapOf<String, Rect>() }
    var scrubbedIndex by remember { mutableIntStateOf(-1) }

    // Curva verticale ergonomica per il pollice: piu alta sul lato esterno, piu bassa verso l'interno
    val verticalCurveDp = remember(handedness) {
        if (handedness == Handedness.RIGHT) {
            listOf(24, 10, 0, 6, 20)
        } else {
            listOf(20, 6, 0, 10, 24)
        }
    }

    val colorFilter = remember(monochromeIcons) {
        if (monochromeIcons) {
            ColorFilter.colorMatrix(ColorMatrix().apply { setToSaturation(0f) })
        } else {
            null
        }
    }

    Surface(
        modifier = modifier
            .fillMaxWidth()
            .pointerInput(apps) {
                detectHorizontalDragGestures(
                    onDragStart = { offset ->
                        if (apps.isNotEmpty()) {
                            val idx = ((offset.x / size.width) * apps.size)
                                .toInt()
                                .coerceIn(0, apps.lastIndex)
                            scrubbedIndex = idx
                            view.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
                        }
                    },
                    onHorizontalDrag = { change, _ ->
                        change.consume()
                        if (apps.isNotEmpty()) {
                            val idx = ((change.position.x / size.width) * apps.size)
                                .toInt()
                                .coerceIn(0, apps.lastIndex)
                            if (idx != scrubbedIndex) {
                                scrubbedIndex = idx
                                view.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
                            }
                        }
                    },
                    onDragEnd = {
                        val target = apps.getOrNull(scrubbedIndex)
                        scrubbedIndex = -1
                        if (target != null) {
                            view.performHapticFeedback(HapticFeedbackConstants.CONFIRM)
                            onLaunchApp(target, itemBounds[target.packageName])
                        }
                    },
                    onDragCancel = {
                        scrubbedIndex = -1
                    }
                )
            },
        shape = ExpressiveShapes.DockContainer,
        color = MaterialTheme.colorScheme.surfaceContainer.copy(alpha = 0.86f),
        tonalElevation = 6.dp
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 18.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.Bottom
        ) {
            apps.forEachIndexed { index, app ->
                val isScrubbed = scrubbedIndex == index
                val isReturning = lastLaunchedPackage == app.packageName && returnPulseToken > 0
                val yOffsetDp = verticalCurveDp.getOrElse(index) { 0 }

                // Animazione di ritorno stile Samsung: l'icona rientra da leggermente espansa al suo posto
                val returnScale = remember(app.packageName) { Animatable(1f) }
                LaunchedEffect(returnPulseToken, isReturning) {
                    if (isReturning) {
                        returnScale.snapTo(1.34f)
                        returnScale.animateTo(
                            targetValue = 1f,
                            animationSpec = ExpressiveMotion.iconReturnSpring()
                        )
                    }
                }

                val scrubScale by animateFloatAsState(
                    targetValue = if (isScrubbed) 1.24f else 1f,
                    animationSpec = ExpressiveMotion.spatialFast(),
                    label = "scrubScale"
                )

                val totalScale = scrubScale * returnScale.value
                val badgeCount = badgeCounts[app.packageName] ?: 0

                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier
                        .offset { IntOffset(0, (-yOffsetDp.dp.toPx()).roundToInt()) }
                        .scale(totalScale)
                        .onGloballyPositioned { coords ->
                            val b = coords.boundsInRoot()
                            val loc = IntArray(2)
                            view.getLocationOnScreen(loc)
                            itemBounds[app.packageName] = Rect(
                                (b.left + loc[0]).roundToInt(),
                                (b.top + loc[1]).roundToInt(),
                                (b.right + loc[0]).roundToInt(),
                                (b.bottom + loc[1]).roundToInt()
                            )
                        }
                ) {
                    Box(
                        modifier = Modifier.size(58.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Box(
                            modifier = Modifier
                                .size(54.dp)
                                .clip(ExpressiveShapes.IconSquircle)
                                .background(
                                    if (isScrubbed) {
                                        MaterialTheme.colorScheme.primaryContainer
                                    } else {
                                        MaterialTheme.colorScheme.surfaceContainerHigh.copy(alpha = 0.72f)
                                    }
                                )
                                .border(
                                    width = if (isScrubbed) 2.dp else 1.dp,
                                    color = if (isScrubbed) {
                                        MaterialTheme.colorScheme.primary
                                    } else {
                                        MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.35f)
                                    },
                                    shape = ExpressiveShapes.IconSquircle
                                )
                                .combinedClickable(
                                    onClick = {
                                        view.performHapticFeedback(HapticFeedbackConstants.CONTEXT_CLICK)
                                        onLaunchApp(app, itemBounds[app.packageName])
                                    },
                                    onLongClick = {
                                        view.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
                                        onLongPressApp(app)
                                    }
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            if (app.icon != null) {
                                Image(
                                    bitmap = app.icon,
                                    contentDescription = app.label,
                                    colorFilter = colorFilter,
                                    modifier = Modifier.size(38.dp)
                                )
                            } else {
                                Text(
                                    text = app.label.take(1).uppercase(),
                                    style = MaterialTheme.typography.titleMedium,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }

                        // Badge Contatore Notifiche sull'angolo superiore destro dell'icona
                        NotificationCounterBadge(
                            count = badgeCount,
                            modifier = Modifier
                                .align(Alignment.TopEnd)
                                .offset(x = 4.dp, y = (-4).dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    Text(
                        text = app.label,
                        style = MaterialTheme.typography.labelSmall,
                        color = if (isScrubbed) {
                            MaterialTheme.colorScheme.primary
                        } else {
                            MaterialTheme.colorScheme.onSurfaceVariant
                        },
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.padding(horizontal = 2.dp)
                    )
                }
            }
        }
    }
}
