package com.onearc.launcher.ui.components

import android.graphics.Rect
import android.view.HapticFeedbackConstants
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.boundsInRoot
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.onearc.launcher.data.AppEntry
import com.onearc.launcher.data.Handedness
import com.onearc.launcher.data.LauncherPrefs
import com.onearc.launcher.ui.theme.ExpressiveMotion
import com.onearc.launcher.ui.theme.ExpressiveShapes
import com.onearc.launcher.ui.theme.LocalLedPalette
import kotlin.math.abs
import kotlin.math.pow
import kotlin.math.roundToInt

/**
 * Dock ad Arco trasparente scura con bordo LED sincronizzato allo sfondo Galaxy.
 * Supporta da 4 a 7 icone, curvatura regolabile, scrubbing aptico e animazioni One UI bounds.
 */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun ArcDock(
    apps: List<AppEntry>,
    badgeCounts: Map<String, Int>,
    prefs: LauncherPrefs,
    lastLaunchedPackage: String?,
    returnPulseToken: Int,
    onLaunchApp: (AppEntry, Rect?) -> Unit,
    onLongPressApp: (AppEntry) -> Unit,
    modifier: Modifier = Modifier
) {
    val view = LocalView.current
    val led = LocalLedPalette.current
    val itemBounds = remember { mutableStateMapOf<String, Rect>() }
    var scrubbedIndex by remember { mutableIntStateOf(-1) }

    // Calcola la curva ergonomica parabolica per qualsiasi numero di app (4..7)
    val verticalCurveDp = remember(apps.size, prefs.handedness, prefs.arcCurvatureDp) {
        val n = apps.size.coerceAtLeast(1)
        val center = if (prefs.handedness == Handedness.RIGHT) (n - 1) * 0.56f else (n - 1) * 0.44f
        val maxDist = maxOf(center, (n - 1) - center, 1f)
        List(n) { idx ->
            val norm = (abs(idx - center) / maxDist).pow(1.65f)
            (norm * prefs.arcCurvatureDp).roundToInt()
        }
    }

    // Adatta leggermente la dimensione massima delle icone se l'utente ne sceglie 6 o 7
    val adaptiveIconSize = remember(apps.size, prefs.iconSizeDp) {
        when {
            apps.size >= 7 -> prefs.iconSizeDp.coerceAtMost(46f).dp
            apps.size == 6 -> prefs.iconSizeDp.coerceAtMost(50f).dp
            else -> prefs.iconSizeDp.dp
        }
    }

    Box(
        modifier = modifier
            .fillMaxWidth()
            .ledGlassSurface(
                shape = ExpressiveShapes.DockContainer,
                glassOpacity = prefs.darkGlassOpacity,
                borderWidth = prefs.ledBorderWidthDp.dp,
                glowIntensity = prefs.ledGlowIntensity,
                animationMode = prefs.ledAnimationMode
            )
            .pointerInput(apps) {
                detectHorizontalDragGestures(
                    onDragStart = { offset ->
                        if (apps.isNotEmpty()) {
                            val idx = ((offset.x / size.width) * apps.size)
                                .toInt()
                                .coerceIn(0, apps.lastIndex)
                            scrubbedIndex = idx
                            view.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
                        }
                    },
                    onHorizontalDrag = { change, _ ->
                        change.consume()
                        if (apps.isNotEmpty()) {
                            val idx = ((change.position.x / size.width) * apps.size)
                                .toInt()
                                .coerceIn(0, apps.lastIndex)
                            if (idx != scrubbedIndex) {
                                scrubbedIndex = idx
                                view.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
                            }
                        }
                    },
                    onDragEnd = {
                        val target = apps.getOrNull(scrubbedIndex)
                        scrubbedIndex = -1
                        if (target != null) {
                            view.performHapticFeedback(HapticFeedbackConstants.CONFIRM)
                            onLaunchApp(target, itemBounds[target.packageName])
                        }
                    },
                    onDragCancel = { scrubbedIndex = -1 }
                )
            }
            .padding(horizontal = 10.dp, vertical = 18.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.Bottom
        ) {
            apps.forEachIndexed { index, app ->
                val isScrubbed = scrubbedIndex == index
                val isReturning = lastLaunchedPackage == app.packageName && returnPulseToken > 0
                val yOffsetDp = verticalCurveDp.getOrElse(index) { 0 }

                val returnScale = remember(app.packageName) { Animatable(1f) }
                LaunchedEffect(returnPulseToken, isReturning) {
                    if (isReturning) {
                        returnScale.snapTo(1.36f)
                        returnScale.animateTo(
                            targetValue = 1f,
                            animationSpec = ExpressiveMotion.iconReturnSpring()
                        )
                    }
                }

                val scrubScale by animateFloatAsState(
                    targetValue = if (isScrubbed) 1.24f else 1f,
                    animationSpec = ExpressiveMotion.spatialFast(),
                    label = "scrubScale"
                )

                val totalScale = scrubScale * returnScale.value
                val badgeCount = badgeCounts[app.packageName] ?: 0

                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier
                        .weight(1f)
                        .offset { IntOffset(0, (-yOffsetDp.dp.toPx()).roundToInt()) }
                        .scale(totalScale)
                        .onGloballyPositioned { coords ->
                            val b = coords.boundsInRoot()
                            val loc = IntArray(2)
                            view.getLocationOnScreen(loc)
                            itemBounds[app.packageName] = Rect(
                                (b.left + loc[0]).roundToInt(),
                                (b.top + loc[1]).roundToInt(),
                                (b.right + loc[0]).roundToInt(),
                                (b.bottom + loc[1]).roundToInt()
                            )
                        }
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        OneArcIconVisual(
                            label = app.label,
                            iconBitmap = app.icon,
                            customGlyphKey = app.customGlyphKey,
                            customLedColorArgb = app.customLedColorArgb,
                            prefs = prefs,
                            sizeOverride = adaptiveIconSize,
                            isHighlighted = isScrubbed,
                            modifier = Modifier.combinedClickable(
                                onClick = {
                                    view.performHapticFeedback(HapticFeedbackConstants.CONTEXT_CLICK)
                                    onLaunchApp(app, itemBounds[app.packageName])
                                },
                                onLongClick = {
                                    view.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
                                    onLongPressApp(app)
                                }
                            )
                        )

                        NotificationCounterBadge(
                            count = badgeCount,
                            style = prefs.badgeStyle,
                            useLedColor = prefs.badgeUseLedColor,
                            modifier = Modifier
                                .align(Alignment.TopEnd)
                                .offset(x = 5.dp, y = (-5).dp)
                        )
                    }

                    if (prefs.showArcLabels) {
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = app.label,
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontSize = prefs.labelTextSizeSp.sp
                            ),
                            color = if (isScrubbed) led.primary else Color.White.copy(alpha = 0.84f),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.padding(horizontal = 2.dp)
                        )
                    }
                }
            }
        }
    }
}
