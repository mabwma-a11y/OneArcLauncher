package com.onearc.launcher.ui.components

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.ColorMatrix
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.onearc.launcher.data.IconColorMode
import com.onearc.launcher.data.IconContainerStyle
import com.onearc.launcher.data.IconShapeStyle
import com.onearc.launcher.data.LauncherPrefs
import com.onearc.launcher.ui.theme.LocalLedPalette

/**
 * Renderer unificato delle icone OneArc:
 * Applica forma, contenitore vetro scuro + LED, colore/tinta, saturazione, opacita,
 * dimensione, zoom interno e override per singola app (galleria, glifo minimal o accent LED).
 */
@Composable
fun OneArcIconVisual(
    label: String,
    iconBitmap: ImageBitmap?,
    customGlyphKey: String?,
    customLedColorArgb: Long?,
    prefs: LauncherPrefs,
    sizeOverride: Dp? = null,
    isHighlighted: Boolean = false,
    modifier: Modifier = Modifier
) {
    val ledPalette = LocalLedPalette.current
    val customAccent = customLedColorArgb?.let { Color(it.toInt()) }
    val activeAccent = customAccent ?: ledPalette.primary

    val boxSize = sizeOverride ?: prefs.iconSizeDp.dp
    val shape = remember(prefs.iconShape) { resolveIconShape(prefs.iconShape) }

    val drawBg = prefs.iconShape != IconShapeStyle.NONE &&
        (prefs.iconContainerStyle == IconContainerStyle.DARK_GLASS_LED ||
            prefs.iconContainerStyle == IconContainerStyle.DARK_GLASS)

    val drawLed = prefs.iconShape != IconShapeStyle.NONE &&
        (isHighlighted ||
            (prefs.perIconLedEnabled &&
                (prefs.iconContainerStyle == IconContainerStyle.DARK_GLASS_LED ||
                    prefs.iconContainerStyle == IconContainerStyle.LED_OUTLINE_ONLY)))

    val iconTintFilter = remember(prefs.iconColorMode, prefs.iconSaturation, activeAccent) {
        when (prefs.iconColorMode) {
            IconColorMode.ORIGINAL -> {
                if (prefs.iconSaturation != 1.0f) {
                    ColorFilter.colorMatrix(ColorMatrix().apply { setToSaturation(prefs.iconSaturation) })
                } else {
                    null
                }
            }
            IconColorMode.MONOCHROME -> {
                ColorFilter.colorMatrix(ColorMatrix().apply { setToSaturation(0f) })
            }
            IconColorMode.WALLPAPER_TINT -> {
                ColorFilter.tint(activeAccent, BlendMode.SrcAtop)
            }
            IconColorMode.NEON_DUOTONE -> {
                ColorFilter.tint(activeAccent.copy(alpha = 0.82f), BlendMode.Modulate)
            }
        }
    }

    val glyphVector = remember(customGlyphKey) { MinimalGlyphRegistry.resolve(customGlyphKey) }
    val innerSize = boxSize * prefs.iconInnerScale.coerceIn(0.45f, 1.05f)

    Box(
        modifier = modifier
            .size(boxSize)
            .ledGlassSurface(
                shape = shape,
                glassOpacity = if (isHighlighted) (prefs.darkGlassOpacity + 0.16f).coerceAtMost(0.92f) else prefs.darkGlassOpacity,
                borderWidth = if (isHighlighted) (prefs.ledBorderWidthDp + 0.8f).dp else (prefs.ledBorderWidthDp * 0.78f).dp,
                glowIntensity = if (isHighlighted) (prefs.ledGlowIntensity * 1.35f).coerceAtMost(1.6f) else prefs.ledGlowIntensity * 0.75f,
                animationMode = prefs.ledAnimationMode,
                drawBackground = drawBg,
                drawLedBorder = drawLed,
                overrideAccentColor = customAccent
            )
            .let { mod ->
                if (prefs.iconShape != IconShapeStyle.NONE) mod.clip(shape) else mod
            },
        contentAlignment = Alignment.Center
    ) {
        when {
            glyphVector != null -> {
                Icon(
                    imageVector = glyphVector,
                    contentDescription = label,
                    tint = when (prefs.iconColorMode) {
                        IconColorMode.MONOCHROME -> Color.White
                        else -> activeAccent
                    },
                    modifier = Modifier
                        .size(innerSize * 0.88f)
                        .alpha(prefs.iconOpacity)
                )
            }
            iconBitmap != null -> {
                Image(
                    bitmap = iconBitmap,
                    contentDescription = label,
                    contentScale = ContentScale.Crop,
                    colorFilter = iconTintFilter,
                    modifier = Modifier
                        .size(innerSize)
                        .alpha(prefs.iconOpacity)
                        .let { m ->
                            if (prefs.iconInnerScale >= 0.92f && prefs.iconShape != IconShapeStyle.NONE) {
                                m.clip(shape)
                            } else {
                                m
                            }
                        }
                )
            }
            else -> {
                Text(
                    text = label.take(1).uppercase(),
                    style = MaterialTheme.typography.titleMedium,
                    color = activeAccent
                )
            }
        }
    }
}
