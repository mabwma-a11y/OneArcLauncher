package com.onearc.launcher.system

import android.app.role.RoleManager
import android.content.Context
import android.content.Intent
import android.provider.Settings

/**
 * Gestisce il controllo e la richiesta integrata del ruolo Home/Launcher predefinito
 * tramite RoleManager nativo Android (popup di sistema diretto all'apertura dell'app).
 */
object DefaultLauncherHelper {

    fun isDefaultLauncher(context: Context): Boolean {
        return runCatching {
            val roleManager = context.getSystemService(RoleManager::class.java)
            roleManager != null &&
                roleManager.isRoleAvailable(RoleManager.ROLE_HOME) &&
                roleManager.isRoleHeld(RoleManager.ROLE_HOME)
        }.getOrDefault(false)
    }

    fun createRequestDefaultIntent(context: Context): Intent {
        val roleManager = context.getSystemService(RoleManager::class.java)
        if (roleManager != null && roleManager.isRoleAvailable(RoleManager.ROLE_HOME)) {
            return runCatching {
                roleManager.createRequestRoleIntent(RoleManager.ROLE_HOME)
            }.getOrElse {
                Intent(Settings.ACTION_HOME_SETTINGS)
            }
        }
        return Intent(Settings.ACTION_HOME_SETTINGS)
    }
}
