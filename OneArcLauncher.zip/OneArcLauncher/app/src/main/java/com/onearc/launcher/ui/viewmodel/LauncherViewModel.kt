package com.onearc.launcher.ui.viewmodel

import android.app.Application
import android.graphics.Rect
import android.net.Uri
import android.view.View
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.onearc.launcher.data.AppCustomization
import com.onearc.launcher.data.AppEntry
import com.onearc.launcher.data.AppRepository
import com.onearc.launcher.data.AppShortcutItem
import com.onearc.launcher.data.BadgeStyle
import com.onearc.launcher.data.CustomIconType
import com.onearc.launcher.data.Handedness
import com.onearc.launcher.data.IconColorMode
import com.onearc.launcher.data.IconContainerStyle
import com.onearc.launcher.data.IconPackInfo
import com.onearc.launcher.data.IconShapeStyle
import com.onearc.launcher.data.LauncherMode
import com.onearc.launcher.data.LauncherPrefs
import com.onearc.launcher.data.LedAnimationMode
import com.onearc.launcher.data.PreferencesRepository
import com.onearc.launcher.service.BadgeNotificationListenerService
import com.onearc.launcher.system.DefaultLauncherHelper
import com.onearc.launcher.system.LedPalette
import com.onearc.launcher.system.WallpaperLedEngine
import com.onearc.launcher.system.WorkModeController
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class LauncherUiState(
    val allApps: List<AppEntry> = emptyList(),
    val visibleApps: List<AppEntry> = emptyList(),
    val arcApps: List<AppEntry> = emptyList(),
    val iconPacks: List<IconPackInfo> = emptyList(),
    val badgeCounts: Map<String, Int> = emptyMap(),
    val totalBadges: Int = 0,
    val mode: LauncherMode = LauncherMode.NORMAL,
    val prefs: LauncherPrefs = LauncherPrefs(),
    val ledPalette: LedPalette = LedPalette(),
    val isDefaultLauncher: Boolean = true,
    val showDefaultLauncherPrompt: Boolean = false,
    val isDrawerOpen: Boolean = false,
    val isSettingsOpen: Boolean = false,
    val isIconStudioOpen: Boolean = false,
    val customizingApp: AppEntry? = null,
    val searchQuery: String = "",
    val selectedAppForMenu: AppEntry? = null,
    val selectedAppShortcuts: List<AppShortcutItem> = emptyList(),
    val lastLaunchedPackage: String? = null,
    val returnPulseToken: Int = 0,
    val hardwarePrivacyActive: Boolean = false,
    val statusBanner: String? = null
)

class LauncherViewModel(application: Application) : AndroidViewModel(application) {

    private val appRepository = AppRepository(application)
    private val prefsRepository = PreferencesRepository(application)
    val workModeController = WorkModeController(application)
    private val wallpaperLedEngine = WallpaperLedEngine(application)

    private val _allApps = MutableStateFlow<List<AppEntry>>(emptyList())
    private val _iconPacks = MutableStateFlow<List<IconPackInfo>>(emptyList())
    private val _mode = MutableStateFlow(LauncherMode.NORMAL)
    private val _isDefaultLauncher = MutableStateFlow(DefaultLauncherHelper.isDefaultLauncher(application))
    private val _dismissedDefaultPromptThisSession = MutableStateFlow(false)
    private val _drawerOpen = MutableStateFlow(false)
    private val _settingsOpen = MutableStateFlow(false)
    private val _iconStudioOpen = MutableStateFlow(false)
    private val _customizingAppPkg = MutableStateFlow<String?>(null)
    private val _searchQuery = MutableStateFlow("")
    private val _selectedApp = MutableStateFlow<AppEntry?>(null)
    private val _selectedShortcuts = MutableStateFlow<List<AppShortcutItem>>(emptyList())
    private val _lastLaunchedPkg = MutableStateFlow<String?>(null)
    private val _returnPulse = MutableStateFlow(0)
    private val _hwPrivacyActive = MutableStateFlow(false)
    private val _statusBanner = MutableStateFlow<String?>(null)

    private val baseState = combine(
        _allApps,
        prefsRepository.preferencesFlow,
        BadgeNotificationListenerService.badgeCounts,
        _mode,
        _searchQuery
    ) { apps, prefs, badges, mode, query ->
        val visible = apps.filter { it.packageName !in prefs.hiddenPackages }
        val configuredArc = if (mode == LauncherMode.NORMAL) prefs.arcPackagesNormal else prefs.arcPackagesWork
        val arcResolved = resolveArcApps(visible, configuredArc, mode, prefs.arcIconCount)
        val filteredDrawer = if (query.isBlank()) {
            visible
        } else {
            visible.filter { it.label.contains(query.trim(), ignoreCase = true) }
        }

        LauncherUiState(
            allApps = apps,
            visibleApps = filteredDrawer,
            arcApps = arcResolved,
            badgeCounts = badges,
            totalBadges = badges.values.sum(),
            mode = mode,
            prefs = prefs,
            searchQuery = query
        )
    }

    private val overlayState = combine(
        _drawerOpen,
        _settingsOpen,
        _iconStudioOpen,
        _customizingAppPkg,
        _selectedApp
    ) { drawer, settings, studio, customPkg, selected ->
        OverlayFlags(drawer, settings, studio, customPkg, selected)
    }

    private val systemState = combine(
        wallpaperLedEngine.palette,
        _isDefaultLauncher,
        _dismissedDefaultPromptThisSession,
        _iconPacks,
        _selectedShortcuts
    ) { led, isDef, dismissed, packs, shortcuts ->
        SystemFlags(led, isDef, dismissed, packs, shortcuts)
    }

    private val animState = combine(
        _lastLaunchedPkg,
        _returnPulse,
        _hwPrivacyActive,
        _statusBanner
    ) { lastPkg, pulse, hwPriv, banner ->
        AnimFlags(lastPkg, pulse, hwPriv, banner)
    }

    val uiState: StateFlow<LauncherUiState> = combine(
        baseState,
        overlayState,
        systemState,
        animState
    ) { base, overlay, sys, anim ->
        val customizingEntry = overlay.customPkg?.let { pkg ->
            base.allApps.firstOrNull { it.packageName == pkg }
        }
        val shouldShowDefaultPrompt = !sys.isDefault &&
            base.prefs.askDefaultLauncherOnStart &&
            !sys.dismissedDefaultPrompt

        base.copy(
            iconPacks = sys.packs,
            ledPalette = sys.led,
            isDefaultLauncher = sys.isDefault,
            showDefaultLauncherPrompt = shouldShowDefaultPrompt,
            isDrawerOpen = overlay.drawer,
            isSettingsOpen = overlay.settings,
            isIconStudioOpen = overlay.studio,
            customizingApp = customizingEntry,
            selectedAppForMenu = overlay.selected,
            selectedAppShortcuts = sys.shortcuts,
            lastLaunchedPackage = anim.lastPkg,
            returnPulseToken = anim.pulse,
            hardwarePrivacyActive = anim.hwPriv,
            statusBanner = anim.banner
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000),
        initialValue = LauncherUiState()
    )

    init {
        refreshIconPacks()

        // Ricarica le icone automaticamente ogni volta che cambiano Icon Pack o personalizzazioni app
        viewModelScope.launch {
            prefsRepository.preferencesFlow
                .map { it.selectedIconPackPackage to it.appCustomizations }
                .distinctUntilChanged()
                .collect { (packPkg, customs) ->
                    _allApps.value = appRepository.loadInstalledApps(packPkg, customs)
                }
        }

        viewModelScope.launch {
            appRepository.observePackageChanges().collect {
                refreshIconPacks()
                reloadAppsNow()
            }
        }
    }

    override fun onCleared() {
        super.onCleared()
        wallpaperLedEngine.release()
    }

    fun reloadAppsNow() {
        viewModelScope.launch {
            val prefs = uiState.value.prefs
            _allApps.value = appRepository.loadInstalledApps(
                prefs.selectedIconPackPackage,
                prefs.appCustomizations
            )
        }
    }

    fun refreshIconPacks() {
        viewModelScope.launch {
            _iconPacks.value = appRepository.getInstalledIconPacks()
        }
    }

    fun refreshSystemStatus() {
        _isDefaultLauncher.value = DefaultLauncherHelper.isDefaultLauncher(getApplication())
        wallpaperLedEngine.refreshNow()
    }

    fun dismissDefaultPromptForSession() {
        _dismissedDefaultPromptThisSession.value = true
    }

    fun disableDefaultPromptForever() {
        _dismissedDefaultPromptThisSession.value = true
        viewModelScope.launch {
            prefsRepository.setAskDefaultLauncherOnStart(false)
        }
    }

    fun toggleWorkMode() {
        val nextMode = if (_mode.value == LauncherMode.NORMAL) LauncherMode.WORK else LauncherMode.NORMAL
        _mode.value = nextMode
        val enabled = nextMode == LauncherMode.WORK
        val result = workModeController.setWorkMode(
            enabled = enabled,
            privacySettingKey = uiState.value.prefs.privacySettingKey
        )
        _hwPrivacyActive.value = enabled && result.hardwarePrivacyToggled
        showTemporaryBanner(result.statusMessage)
    }

    fun launchApp(app: AppEntry, anchorView: View?, sourceBounds: Rect?) {
        _lastLaunchedPkg.value = app.packageName
        _drawerOpen.value = false
        _searchQuery.value = ""
        _selectedApp.value = null
        appRepository.launchApp(app, anchorView, sourceBounds)
    }

    fun notifyReturnedHome() {
        refreshSystemStatus()
        if (_lastLaunchedPkg.value != null) {
            _returnPulse.value += 1
            viewModelScope.launch {
                delay(650)
                _lastLaunchedPkg.value = null
            }
        }
    }

    fun openDrawer() { _drawerOpen.value = true }
    fun closeDrawer() { _drawerOpen.value = false; _searchQuery.value = "" }
    fun updateSearchQuery(q: String) { _searchQuery.value = q }
    fun openSettings() { _settingsOpen.value = true }
    fun closeSettings() { _settingsOpen.value = false }
    fun openIconStudio() { _iconStudioOpen.value = true }
    fun closeIconStudio() { _iconStudioOpen.value = false }

    fun openAppContextMenu(app: AppEntry) {
        _selectedApp.value = app
        _selectedShortcuts.value = appRepository.getAppShortcuts(app)
    }

    fun closeAppContextMenu() {
        _selectedApp.value = null
        _selectedShortcuts.value = emptyList()
    }

    fun openAppCustomizer(app: AppEntry) {
        closeAppContextMenu()
        _customizingAppPkg.value = app.packageName
    }

    fun closeAppCustomizer() {
        _customizingAppPkg.value = null
    }

    fun saveAppCustomization(packageName: String, customization: AppCustomization?) {
        viewModelScope.launch {
            appRepository.clearIconCache()
            prefsRepository.setAppCustomization(packageName, customization)
            showTemporaryBanner(
                if (customization == null) "Icona ripristinata" else "Personalizzazione icona salvata"
            )
        }
    }

    fun pickGalleryIconForApp(packageName: String, uri: Uri, current: AppCustomization?) {
        viewModelScope.launch {
            val savedPath = appRepository.saveCustomIconFromUri(packageName, uri)
            if (savedPath != null) {
                val updated = (current ?: AppCustomization()).copy(
                    iconType = CustomIconType.GALLERY_IMAGE,
                    iconValue = savedPath
                )
                prefsRepository.setAppCustomization(packageName, updated)
                showTemporaryBanner("Immagine icona applicata")
            } else {
                showTemporaryBanner("Impossibile caricare l'immagine")
            }
        }
    }

    fun launchShortcut(shortcut: AppShortcutItem, bounds: Rect?) {
        closeAppContextMenu()
        appRepository.launchShortcut(shortcut, bounds)
    }

    fun openAppInfo(app: AppEntry) {
        closeAppContextMenu()
        appRepository.openAppInfo(app)
    }

    fun requestUninstall(app: AppEntry) {
        closeAppContextMenu()
        appRepository.requestUninstall(app)
    }

    fun togglePinInCurrentArc(app: AppEntry) {
        viewModelScope.launch {
            val mode = _mode.value
            val maxCount = uiState.value.prefs.arcIconCount
            val current = uiState.value.arcApps.map { it.packageName }.toMutableList()
            if (app.packageName in current) {
                current.remove(app.packageName)
                showTemporaryBanner("${app.label} rimossa dall'Arco")
            } else {
                while (current.size >= maxCount) {
                    current.removeAt(current.lastIndex)
                }
                current.add(0, app.packageName)
                showTemporaryBanner("${app.label} aggiunta all'Arco")
            }
            prefsRepository.setArcPackages(mode, current)
            closeAppContextMenu()
        }
    }

    fun toggleHideApp(app: AppEntry) {
        viewModelScope.launch {
            prefsRepository.toggleHiddenPackage(app.packageName)
            closeAppContextMenu()
            showTemporaryBanner("Visibilita aggiornata per ${app.label}")
        }
    }

    // Setters Preferenze LED & Icon Studio
    fun setHandedness(v: Handedness) = viewModelScope.launch { prefsRepository.setHandedness(v) }
    fun setArcIconCount(v: Int) = viewModelScope.launch { prefsRepository.setArcIconCount(v) }
    fun setArcCurvature(v: Float) = viewModelScope.launch { prefsRepository.setArcCurvature(v) }

    fun setLedAnimationMode(v: LedAnimationMode) = viewModelScope.launch { prefsRepository.setLedAnimationMode(v) }
    fun setLedGlowIntensity(v: Float) = viewModelScope.launch { prefsRepository.setLedGlowIntensity(v) }
    fun setLedBorderWidth(v: Float) = viewModelScope.launch { prefsRepository.setLedBorderWidth(v) }
    fun setDarkGlassOpacity(v: Float) = viewModelScope.launch { prefsRepository.setDarkGlassOpacity(v) }
    fun setPerIconLedEnabled(v: Boolean) = viewModelScope.launch { prefsRepository.setPerIconLedEnabled(v) }

    fun setIconPack(pkg: String) = viewModelScope.launch {
        appRepository.clearIconCache()
        prefsRepository.setIconPack(pkg)
    }
    fun setIconShape(v: IconShapeStyle) = viewModelScope.launch { prefsRepository.setIconShape(v) }
    fun setIconContainerStyle(v: IconContainerStyle) = viewModelScope.launch { prefsRepository.setIconContainerStyle(v) }
    fun setIconColorMode(v: IconColorMode) = viewModelScope.launch { prefsRepository.setIconColorMode(v) }
    fun setIconSize(v: Float) = viewModelScope.launch { prefsRepository.setIconSize(v) }
    fun setIconInnerScale(v: Float) = viewModelScope.launch { prefsRepository.setIconInnerScale(v) }
    fun setIconSaturation(v: Float) = viewModelScope.launch { prefsRepository.setIconSaturation(v) }
    fun setIconOpacity(v: Float) = viewModelScope.launch { prefsRepository.setIconOpacity(v) }
    fun setShowArcLabels(v: Boolean) = viewModelScope.launch { prefsRepository.setShowArcLabels(v) }
    fun setShowDrawerLabels(v: Boolean) = viewModelScope.launch { prefsRepository.setShowDrawerLabels(v) }
    fun setLabelTextSizeSp(v: Float) = viewModelScope.launch { prefsRepository.setLabelTextSizeSp(v) }
    fun setBadgeStyle(v: BadgeStyle) = viewModelScope.launch { prefsRepository.setBadgeStyle(v) }
    fun setBadgeUseLedColor(v: Boolean) = viewModelScope.launch { prefsRepository.setBadgeUseLedColor(v) }
    fun resetAllIconStyles() = viewModelScope.launch {
        appRepository.clearIconCache()
        prefsRepository.resetAllIconStyles()
        showTemporaryBanner("Stile icone e LED ripristinato")
    }

    fun setDoubleTapToLock(v: Boolean) = viewModelScope.launch { prefsRepository.setDoubleTapToLock(v) }
    fun setAutoFocusSearch(v: Boolean) = viewModelScope.launch { prefsRepository.setAutoFocusSearch(v) }
    fun setAmoledWorkBackground(v: Boolean) = viewModelScope.launch { prefsRepository.setAmoledWorkBackground(v) }
    fun setPrivacyFallbackDimmer(v: Boolean) = viewModelScope.launch { prefsRepository.setPrivacyFallbackDimmer(v) }
    fun setPrivacySettingKey(v: String) = viewModelScope.launch { prefsRepository.setPrivacySettingKey(v) }
    fun setAskDefaultLauncherOnStart(v: Boolean) = viewModelScope.launch { prefsRepository.setAskDefaultLauncherOnStart(v) }

    fun showTemporaryBanner(text: String) {
        _statusBanner.value = text
        viewModelScope.launch {
            delay(3200)
            if (_statusBanner.value == text) _statusBanner.value = null
        }
    }

    private fun resolveArcApps(
        visibleApps: List<AppEntry>,
        configured: List<String>,
        mode: LauncherMode,
        count: Int
    ): List<AppEntry> {
        val byPkg = visibleApps.associateBy { it.packageName }
        val resolved = configured.mapNotNull { byPkg[it] }.toMutableList()
        if (resolved.size >= count) return resolved.take(count)

        val preferredDefaults = if (mode == LauncherMode.WORK) {
            listOf(
                "com.samsung.android.dialer",
                "com.whatsapp",
                "com.samsung.android.calendar",
                "com.samsung.android.app.notes",
                "com.google.android.gm",
                "com.microsoft.teams",
                "com.sec.android.app.clockpackage"
            )
        } else {
            listOf(
                "com.samsung.android.dialer",
                "com.whatsapp",
                "com.sec.android.app.camera",
                "com.sec.android.app.sbrowser",
                "com.android.chrome",
                "com.spotify.music",
                "com.sec.android.gallery3d"
            )
        }

        for (pkg in preferredDefaults) {
            if (resolved.size >= count) break
            val candidate = byPkg[pkg]
            if (candidate != null && resolved.none { it.packageName == pkg }) {
                resolved += candidate
            }
        }
        for (app in visibleApps) {
            if (resolved.size >= count) break
            if (resolved.none { it.packageName == app.packageName }) {
                resolved += app
            }
        }
        return resolved.take(count)
    }

    private data class OverlayFlags(
        val drawer: Boolean,
        val settings: Boolean,
        val studio: Boolean,
        val customPkg: String?,
        val selected: AppEntry?
    )

    private data class SystemFlags(
        val led: LedPalette,
        val isDefault: Boolean,
        val dismissedDefaultPrompt: Boolean,
        val packs: List<IconPackInfo>,
        val shortcuts: List<AppShortcutItem>
    )

    private data class AnimFlags(
        val lastPkg: String?,
        val pulse: Int,
        val hwPriv: Boolean,
        val banner: String?
    )
}
