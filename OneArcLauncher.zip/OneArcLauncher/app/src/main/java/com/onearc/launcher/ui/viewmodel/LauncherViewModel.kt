package com.onearc.launcher.ui.viewmodel

import android.app.Application
import android.graphics.Rect
import android.view.View
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.onearc.launcher.data.AppEntry
import com.onearc.launcher.data.AppRepository
import com.onearc.launcher.data.AppShortcutItem
import com.onearc.launcher.data.Handedness
import com.onearc.launcher.data.LauncherMode
import com.onearc.launcher.data.LauncherPrefs
import com.onearc.launcher.data.PreferencesRepository
import com.onearc.launcher.service.BadgeNotificationListenerService
import com.onearc.launcher.system.WorkModeController
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class LauncherUiState(
    val allApps: List<AppEntry> = emptyList(),
    val visibleApps: List<AppEntry> = emptyList(),
    val arcApps: List<AppEntry> = emptyList(),
    val badgeCounts: Map<String, Int> = emptyMap(),
    val totalBadges: Int = 0,
    val mode: LauncherMode = LauncherMode.NORMAL,
    val prefs: LauncherPrefs = LauncherPrefs(),
    val isDrawerOpen: Boolean = false,
    val isSettingsOpen: Boolean = false,
    val searchQuery: String = "",
    val selectedAppForMenu: AppEntry? = null,
    val selectedAppShortcuts: List<AppShortcutItem> = emptyList(),
    val lastLaunchedPackage: String? = null,
    val returnPulseToken: Int = 0,
    val hardwarePrivacyActive: Boolean = false,
    val statusBanner: String? = null
)

class LauncherViewModel(application: Application) : AndroidViewModel(application) {

    private val appRepository = AppRepository(application)
    private val prefsRepository = PreferencesRepository(application)
    val workModeController = WorkModeController(application)

    private val _allApps = MutableStateFlow<List<AppEntry>>(emptyList())
    private val _mode = MutableStateFlow(LauncherMode.NORMAL)
    private val _drawerOpen = MutableStateFlow(false)
    private val _settingsOpen = MutableStateFlow(false)
    private val _searchQuery = MutableStateFlow("")
    private val _selectedApp = MutableStateFlow<AppEntry?>(null)
    private val _selectedShortcuts = MutableStateFlow<List<AppShortcutItem>>(emptyList())
    private val _lastLaunchedPkg = MutableStateFlow<String?>(null)
    private val _returnPulse = MutableStateFlow(0)
    private val _hwPrivacyActive = MutableStateFlow(false)
    private val _statusBanner = MutableStateFlow<String?>(null)

    private val baseState = combine(
        _allApps,
        prefsRepository.preferencesFlow,
        BadgeNotificationListenerService.badgeCounts,
        _mode,
        _searchQuery
    ) { apps, prefs, badges, mode, query ->
        val visible = apps.filter { it.packageName !in prefs.hiddenPackages }
        val configuredArc = if (mode == LauncherMode.NORMAL) {
            prefs.arcPackagesNormal
        } else {
            prefs.arcPackagesWork
        }

        val arcResolved = resolveArcApps(visible, configuredArc, mode)
        val filteredDrawer = if (query.isBlank()) {
            visible
        } else {
            visible.filter { it.label.contains(query.trim(), ignoreCase = true) }
        }

        val totalUnread = badges.values.sum()

        LauncherUiState(
            allApps = apps,
            visibleApps = filteredDrawer,
            arcApps = arcResolved,
            badgeCounts = badges,
            totalBadges = totalUnread,
            mode = mode,
            prefs = prefs,
            searchQuery = query
        )
    }

    val uiState: StateFlow<LauncherUiState> = combine(
        baseState,
        _drawerOpen,
        _settingsOpen,
        _selectedApp,
        _selectedShortcuts
    ) { state, drawer, settings, selected, shortcuts ->
        state.copy(
            isDrawerOpen = drawer,
            isSettingsOpen = settings,
            selectedAppForMenu = selected,
            selectedAppShortcuts = shortcuts
        )
    }.combine(_lastLaunchedPkg) { state, lastPkg ->
        state.copy(lastLaunchedPackage = lastPkg)
    }.combine(_returnPulse) { state, pulse ->
        state.copy(returnPulseToken = pulse)
    }.combine(_hwPrivacyActive) { state, hwPriv ->
        state.copy(hardwarePrivacyActive = hwPriv)
    }.combine(_statusBanner) { state, banner ->
        state.copy(statusBanner = banner)
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000),
        initialValue = LauncherUiState()
    )

    init {
        refreshApps()
        viewModelScope.launch {
            appRepository.observePackageChanges().collect {
                refreshApps()
            }
        }
    }

    fun refreshApps() {
        viewModelScope.launch {
            _allApps.value = appRepository.loadInstalledApps()
        }
    }

    fun toggleWorkMode() {
        val nextMode = if (_mode.value == LauncherMode.NORMAL) LauncherMode.WORK else LauncherMode.NORMAL
        _mode.value = nextMode
        val enabled = nextMode == LauncherMode.WORK

        val result = workModeController.setWorkMode(
            enabled = enabled,
            privacySettingKey = uiState.value.prefs.privacySettingKey
        )
        _hwPrivacyActive.value = enabled && result.hardwarePrivacyToggled
        showTemporaryBanner(result.statusMessage)
    }

    fun launchApp(app: AppEntry, anchorView: View?, sourceBounds: Rect?) {
        _lastLaunchedPkg.value = app.packageName
        _drawerOpen.value = false
        _searchQuery.value = ""
        _selectedApp.value = null
        appRepository.launchApp(app, anchorView, sourceBounds)
    }

    /**
     * Richiamato da MainActivity.onResume / onNewIntent quando si torna alla Home:
     * fa scattare l'animazione elastica di rientro sull'ultima icona aperta.
     */
    fun notifyReturnedHome() {
        if (_lastLaunchedPkg.value != null) {
            _returnPulse.value += 1
            viewModelScope.launch {
                delay(650)
                _lastLaunchedPkg.value = null
            }
        }
    }

    fun openDrawer() {
        _drawerOpen.value = true
    }

    fun closeDrawer() {
        _drawerOpen.value = false
        _searchQuery.value = ""
    }

    fun updateSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun openSettings() {
        _settingsOpen.value = true
    }

    fun closeSettings() {
        _settingsOpen.value = false
    }

    fun openAppContextMenu(app: AppEntry) {
        _selectedApp.value = app
        _selectedShortcuts.value = appRepository.getAppShortcuts(app)
    }

    fun closeAppContextMenu() {
        _selectedApp.value = null
        _selectedShortcuts.value = emptyList()
    }

    fun launchShortcut(shortcut: AppShortcutItem, bounds: Rect?) {
        closeAppContextMenu()
        appRepository.launchShortcut(shortcut, bounds)
    }

    fun openAppInfo(app: AppEntry) {
        closeAppContextMenu()
        appRepository.openAppInfo(app)
    }

    fun requestUninstall(app: AppEntry) {
        closeAppContextMenu()
        appRepository.requestUninstall(app)
    }

    fun togglePinInCurrentArc(app: AppEntry) {
        viewModelScope.launch {
            val mode = _mode.value
            val current = uiState.value.arcApps.map { it.packageName }.toMutableList()
            if (app.packageName in current) {
                current.remove(app.packageName)
                showTemporaryBanner("${app.label} rimossa dall'Arco")
            } else {
                if (current.size >= 5) {
                    current.removeAt(current.lastIndex)
                }
                current.add(0, app.packageName)
                showTemporaryBanner("${app.label} aggiunta all'Arco (${if (mode == LauncherMode.WORK) "Lavoro" else "Normale"})")
            }
            prefsRepository.setArcPackages(mode, current)
            closeAppContextMenu()
        }
    }

    fun toggleHideApp(app: AppEntry) {
        viewModelScope.launch {
            prefsRepository.toggleHiddenPackage(app.packageName)
            closeAppContextMenu()
            showTemporaryBanner("Visibilita aggiornata per ${app.label}")
        }
    }

    fun setHandedness(handedness: Handedness) {
        viewModelScope.launch { prefsRepository.setHandedness(handedness) }
    }

    fun setMonochromeIcons(enabled: Boolean) {
        viewModelScope.launch { prefsRepository.setMonochromeIcons(enabled) }
    }

    fun setDoubleTapToLock(enabled: Boolean) {
        viewModelScope.launch { prefsRepository.setDoubleTapToLock(enabled) }
    }

    fun setAutoFocusSearch(enabled: Boolean) {
        viewModelScope.launch { prefsRepository.setAutoFocusSearch(enabled) }
    }

    fun setAmoledWorkBackground(enabled: Boolean) {
        viewModelScope.launch { prefsRepository.setAmoledWorkBackground(enabled) }
    }

    fun setPrivacyFallbackDimmer(enabled: Boolean) {
        viewModelScope.launch { prefsRepository.setPrivacyFallbackDimmer(enabled) }
    }

    fun setPrivacySettingKey(key: String) {
        viewModelScope.launch { prefsRepository.setPrivacySettingKey(key) }
    }

    fun showTemporaryBanner(text: String) {
        _statusBanner.value = text
        viewModelScope.launch {
            delay(3200)
            if (_statusBanner.value == text) {
                _statusBanner.value = null
            }
        }
    }

    private fun resolveArcApps(
        visibleApps: List<AppEntry>,
        configured: List<String>,
        mode: LauncherMode
    ): List<AppEntry> {
        val byPkg = visibleApps.associateBy { it.packageName }
        val resolved = configured.mapNotNull { byPkg[it] }.toMutableList()
        if (resolved.size >= 5) return resolved.take(5)

        // Default intelligenti per dispositivi Samsung Galaxy
        val preferredDefaults = if (mode == LauncherMode.WORK) {
            listOf(
                "com.samsung.android.dialer",
                "com.whatsapp",
                "com.samsung.android.calendar",
                "com.samsung.android.app.notes",
                "com.google.android.gm",
                "com.microsoft.teams"
            )
        } else {
            listOf(
                "com.samsung.android.dialer",
                "com.whatsapp",
                "com.sec.android.app.camera",
                "com.sec.android.app.sbrowser",
                "com.android.chrome",
                "com.spotify.music",
                "com.sec.android.gallery3d"
            )
        }

        for (pkg in preferredDefaults) {
            if (resolved.size >= 5) break
            val candidate = byPkg[pkg]
            if (candidate != null && resolved.none { it.packageName == pkg }) {
                resolved += candidate
            }
        }

        for (app in visibleApps) {
            if (resolved.size >= 5) break
            if (resolved.none { it.packageName == app.packageName }) {
                resolved += app
            }
        }
        return resolved.take(5)
    }
}
