package com.onearc.launcher.service

import android.app.Notification
import android.content.ComponentName
import android.content.Context
import android.provider.Settings
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Servizio ultra-leggero dedicato ESCLUSIVAMENTE ai contatori badge delle icone.
 * Non sostituisce ne interferisce con altre app di gestione notifiche:
 * legge soltanto quante notifiche attive ha ciascun package.
 */
class BadgeNotificationListenerService : NotificationListenerService() {

    override fun onListenerConnected() {
        super.onListenerConnected()
        _isConnected.value = true
        recalculateBadges()
    }

    override fun onListenerDisconnected() {
        super.onListenerDisconnected()
        _isConnected.value = false
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        recalculateBadges()
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification?) {
        recalculateBadges()
    }

    private fun recalculateBadges() {
        val active = try {
            activeNotifications ?: emptyArray()
        } catch (_: Exception) {
            emptyArray()
        }

        val counts = mutableMapOf<String, Int>()
        for (sbn in active) {
            val notification = sbn.notification ?: continue

            // Ignora i contenitori di gruppo per non raddoppiare il conteggio
            if ((notification.flags and Notification.FLAG_GROUP_SUMMARY) != 0) continue

            // Ignora servizi permanenti di sistema (es. VPN, musica persistente) per badge puliti
            if ((notification.flags and Notification.FLAG_ONGOING_EVENT) != 0) continue

            val pkg = sbn.packageName ?: continue
            val weight = if (notification.number > 1) notification.number else 1
            counts[pkg] = (counts[pkg] ?: 0) + weight
        }

        _badgeCounts.value = counts
    }

    companion object {
        private val _badgeCounts = MutableStateFlow<Map<String, Int>>(emptyMap())
        val badgeCounts: StateFlow<Map<String, Int>> = _badgeCounts.asStateFlow()

        private val _isConnected = MutableStateFlow(false)
        val isConnected: StateFlow<Boolean> = _isConnected.asStateFlow()

        fun isPermissionGranted(context: Context): Boolean {
            val flat = Settings.Secure.getString(
                context.contentResolver,
                "enabled_notification_listeners"
            ) ?: return false
            val expected = ComponentName(context, BadgeNotificationListenerService::class.java)
            return flat.contains(expected.flattenToString()) || flat.contains(expected.flattenToShortString())
        }
    }
}
