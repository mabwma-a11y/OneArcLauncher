package com.onearc.launcher.ui.components

import android.content.Context
import android.content.Intent
import android.provider.Settings
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Palette
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.onearc.launcher.data.Handedness
import com.onearc.launcher.data.LauncherPrefs
import com.onearc.launcher.service.BadgeNotificationListenerService
import com.onearc.launcher.service.OneArcAccessibilityService
import com.onearc.launcher.system.WorkModeController
import com.onearc.launcher.ui.theme.ExpressiveShapes
import com.onearc.launcher.ui.theme.LocalLedPalette

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsSheet(
    prefs: LauncherPrefs,
    isDefaultLauncher: Boolean,
    workModeController: WorkModeController,
    onRequestDefaultLauncher: () -> Unit,
    onOpenIconStudio: () -> Unit,
    onHandednessChange: (Handedness) -> Unit,
    onDoubleTapLockChange: (Boolean) -> Unit,
    onAutoFocusSearchChange: (Boolean) -> Unit,
    onAmoledWorkChange: (Boolean) -> Unit,
    onPrivacyDimmerChange: (Boolean) -> Unit,
    onPrivacyKeyChange: (String) -> Unit,
    onAskDefaultOnStartChange: (Boolean) -> Unit,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val led = LocalLedPalette.current
    val badgePerm = remember(prefs) { BadgeNotificationListenerService.isPermissionGranted(context) }
    val policyPerm = remember(prefs) { workModeController.hasNotificationPolicyAccess() }
    val accessibilityPerm = remember(prefs) { OneArcAccessibilityService.isEnabled(context) }
    val secureSettingsPerm = remember(prefs) { workModeController.hasWriteSecureSettings() }
    var privacyKeyText by remember(prefs.privacySettingKey) { mutableStateOf(prefs.privacySettingKey) }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        shape = ExpressiveShapes.SheetTop,
        containerColor = Color(0xFF080B13)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 22.dp, vertical = 10.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Text(
                text = "Impostazioni OneArc",
                style = MaterialTheme.typography.headlineMedium,
                color = Color.White
            )

            // Accesso rapido a Icon & LED Studio
            Button(
                onClick = {
                    onDismiss()
                    onOpenIconStudio()
                },
                shape = ExpressiveShapes.Pill,
                colors = ButtonDefaults.buttonColors(
                    containerColor = led.primary,
                    contentColor = Color(0xFF041018)
                ),
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(Icons.Rounded.Palette, contentDescription = null)
                Spacer(modifier = Modifier.padding(horizontal = 4.dp))
                Text("Apri Icon & LED Studio", style = MaterialTheme.typography.labelLarge)
            }

            // Launcher Predefinito integrato
            PermissionActionCard(
                title = "Launcher predefinito",
                status = if (isDefaultLauncher) "OneArc e gia impostato come Home" else "Tocca per impostare OneArc subito",
                buttonLabel = if (isDefaultLauncher) "Cambia" else "Imposta",
                prefs = prefs,
                onClick = onRequestDefaultLauncher
            )

            SettingToggleRow(
                title = "Chiedi all'apertura se non predefinito",
                subtitle = "Mostra il selettore integrato quando apri OneArc",
                checked = prefs.askDefaultLauncherOnStart,
                onCheckedChange = onAskDefaultOnStartChange
            )

            HorizontalDivider(color = Color.White.copy(alpha = 0.1f))

            Text(
                text = "Ergonomia monomano",
                style = MaterialTheme.typography.labelLarge,
                color = led.primary
            )
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                FilterChip(
                    selected = prefs.handedness == Handedness.RIGHT,
                    onClick = { onHandednessChange(Handedness.RIGHT) },
                    label = { Text("Destrimano") }
                )
                FilterChip(
                    selected = prefs.handedness == Handedness.LEFT,
                    onClick = { onHandednessChange(Handedness.LEFT) },
                    label = { Text("Mancino") }
                )
            }

            HorizontalDivider(color = Color.White.copy(alpha = 0.1f))

            Text(
                text = "Gesture & Modalita Lavoro",
                style = MaterialTheme.typography.labelLarge,
                color = led.primary
            )
            SettingToggleRow(
                title = "Sfondo nero AMOLED in Lavoro",
                subtitle = "Mantiene i LED accesi su nero assoluto Galaxy",
                checked = prefs.amoledWorkBackground,
                onCheckedChange = onAmoledWorkChange
            )
            SettingToggleRow(
                title = "Filtro Privacy software di riserva",
                subtitle = "Oscura discretamente la Home se Privacy Display hardware non e autorizzato",
                checked = prefs.privacyFallbackDimmer,
                onCheckedChange = onPrivacyDimmerChange
            )
            SettingToggleRow(
                title = "Doppio tap per bloccare schermo",
                subtitle = "Richiede il servizio di accessibilita OneArc",
                checked = prefs.doubleTapToLock,
                onCheckedChange = onDoubleTapLockChange
            )
            SettingToggleRow(
                title = "Apri tastiera nel drawer",
                subtitle = "Ricerca immediata appena fai swipe verso l'alto",
                checked = prefs.autoFocusSearch,
                onCheckedChange = onAutoFocusSearchChange
            )

            HorizontalDivider(color = Color.White.copy(alpha = 0.1f))

            Text(
                text = "Permessi di sistema",
                style = MaterialTheme.typography.labelLarge,
                color = led.primary
            )
            PermissionActionCard(
                title = "Accesso notifiche (solo contatore badge)",
                status = if (badgePerm) "Attivo" else "Richiesto per i numeri/LED sulle icone",
                buttonLabel = if (badgePerm) "Gestisci" else "Consenti",
                prefs = prefs,
                onClick = { openSafeSettings(context, Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS) }
            )
            PermissionActionCard(
                title = "Accesso Non Disturbare / Vibrazione",
                status = if (policyPerm) "Attivo" else "Per passaggio automatico in Vibrazione",
                buttonLabel = if (policyPerm) "Gestisci" else "Consenti",
                prefs = prefs,
                onClick = { openSafeSettings(context, Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS) }
            )
            PermissionActionCard(
                title = "Servizio Gesture (Tendina e Blocco)",
                status = if (accessibilityPerm) "Attivo" else "Per swipe giu e doppio tap blocco",
                buttonLabel = if (accessibilityPerm) "Gestisci" else "Attiva",
                prefs = prefs,
                onClick = { openSafeSettings(context, Settings.ACTION_ACCESSIBILITY_SETTINGS) }
            )

            HorizontalDivider(color = Color.White.copy(alpha = 0.1f))

            Text(
                text = "Galaxy Privacy Display (Modalita Lavoro)",
                style = MaterialTheme.typography.labelLarge,
                color = led.primary
            )
            Text(
                text = if (secureSettingsPerm) {
                    "Permesso WRITE_SECURE_SETTINGS attivo: toggle hardware diretto abilitato."
                } else {
                    "Puoi collegare una Routine Samsung su com.onearc.launcher.ACTION_WORK_MODE_CHANGED oppure concedere WRITE_SECURE_SETTINGS via ADB/Shizuku."
                },
                style = MaterialTheme.typography.bodySmall,
                color = Color.White.copy(alpha = 0.65f)
            )
            OutlinedTextField(
                value = privacyKeyText,
                onValueChange = {
                    privacyKeyText = it
                    onPrivacyKeyChange(it)
                },
                label = { Text("Chiave Samsung Settings (avanzato)") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(20.dp))
        }
    }
}

@Composable
private fun SettingToggleRow(
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column(modifier = Modifier.weight(1f).padding(end = 12.dp)) {
            Text(text = title, style = MaterialTheme.typography.titleMedium, color = Color.White)
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = Color.White.copy(alpha = 0.65f)
            )
        }
        Switch(checked = checked, onCheckedChange = onCheckedChange)
    }
}

@Composable
private fun PermissionActionCard(
    title: String,
    status: String,
    buttonLabel: String,
    prefs: LauncherPrefs,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .ledGlassSurface(
                shape = ExpressiveShapes.CardExpressive,
                glassOpacity = 0.72f,
                borderWidth = 1.2.dp,
                glowIntensity = prefs.ledGlowIntensity * 0.55f,
                animationMode = prefs.ledAnimationMode
            )
            .padding(horizontal = 16.dp, vertical = 12.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1f).padding(end = 10.dp)) {
                Text(text = title, style = MaterialTheme.typography.labelLarge, color = Color.White)
                Text(
                    text = status,
                    style = MaterialTheme.typography.bodySmall,
                    color = Color.White.copy(alpha = 0.65f)
                )
            }
            FilledTonalButton(onClick = onClick) {
                Text(buttonLabel)
            }
        }
    }
}

private fun openSafeSettings(context: Context, action: String) {
    runCatching {
        val intent = Intent(action).apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) }
        context.startActivity(intent)
    }
}
