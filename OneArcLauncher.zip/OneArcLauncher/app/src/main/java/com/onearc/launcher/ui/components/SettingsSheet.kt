package com.onearc.launcher.ui.components

import android.content.Context
import android.content.Intent
import android.provider.Settings
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.onearc.launcher.data.Handedness
import com.onearc.launcher.data.LauncherPrefs
import com.onearc.launcher.service.BadgeNotificationListenerService
import com.onearc.launcher.service.OneArcAccessibilityService
import com.onearc.launcher.system.WorkModeController
import com.onearc.launcher.ui.theme.ExpressiveShapes

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsSheet(
    prefs: LauncherPrefs,
    workModeController: WorkModeController,
    onHandednessChange: (Handedness) -> Unit,
    onMonochromeChange: (Boolean) -> Unit,
    onDoubleTapLockChange: (Boolean) -> Unit,
    onAutoFocusSearchChange: (Boolean) -> Unit,
    onAmoledWorkChange: (Boolean) -> Unit,
    onPrivacyDimmerChange: (Boolean) -> Unit,
    onPrivacyKeyChange: (String) -> Unit,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val badgePerm = remember(prefs) { BadgeNotificationListenerService.isPermissionGranted(context) }
    val policyPerm = remember(prefs) { workModeController.hasNotificationPolicyAccess() }
    val accessibilityPerm = remember(prefs) { OneArcAccessibilityService.isEnabled(context) }
    val secureSettingsPerm = remember(prefs) { workModeController.hasWriteSecureSettings() }
    var privacyKeyText by remember(prefs.privacySettingKey) { mutableStateOf(prefs.privacySettingKey) }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        shape = ExpressiveShapes.SheetTop,
        containerColor = MaterialTheme.colorScheme.surfaceContainer
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 22.dp, vertical = 10.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Text(
                text = "Impostazioni OneArc",
                style = MaterialTheme.typography.headlineMedium
            )

            // Ergonomia mano
            Text(
                text = "Ergonomia monomano",
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.primary
            )
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                FilterChip(
                    selected = prefs.handedness == Handedness.RIGHT,
                    onClick = { onHandednessChange(Handedness.RIGHT) },
                    label = { Text("Destrimano") }
                )
                FilterChip(
                    selected = prefs.handedness == Handedness.LEFT,
                    onClick = { onHandednessChange(Handedness.LEFT) },
                    label = { Text("Mancino") }
                )
            }

            HorizontalDivider()

            // Interruttori moderni
            Text(
                text = "Stile & Gesture",
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.primary
            )
            SettingToggleRow(
                title = "Icone monocromatiche",
                subtitle = "Minimalismo visivo coordinato con Material 3",
                checked = prefs.monochromeIcons,
                onCheckedChange = onMonochromeChange
            )
            SettingToggleRow(
                title = "Sfondo nero AMOLED in Lavoro",
                subtitle = "Riduce distrazioni e consumi sul pannello Galaxy",
                checked = prefs.amoledWorkBackground,
                onCheckedChange = onAmoledWorkChange
            )
            SettingToggleRow(
                title = "Filtro Privacy software di riserva",
                subtitle = "Oscura discretamente la home se Privacy Display hardware non e autorizzato",
                checked = prefs.privacyFallbackDimmer,
                onCheckedChange = onPrivacyDimmerChange
            )
            SettingToggleRow(
                title = "Doppio tap per bloccare schermo",
                subtitle = "Richiede il servizio di accessibilita OneArc",
                checked = prefs.doubleTapToLock,
                onCheckedChange = onDoubleTapLockChange
            )
            SettingToggleRow(
                title = "Apri tastiera nel drawer",
                subtitle = "Ricerca immediata appena fai swipe verso l'alto",
                checked = prefs.autoFocusSearch,
                onCheckedChange = onAutoFocusSearchChange
            )

            HorizontalDivider()

            // Permessi Android / Galaxy
            Text(
                text = "Permessi di sistema",
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.primary
            )

            PermissionActionCard(
                title = "Imposta come Launcher predefinito",
                status = "Abilita animazioni Home & App Shortcuts",
                buttonLabel = "Apri Home",
                onClick = { openSafeSettings(context, Settings.ACTION_HOME_SETTINGS) }
            )
            PermissionActionCard(
                title = "Accesso notifiche (solo contatore badge)",
                status = if (badgePerm) "Attivo" else "Richiesto per i numeri sulle icone",
                buttonLabel = if (badgePerm) "Gestisci" else "Consenti",
                onClick = { openSafeSettings(context, Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS) }
            )
            PermissionActionCard(
                title = "Accesso Non Disturbare / Vibrazione",
                status = if (policyPerm) "Attivo" else "Consigliato per cambio profilo Lavoro",
                buttonLabel = if (policyPerm) "Gestisci" else "Consenti",
                onClick = { openSafeSettings(context, Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS) }
            )
            PermissionActionCard(
                title = "Servizio Gesture (Tendina e Blocco)",
                status = if (accessibilityPerm) "Attivo" else "Per swipe giu e doppio tap blocco",
                buttonLabel = if (accessibilityPerm) "Gestisci" else "Attiva",
                onClick = { openSafeSettings(context, Settings.ACTION_ACCESSIBILITY_SETTINGS) }
            )

            HorizontalDivider()

            // Configurazione Galaxy Privacy Display
            Text(
                text = "Galaxy Privacy Display (Modalita Lavoro)",
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.primary
            )
            Text(
                text = if (secureSettingsPerm) {
                    "Permesso WRITE_SECURE_SETTINGS attivo: OneArc tentera il toggle diretto hardware."
                } else {
                    "Su Galaxy con Privacy Display hardware puoi: (1) collegare una Routine Samsung sull'intent com.onearc.launcher.ACTION_WORK_MODE_CHANGED, oppure (2) concedere WRITE_SECURE_SETTINGS via ADB/Shizuku."
                },
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            OutlinedTextField(
                value = privacyKeyText,
                onValueChange = {
                    privacyKeyText = it
                    onPrivacyKeyChange(it)
                },
                label = { Text("Chiave Samsung Settings (avanzato)") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(20.dp))
        }
    }
}

@Composable
private fun SettingToggleRow(
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column(modifier = Modifier.weight(1f).padding(end = 12.dp)) {
            Text(text = title, style = MaterialTheme.typography.titleMedium)
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        Switch(checked = checked, onCheckedChange = onCheckedChange)
    }
}

@Composable
private fun PermissionActionCard(
    title: String,
    status: String,
    buttonLabel: String,
    onClick: () -> Unit
) {
    Surface(
        shape = ExpressiveShapes.CardExpressive,
        color = MaterialTheme.colorScheme.surfaceContainerHigh,
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1f).padding(end = 10.dp)) {
                Text(text = title, style = MaterialTheme.typography.labelLarge)
                Text(
                    text = status,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            FilledTonalButton(onClick = onClick) {
                Text(buttonLabel)
            }
        }
    }
}

private fun openSafeSettings(context: Context, action: String) {
    runCatching {
        val intent = Intent(action).apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) }
        context.startActivity(intent)
    }
}
