package com.onearc.launcher.data

import android.app.ActivityOptions
import android.content.Context
import android.content.Intent
import android.content.pm.LauncherActivityInfo
import android.content.pm.LauncherApps
import android.content.pm.ShortcutInfo
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Rect
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import android.net.Uri
import android.os.UserHandle
import android.os.UserManager
import android.provider.Settings
import android.util.LruCache
import android.view.View
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

class AppRepository(private val context: Context) {

    private val launcherApps = context.getSystemService(Context.LAUNCHER_APPS_SERVICE) as LauncherApps
    private val userManager = context.getSystemService(Context.USER_SERVICE) as UserManager
    private val iconPackManager = IconPackManager(context)
    private val iconCache = LruCache<String, ImageBitmap>(220)

    suspend fun getInstalledIconPacks(): List<IconPackInfo> = withContext(Dispatchers.IO) {
        iconPackManager.getInstalledIconPacks()
    }

    fun clearIconCache() {
        iconCache.evictAll()
    }

    suspend fun loadInstalledApps(
        iconPackPackage: String,
        customizations: Map<String, AppCustomization>
    ): List<AppEntry> = withContext(Dispatchers.IO) {
        iconPackManager.loadPack(iconPackPackage)
        val result = mutableListOf<AppEntry>()
        val profiles = userManager.userProfiles

        for (profile in profiles) {
            val activities: List<LauncherActivityInfo> = try {
                launcherApps.getActivityList(null, profile)
            } catch (_: Exception) {
                emptyList()
            }

            for (info in activities) {
                val pkg = info.componentName.packageName
                if (pkg == context.packageName) continue

                val custom = customizations[pkg]
                val effectiveLabel = custom?.customLabel?.takeIf { it.isNotBlank() }
                    ?: info.label?.toString()
                    ?: pkg

                val cacheKey = "${info.componentName.flattenToShortString()}_${profile.hashCode()}_${iconPackPackage}_${custom?.iconType}_${custom?.iconValue}"
                val resolvedIcon = iconCache.get(cacheKey) ?: run {
                    val bmp = when (custom?.iconType) {
                        CustomIconType.GALLERY_IMAGE -> {
                            custom.iconValue?.let { loadCustomBitmap(it) }
                                ?: loadSystemOrPackIcon(info, iconPackPackage)
                        }
                        CustomIconType.MINIMAL_GLYPH -> null
                        else -> loadSystemOrPackIcon(info, iconPackPackage)
                    }
                    bmp?.also { iconCache.put(cacheKey, it) }
                }

                result += AppEntry(
                    packageName = pkg,
                    activityName = info.componentName.className,
                    label = effectiveLabel,
                    componentName = info.componentName,
                    userHandle = profile,
                    icon = resolvedIcon,
                    customGlyphKey = if (custom?.iconType == CustomIconType.MINIMAL_GLYPH) custom.iconValue else null,
                    customLedColorArgb = custom?.customLedColorArgb
                )
            }
        }

        result.sortedBy { it.label.lowercase() }
    }

    private fun loadSystemOrPackIcon(info: LauncherActivityInfo, iconPackPackage: String): ImageBitmap? {
        val packDrawable = if (iconPackPackage.isNotBlank()) {
            iconPackManager.getIconDrawable(info.componentName)
        } else {
            null
        }
        val drawable = packDrawable ?: info.getBadgedIcon(0)
        return drawableToImageBitmap(drawable)
    }

    /**
     * Salva un'immagine dalla galleria nella cartella privata dell'app (192x192 PNG)
     * cosi l'icona personalizzata resta sempre disponibile anche dopo il riavvio del Galaxy.
     */
    suspend fun saveCustomIconFromUri(packageName: String, uri: Uri): String? = withContext(Dispatchers.IO) {
        runCatching {
            val dir = File(context.filesDir, "custom_icons").apply { mkdirs() }
            val outFile = File(dir, "${packageName.replace('.', '_')}_${System.currentTimeMillis()}.png")

            // Pulisce eventuali vecchie icone della stessa app
            dir.listFiles()?.filter { it.name.startsWith("${packageName.replace('.', '_')}_") }?.forEach {
                it.delete()
            }

            val input = context.contentResolver.openInputStream(uri) ?: return@runCatching null
            val raw = input.use { BitmapFactory.decodeStream(it) } ?: return@runCatching null
            val square = centerCropAndScale(raw, 192)
            FileOutputStream(outFile).use { fos ->
                square.compress(Bitmap.CompressFormat.PNG, 95, fos)
            }
            if (square != raw) raw.recycle()
            iconCache.evictAll()
            outFile.absolutePath
        }.getOrNull()
    }

    private fun loadCustomBitmap(path: String): ImageBitmap? {
        return runCatching {
            val file = File(path)
            if (!file.exists()) return null
            BitmapFactory.decodeFile(file.absolutePath)?.asImageBitmap()
        }.getOrNull()
    }

    private fun centerCropAndScale(source: Bitmap, targetSize: Int): Bitmap {
        val minEdge = minOf(source.width, source.height)
        val x = (source.width - minEdge) / 2
        val y = (source.height - minEdge) / 2
        val cropped = Bitmap.createBitmap(source, x, y, minEdge, minEdge)
        val scaled = Bitmap.createScaledBitmap(cropped, targetSize, targetSize, true)
        if (cropped != source && cropped != scaled) cropped.recycle()
        return scaled
    }

    fun observePackageChanges(): Flow<Unit> = callbackFlow {
        val callback = object : LauncherApps.Callback() {
            override fun onPackageRemoved(packageName: String?, user: UserHandle?) {
                iconCache.evictAll()
                trySend(Unit)
            }

            override fun onPackageAdded(packageName: String?, user: UserHandle?) {
                trySend(Unit)
            }

            override fun onPackageChanged(packageName: String?, user: UserHandle?) {
                iconCache.evictAll()
                trySend(Unit)
            }

            override fun onPackagesAvailable(packageNames: Array<out String>?, user: UserHandle?, replacing: Boolean) {
                trySend(Unit)
            }

            override fun onPackagesUnavailable(packageNames: Array<out String>?, user: UserHandle?, replacing: Boolean) {
                trySend(Unit)
            }
        }

        launcherApps.registerCallback(callback)
        awaitClose {
            launcherApps.unregisterCallback(callback)
        }
    }

    fun launchApp(
        app: AppEntry,
        anchorView: View?,
        sourceBounds: Rect?
    ) {
        val optionsBundle = when {
            anchorView != null && sourceBounds != null && sourceBounds.width() > 0 && sourceBounds.height() > 0 -> {
                val loc = IntArray(2)
                anchorView.getLocationOnScreen(loc)
                val startX = (sourceBounds.left - loc[0]).coerceAtLeast(0)
                val startY = (sourceBounds.top - loc[1]).coerceAtLeast(0)
                ActivityOptions.makeClipRevealAnimation(
                    anchorView,
                    startX,
                    startY,
                    sourceBounds.width(),
                    sourceBounds.height()
                ).toBundle()
            }
            anchorView != null -> {
                ActivityOptions.makeScaleUpAnimation(
                    anchorView,
                    anchorView.width / 2,
                    anchorView.height / 2,
                    0,
                    0
                ).toBundle()
            }
            else -> null
        }

        try {
            launcherApps.startMainActivity(
                app.componentName,
                app.userHandle,
                sourceBounds,
                optionsBundle
            )
        } catch (_: Exception) {
            val fallback = context.packageManager.getLaunchIntentForPackage(app.packageName)
            fallback?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            if (fallback != null) {
                context.startActivity(fallback, optionsBundle)
            }
        }
    }

    fun getAppShortcuts(app: AppEntry): List<AppShortcutItem> {
        if (!launcherApps.hasShortcutHostPermission()) return emptyList()
        return try {
            val query = LauncherApps.ShortcutQuery().apply {
                setPackage(app.packageName)
                setQueryFlags(
                    LauncherApps.ShortcutQuery.FLAG_MATCH_DYNAMIC or
                        LauncherApps.ShortcutQuery.FLAG_MATCH_MANIFEST or
                        LauncherApps.ShortcutQuery.FLAG_MATCH_PINNED
                )
            }
            val list: List<ShortcutInfo> = launcherApps.getShortcuts(query, app.userHandle).orEmpty()
            list.take(4).map { info ->
                AppShortcutItem(
                    id = info.id,
                    label = (info.shortLabel ?: info.longLabel ?: info.id).toString(),
                    shortcutInfo = info
                )
            }
        } catch (_: Exception) {
            emptyList()
        }
    }

    fun launchShortcut(shortcut: AppShortcutItem, sourceBounds: Rect?) {
        runCatching {
            launcherApps.startShortcut(shortcut.shortcutInfo, sourceBounds, null)
        }
    }

    fun openAppInfo(app: AppEntry) {
        try {
            launcherApps.startAppDetailsActivity(app.componentName, app.userHandle, null, null)
        } catch (_: Exception) {
            val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                data = Uri.fromParts("package", app.packageName, null)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        }
    }

    fun requestUninstall(app: AppEntry) {
        val intent = Intent(Intent.ACTION_DELETE).apply {
            data = Uri.parse("package:${app.packageName}")
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(intent)
    }

    private fun drawableToImageBitmap(drawable: Drawable, sizePx: Int = 160): ImageBitmap? {
        return try {
            if (drawable is BitmapDrawable && drawable.bitmap != null && !drawable.bitmap.isRecycled) {
                Bitmap.createScaledBitmap(drawable.bitmap, sizePx, sizePx, true).asImageBitmap()
            } else {
                val bitmap = Bitmap.createBitmap(sizePx, sizePx, Bitmap.Config.ARGB_8888)
                val canvas = Canvas(bitmap)
                drawable.setBounds(0, 0, canvas.width, canvas.height)
                drawable.draw(canvas)
                bitmap.asImageBitmap()
            }
        } catch (_: Exception) {
            null
        }
    }
}
