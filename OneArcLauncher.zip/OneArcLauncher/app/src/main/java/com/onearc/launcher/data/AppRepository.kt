package com.onearc.launcher.data

import android.app.ActivityOptions
import android.content.Context
import android.content.Intent
import android.content.pm.LauncherActivityInfo
import android.content.pm.LauncherApps
import android.content.pm.ShortcutInfo
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Rect
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import android.net.Uri
import android.os.Build
import android.os.UserHandle
import android.os.UserManager
import android.provider.Settings
import android.util.LruCache
import android.view.View
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.withContext

class AppRepository(private val context: Context) {

    private val launcherApps = context.getSystemService(Context.LAUNCHER_APPS_SERVICE) as LauncherApps
    private val userManager = context.getSystemService(Context.USER_SERVICE) as UserManager
    private val iconCache = LruCache<String, ImageBitmap>(180)

    suspend fun loadInstalledApps(): List<AppEntry> = withContext(Dispatchers.IO) {
        val result = mutableListOf<AppEntry>()
        val profiles = userManager.userProfiles

        for (profile in profiles) {
            val activities: List<LauncherActivityInfo> = try {
                launcherApps.getActivityList(null, profile)
            } catch (_: Exception) {
                emptyList()
            }

            for (info in activities) {
                val pkg = info.componentName.packageName
                if (pkg == context.packageName) continue

                val cacheKey = "${info.componentName.flattenToShortString()}_${profile.hashCode()}"
                val cachedIcon = iconCache.get(cacheKey) ?: run {
                    val drawable = info.getBadgedIcon(0)
                    drawableToImageBitmap(drawable)?.also { iconCache.put(cacheKey, it) }
                }

                result += AppEntry(
                    packageName = pkg,
                    activityName = info.componentName.className,
                    label = info.label?.toString() ?: pkg,
                    componentName = info.componentName,
                    userHandle = profile,
                    icon = cachedIcon
                )
            }
        }

        result.sortedBy { it.label.lowercase() }
    }

    /**
     * Osserva installazioni, disinstallazioni e aggiornamenti in tempo reale.
     */
    fun observePackageChanges(): Flow<Unit> = callbackFlow {
        val callback = object : LauncherApps.Callback() {
            override fun onPackageRemoved(packageName: String?, user: UserHandle?) {
                iconCache.evictAll()
                trySend(Unit)
            }

            override fun onPackageAdded(packageName: String?, user: UserHandle?) {
                trySend(Unit)
            }

            override fun onPackageChanged(packageName: String?, user: UserHandle?) {
                iconCache.evictAll()
                trySend(Unit)
            }

            override fun onPackagesAvailable(packageNames: Array<out String>?, user: UserHandle?, replacing: Boolean) {
                trySend(Unit)
            }

            override fun onPackagesUnavailable(packageNames: Array<out String>?, user: UserHandle?, replacing: Boolean) {
                trySend(Unit)
            }
        }

        launcherApps.registerCallback(callback)
        awaitClose {
            launcherApps.unregisterCallback(callback)
        }
    }

    /**
     * Avvia un'app sfruttando le coordinate esatte dell'icona sullo schermo:
     * Android / Samsung One UI espande la finestra partendo dal rettangolo dell'icona
     * e usa gli stessi bounds per la transizione di ritorno alla Home.
     */
    fun launchApp(
        app: AppEntry,
        anchorView: View?,
        sourceBounds: Rect?
    ) {
        val optionsBundle = when {
            anchorView != null && sourceBounds != null && sourceBounds.width() > 0 && sourceBounds.height() > 0 -> {
                val loc = IntArray(2)
                anchorView.getLocationOnScreen(loc)
                val startX = (sourceBounds.left - loc[0]).coerceAtLeast(0)
                val startY = (sourceBounds.top - loc[1]).coerceAtLeast(0)
                ActivityOptions.makeClipRevealAnimation(
                    anchorView,
                    startX,
                    startY,
                    sourceBounds.width(),
                    sourceBounds.height()
                ).toBundle()
            }
            anchorView != null -> {
                ActivityOptions.makeScaleUpAnimation(
                    anchorView,
                    anchorView.width / 2,
                    anchorView.height / 2,
                    0,
                    0
                ).toBundle()
            }
            else -> null
        }

        try {
            launcherApps.startMainActivity(
                app.componentName,
                app.userHandle,
                sourceBounds,
                optionsBundle
            )
        } catch (_: Exception) {
            val fallback = context.packageManager.getLaunchIntentForPackage(app.packageName)
            fallback?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            if (fallback != null) {
                context.startActivity(fallback, optionsBundle)
            }
        }
    }

    /**
     * Recupera le azioni rapide (App Shortcuts) quando OneArc e il launcher predefinito.
     */
    fun getAppShortcuts(app: AppEntry): List<AppShortcutItem> {
        if (!launcherApps.hasShortcutHostPermission()) return emptyList()
        return try {
            val query = LauncherApps.ShortcutQuery().apply {
                setPackage(app.packageName)
                setQueryFlags(
                    LauncherApps.ShortcutQuery.FLAG_MATCH_DYNAMIC or
                        LauncherApps.ShortcutQuery.FLAG_MATCH_MANIFEST or
                        LauncherApps.ShortcutQuery.FLAG_MATCH_PINNED
                )
            }
            val list: List<ShortcutInfo> = launcherApps.getShortcuts(query, app.userHandle).orEmpty()
            list.take(4).map { info ->
                AppShortcutItem(
                    id = info.id,
                    label = (info.shortLabel ?: info.longLabel ?: info.id).toString(),
                    shortcutInfo = info
                )
            }
        } catch (_: Exception) {
            emptyList()
        }
    }

    fun launchShortcut(shortcut: AppShortcutItem, sourceBounds: Rect?) {
        try {
            launcherApps.startShortcut(shortcut.shortcutInfo, sourceBounds, null)
        } catch (_: Exception) {
            // Ignora se lo shortcut non e piu valido
        }
    }

    fun openAppInfo(app: AppEntry) {
        try {
            launcherApps.startAppDetailsActivity(app.componentName, app.userHandle, null, null)
        } catch (_: Exception) {
            val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                data = Uri.fromParts("package", app.packageName, null)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        }
    }

    fun requestUninstall(app: AppEntry) {
        val intent = Intent(Intent.ACTION_DELETE).apply {
            data = Uri.parse("package:${app.packageName}")
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(intent)
    }

    private fun drawableToImageBitmap(drawable: Drawable, sizePx: Int = 144): ImageBitmap? {
        return try {
            if (drawable is BitmapDrawable && drawable.bitmap != null && !drawable.bitmap.isRecycled) {
                val bmp = Bitmap.createScaledBitmap(drawable.bitmap, sizePx, sizePx, true)
                bmp.asImageBitmap()
            } else {
                val bitmap = Bitmap.createBitmap(sizePx, sizePx, Bitmap.Config.ARGB_8888)
                val canvas = Canvas(bitmap)
                drawable.setBounds(0, 0, canvas.width, canvas.height)
                drawable.draw(canvas)
                bitmap.asImageBitmap()
            }
        } catch (_: Exception) {
            null
        }
    }
}
