package com.onearc.launcher.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import org.json.JSONObject

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "onearc_led_prefs")

class PreferencesRepository(private val context: Context) {

    private object Keys {
        val HANDEDNESS = stringPreferencesKey("handedness")
        val ARC_NORMAL = stringPreferencesKey("arc_normal_csv")
        val ARC_WORK = stringPreferencesKey("arc_work_csv")
        val HIDDEN_APPS = stringSetPreferencesKey("hidden_apps")
        val ARC_ICON_COUNT = intPreferencesKey("arc_icon_count")
        val ARC_CURVATURE = floatPreferencesKey("arc_curvature_dp")

        val LED_ANIMATION = stringPreferencesKey("led_animation_mode")
        val LED_GLOW = floatPreferencesKey("led_glow_intensity")
        val LED_BORDER_WIDTH = floatPreferencesKey("led_border_width_dp")
        val DARK_GLASS_OPACITY = floatPreferencesKey("dark_glass_opacity")
        val PER_ICON_LED = booleanPreferencesKey("per_icon_led")

        val ICON_PACK = stringPreferencesKey("icon_pack_pkg")
        val ICON_SHAPE = stringPreferencesKey("icon_shape")
        val ICON_CONTAINER = stringPreferencesKey("icon_container_style")
        val ICON_COLOR_MODE = stringPreferencesKey("icon_color_mode")
        val ICON_SIZE = floatPreferencesKey("icon_size_dp")
        val ICON_INNER_SCALE = floatPreferencesKey("icon_inner_scale")
        val ICON_SATURATION = floatPreferencesKey("icon_saturation")
        val ICON_OPACITY = floatPreferencesKey("icon_opacity")
        val SHOW_ARC_LABELS = booleanPreferencesKey("show_arc_labels")
        val SHOW_DRAWER_LABELS = booleanPreferencesKey("show_drawer_labels")
        val LABEL_SIZE_SP = floatPreferencesKey("label_size_sp")

        val BADGE_STYLE = stringPreferencesKey("badge_style")
        val BADGE_LED_COLOR = booleanPreferencesKey("badge_led_color")

        val APP_CUSTOMIZATIONS_JSON = stringPreferencesKey("app_customizations_json")

        val DOUBLE_TAP_LOCK = booleanPreferencesKey("double_tap_lock")
        val AUTO_FOCUS_SEARCH = booleanPreferencesKey("auto_focus_search")
        val AMOLED_WORK_BG = booleanPreferencesKey("amoled_work_bg")
        val PRIVACY_DIMMER = booleanPreferencesKey("privacy_fallback_dimmer")
        val PRIVACY_SETTING_KEY = stringPreferencesKey("privacy_setting_key")
        val ASK_DEFAULT_ON_START = booleanPreferencesKey("ask_default_on_start")
    }

    val preferencesFlow: Flow<LauncherPrefs> = context.dataStore.data.map { prefs ->
        LauncherPrefs(
            handedness = parseEnum(prefs[Keys.HANDEDNESS], Handedness.RIGHT),
            arcPackagesNormal = prefs[Keys.ARC_NORMAL]?.split(",")?.filter { it.isNotBlank() } ?: emptyList(),
            arcPackagesWork = prefs[Keys.ARC_WORK]?.split(",")?.filter { it.isNotBlank() } ?: emptyList(),
            hiddenPackages = prefs[Keys.HIDDEN_APPS] ?: emptySet(),
            arcIconCount = (prefs[Keys.ARC_ICON_COUNT] ?: 5).coerceIn(4, 7),
            arcCurvatureDp = (prefs[Keys.ARC_CURVATURE] ?: 22f).coerceIn(0f, 36f),

            ledAnimationMode = parseEnum(prefs[Keys.LED_ANIMATION], LedAnimationMode.FLOW),
            ledGlowIntensity = (prefs[Keys.LED_GLOW] ?: 0.85f).coerceIn(0f, 1.4f),
            ledBorderWidthDp = (prefs[Keys.LED_BORDER_WIDTH] ?: 1.8f).coerceIn(0.8f, 3.5f),
            darkGlassOpacity = (prefs[Keys.DARK_GLASS_OPACITY] ?: 0.62f).coerceIn(0.25f, 0.92f),
            perIconLedEnabled = prefs[Keys.PER_ICON_LED] ?: true,

            selectedIconPackPackage = prefs[Keys.ICON_PACK] ?: "",
            iconShape = parseEnum(prefs[Keys.ICON_SHAPE], IconShapeStyle.SQUIRCLE),
            iconContainerStyle = parseEnum(prefs[Keys.ICON_CONTAINER], IconContainerStyle.DARK_GLASS_LED),
            iconColorMode = parseEnum(prefs[Keys.ICON_COLOR_MODE], IconColorMode.ORIGINAL),
            iconSizeDp = (prefs[Keys.ICON_SIZE] ?: 54f).coerceIn(40f, 68f),
            iconInnerScale = (prefs[Keys.ICON_INNER_SCALE] ?: 0.72f).coerceIn(0.50f, 1.05f),
            iconSaturation = (prefs[Keys.ICON_SATURATION] ?: 1.0f).coerceIn(0f, 1.5f),
            iconOpacity = (prefs[Keys.ICON_OPACITY] ?: 1.0f).coerceIn(0.45f, 1.0f),
            showArcLabels = prefs[Keys.SHOW_ARC_LABELS] ?: true,
            showDrawerLabels = prefs[Keys.SHOW_DRAWER_LABELS] ?: true,
            labelTextSizeSp = (prefs[Keys.LABEL_SIZE_SP] ?: 11f).coerceIn(9f, 15f),

            badgeStyle = parseEnum(prefs[Keys.BADGE_STYLE], BadgeStyle.COUNT),
            badgeUseLedColor = prefs[Keys.BADGE_LED_COLOR] ?: true,

            appCustomizations = decodeCustomizations(prefs[Keys.APP_CUSTOMIZATIONS_JSON]),

            doubleTapToLock = prefs[Keys.DOUBLE_TAP_LOCK] ?: true,
            autoFocusSearch = prefs[Keys.AUTO_FOCUS_SEARCH] ?: false,
            amoledWorkBackground = prefs[Keys.AMOLED_WORK_BG] ?: true,
            privacyFallbackDimmer = prefs[Keys.PRIVACY_DIMMER] ?: true,
            privacySettingKey = prefs[Keys.PRIVACY_SETTING_KEY] ?: "privacy_display_mode",
            askDefaultLauncherOnStart = prefs[Keys.ASK_DEFAULT_ON_START] ?: true
        )
    }

    suspend fun update(block: (androidx.datastore.preferences.core.MutablePreferences) -> Unit) {
        context.dataStore.edit(block)
    }

    suspend fun setHandedness(v: Handedness) = update { it[Keys.HANDEDNESS] = v.name }
    suspend fun setArcPackages(mode: LauncherMode, packages: List<String>) = update {
        val key = if (mode == LauncherMode.NORMAL) Keys.ARC_NORMAL else Keys.ARC_WORK
        it[key] = packages.take(7).joinToString(",")
    }
    suspend fun setArcIconCount(count: Int) = update { it[Keys.ARC_ICON_COUNT] = count.coerceIn(4, 7) }
    suspend fun setArcCurvature(dp: Float) = update { it[Keys.ARC_CURVATURE] = dp.coerceIn(0f, 36f) }

    suspend fun setLedAnimationMode(m: LedAnimationMode) = update { it[Keys.LED_ANIMATION] = m.name }
    suspend fun setLedGlowIntensity(v: Float) = update { it[Keys.LED_GLOW] = v.coerceIn(0f, 1.4f) }
    suspend fun setLedBorderWidth(v: Float) = update { it[Keys.LED_BORDER_WIDTH] = v.coerceIn(0.8f, 3.5f) }
    suspend fun setDarkGlassOpacity(v: Float) = update { it[Keys.DARK_GLASS_OPACITY] = v.coerceIn(0.25f, 0.92f) }
    suspend fun setPerIconLedEnabled(v: Boolean) = update { it[Keys.PER_ICON_LED] = v }

    suspend fun setIconPack(pkg: String) = update { it[Keys.ICON_PACK] = pkg }
    suspend fun setIconShape(s: IconShapeStyle) = update { it[Keys.ICON_SHAPE] = s.name }
    suspend fun setIconContainerStyle(s: IconContainerStyle) = update { it[Keys.ICON_CONTAINER] = s.name }
    suspend fun setIconColorMode(m: IconColorMode) = update { it[Keys.ICON_COLOR_MODE] = m.name }
    suspend fun setIconSize(dp: Float) = update { it[Keys.ICON_SIZE] = dp.coerceIn(40f, 68f) }
    suspend fun setIconInnerScale(v: Float) = update { it[Keys.ICON_INNER_SCALE] = v.coerceIn(0.50f, 1.05f) }
    suspend fun setIconSaturation(v: Float) = update { it[Keys.ICON_SATURATION] = v.coerceIn(0f, 1.5f) }
    suspend fun setIconOpacity(v: Float) = update { it[Keys.ICON_OPACITY] = v.coerceIn(0.45f, 1.0f) }
    suspend fun setShowArcLabels(v: Boolean) = update { it[Keys.SHOW_ARC_LABELS] = v }
    suspend fun setShowDrawerLabels(v: Boolean) = update { it[Keys.SHOW_DRAWER_LABELS] = v }
    suspend fun setLabelTextSizeSp(v: Float) = update { it[Keys.LABEL_SIZE_SP] = v.coerceIn(9f, 15f) }

    suspend fun setBadgeStyle(s: BadgeStyle) = update { it[Keys.BADGE_STYLE] = s.name }
    suspend fun setBadgeUseLedColor(v: Boolean) = update { it[Keys.BADGE_LED_COLOR] = v }

    suspend fun setAppCustomization(packageName: String, customization: AppCustomization?) = update { prefs ->
        val map = decodeCustomizations(prefs[Keys.APP_CUSTOMIZATIONS_JSON]).toMutableMap()
        if (customization == null) {
            map.remove(packageName)
        } else {
            map[packageName] = customization
        }
        prefs[Keys.APP_CUSTOMIZATIONS_JSON] = encodeCustomizations(map)
    }

    suspend fun resetAllIconStyles() = update { prefs ->
        prefs[Keys.ICON_PACK] = ""
        prefs[Keys.ICON_SHAPE] = IconShapeStyle.SQUIRCLE.name
        prefs[Keys.ICON_CONTAINER] = IconContainerStyle.DARK_GLASS_LED.name
        prefs[Keys.ICON_COLOR_MODE] = IconColorMode.ORIGINAL.name
        prefs[Keys.ICON_SIZE] = 54f
        prefs[Keys.ICON_INNER_SCALE] = 0.72f
        prefs[Keys.ICON_SATURATION] = 1.0f
        prefs[Keys.ICON_OPACITY] = 1.0f
        prefs[Keys.PER_ICON_LED] = true
        prefs[Keys.LED_ANIMATION] = LedAnimationMode.FLOW.name
        prefs[Keys.LED_GLOW] = 0.85f
        prefs[Keys.LED_BORDER_WIDTH] = 1.8f
        prefs[Keys.DARK_GLASS_OPACITY] = 0.62f
    }

    suspend fun toggleHiddenPackage(packageName: String) = update { prefs ->
        val current = prefs[Keys.HIDDEN_APPS]?.toMutableSet() ?: mutableSetOf()
        if (!current.add(packageName)) current.remove(packageName)
        prefs[Keys.HIDDEN_APPS] = current
    }

    suspend fun setDoubleTapToLock(v: Boolean) = update { it[Keys.DOUBLE_TAP_LOCK] = v }
    suspend fun setAutoFocusSearch(v: Boolean) = update { it[Keys.AUTO_FOCUS_SEARCH] = v }
    suspend fun setAmoledWorkBackground(v: Boolean) = update { it[Keys.AMOLED_WORK_BG] = v }
    suspend fun setPrivacyFallbackDimmer(v: Boolean) = update { it[Keys.PRIVACY_DIMMER] = v }
    suspend fun setPrivacySettingKey(k: String) = update {
        it[Keys.PRIVACY_SETTING_KEY] = k.trim().ifEmpty { "privacy_display_mode" }
    }
    suspend fun setAskDefaultLauncherOnStart(v: Boolean) = update { it[Keys.ASK_DEFAULT_ON_START] = v }

    private inline fun <reified T : Enum<T>> parseEnum(raw: String?, fallback: T): T {
        if (raw.isNullOrBlank()) return fallback
        return runCatching { enumValueOf<T>(raw) }.getOrDefault(fallback)
    }

    private fun decodeCustomizations(jsonStr: String?): Map<String, AppCustomization> {
        if (jsonStr.isNullOrBlank()) return emptyMap()
        return runCatching {
            val root = JSONObject(jsonStr)
            val result = mutableMapOf<String, AppCustomization>()
            val keys = root.keys()
            while (keys.hasNext()) {
                val pkg = keys.next()
                val obj = root.optJSONObject(pkg) ?: continue
                val label = obj.optString("label", "").takeIf { it.isNotBlank() }
                val type = parseEnum(obj.optString("type", ""), CustomIconType.DEFAULT)
                val value = obj.optString("value", "").takeIf { it.isNotBlank() }
                val led = if (obj.has("led") && !obj.isNull("led")) obj.optLong("led") else null
                result[pkg] = AppCustomization(
                    customLabel = label,
                    iconType = type,
                    iconValue = value,
                    customLedColorArgb = led
                )
            }
            result
        }.getOrDefault(emptyMap())
    }

    private fun encodeCustomizations(map: Map<String, AppCustomization>): String {
        val root = JSONObject()
        for ((pkg, item) in map) {
            val obj = JSONObject()
            item.customLabel?.let { obj.put("label", it) }
            obj.put("type", item.iconType.name)
            item.iconValue?.let { obj.put("value", it) }
            item.customLedColorArgb?.let { obj.put("led", it) }
            root.put(pkg, obj)
        }
        return root.toString()
    }
}
