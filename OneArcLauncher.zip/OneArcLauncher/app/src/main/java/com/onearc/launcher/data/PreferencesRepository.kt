package com.onearc.launcher.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "onearc_prefs")

class PreferencesRepository(private val context: Context) {

    private object Keys {
        val HANDEDNESS = stringPreferencesKey("handedness")
        val ARC_NORMAL = stringPreferencesKey("arc_normal_csv")
        val ARC_WORK = stringPreferencesKey("arc_work_csv")
        val HIDDEN_APPS = stringSetPreferencesKey("hidden_apps")
        val MONOCHROME_ICONS = booleanPreferencesKey("monochrome_icons")
        val DOUBLE_TAP_LOCK = booleanPreferencesKey("double_tap_lock")
        val AUTO_FOCUS_SEARCH = booleanPreferencesKey("auto_focus_search")
        val AMOLED_WORK_BG = booleanPreferencesKey("amoled_work_bg")
        val PRIVACY_DIMMER = booleanPreferencesKey("privacy_fallback_dimmer")
        val PRIVACY_SETTING_KEY = stringPreferencesKey("privacy_setting_key")
    }

    val preferencesFlow: Flow<LauncherPrefs> = context.dataStore.data.map { prefs ->
        LauncherPrefs(
            handedness = runCatching {
                Handedness.valueOf(prefs[Keys.HANDEDNESS] ?: Handedness.RIGHT.name)
            }.getOrDefault(Handedness.RIGHT),
            arcPackagesNormal = prefs[Keys.ARC_NORMAL]
                ?.split(",")
                ?.filter { it.isNotBlank() }
                ?: emptyList(),
            arcPackagesWork = prefs[Keys.ARC_WORK]
                ?.split(",")
                ?.filter { it.isNotBlank() }
                ?: emptyList(),
            hiddenPackages = prefs[Keys.HIDDEN_APPS] ?: emptySet(),
            monochromeIcons = prefs[Keys.MONOCHROME_ICONS] ?: false,
            doubleTapToLock = prefs[Keys.DOUBLE_TAP_LOCK] ?: true,
            autoFocusSearch = prefs[Keys.AUTO_FOCUS_SEARCH] ?: false,
            amoledWorkBackground = prefs[Keys.AMOLED_WORK_BG] ?: true,
            privacyFallbackDimmer = prefs[Keys.PRIVACY_DIMMER] ?: true,
            privacySettingKey = prefs[Keys.PRIVACY_SETTING_KEY] ?: "privacy_display_mode"
        )
    }

    suspend fun setHandedness(handedness: Handedness) {
        context.dataStore.edit { it[Keys.HANDEDNESS] = handedness.name }
    }

    suspend fun setArcPackages(mode: LauncherMode, packages: List<String>) {
        val key = if (mode == LauncherMode.NORMAL) Keys.ARC_NORMAL else Keys.ARC_WORK
        context.dataStore.edit { it[key] = packages.take(5).joinToString(",") }
    }

    suspend fun toggleHiddenPackage(packageName: String) {
        context.dataStore.edit { prefs ->
            val current = prefs[Keys.HIDDEN_APPS]?.toMutableSet() ?: mutableSetOf()
            if (!current.add(packageName)) {
                current.remove(packageName)
            }
            prefs[Keys.HIDDEN_APPS] = current
        }
    }

    suspend fun setMonochromeIcons(enabled: Boolean) {
        context.dataStore.edit { it[Keys.MONOCHROME_ICONS] = enabled }
    }

    suspend fun setDoubleTapToLock(enabled: Boolean) {
        context.dataStore.edit { it[Keys.DOUBLE_TAP_LOCK] = enabled }
    }

    suspend fun setAutoFocusSearch(enabled: Boolean) {
        context.dataStore.edit { it[Keys.AUTO_FOCUS_SEARCH] = enabled }
    }

    suspend fun setAmoledWorkBackground(enabled: Boolean) {
        context.dataStore.edit { it[Keys.AMOLED_WORK_BG] = enabled }
    }

    suspend fun setPrivacyFallbackDimmer(enabled: Boolean) {
        context.dataStore.edit { it[Keys.PRIVACY_DIMMER] = enabled }
    }

    suspend fun setPrivacySettingKey(settingKey: String) {
        context.dataStore.edit { it[Keys.PRIVACY_SETTING_KEY] = settingKey.trim().ifEmpty { "privacy_display_mode" } }
    }
}
