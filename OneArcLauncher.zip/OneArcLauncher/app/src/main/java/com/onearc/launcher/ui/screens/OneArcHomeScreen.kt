package com.onearc.launcher.ui.screens

import android.graphics.Rect
import android.view.HapticFeedbackConstants
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Apps
import androidx.compose.material.icons.rounded.Notifications
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.Shield
import androidx.compose.material.icons.rounded.Vibration
import androidx.compose.material.icons.rounded.WbSunny
import androidx.compose.material.icons.rounded.Work
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.dp
import com.onearc.launcher.data.AppEntry
import com.onearc.launcher.data.AppShortcutItem
import com.onearc.launcher.data.Handedness
import com.onearc.launcher.data.LauncherMode
import com.onearc.launcher.service.OneArcAccessibilityService
import com.onearc.launcher.system.WorkModeController
import com.onearc.launcher.ui.components.AppContextSheet
import com.onearc.launcher.ui.components.AppDrawerSheet
import com.onearc.launcher.ui.components.ArcDock
import com.onearc.launcher.ui.components.SettingsSheet
import com.onearc.launcher.ui.theme.ExpressiveMotion
import com.onearc.launcher.ui.theme.ExpressiveShapes
import com.onearc.launcher.ui.viewmodel.LauncherUiState
import kotlinx.coroutines.delay
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale

@Composable
fun OneArcHomeScreen(
    state: LauncherUiState,
    workModeController: WorkModeController,
    onToggleWorkMode: () -> Unit,
    onLaunchApp: (AppEntry, Rect?) -> Unit,
    onOpenDrawer: () -> Unit,
    onCloseDrawer: () -> Unit,
    onSearchChange: (String) -> Unit,
    onOpenSettings: () -> Unit,
    onCloseSettings: () -> Unit,
    onLongPressApp: (AppEntry) -> Unit,
    onCloseContextMenu: () -> Unit,
    onTogglePinArc: (AppEntry) -> Unit,
    onLaunchShortcut: (AppShortcutItem, Rect?) -> Unit,
    onHideApp: (AppEntry) -> Unit,
    onAppInfo: (AppEntry) -> Unit,
    onUninstall: (AppEntry) -> Unit,
    onHandednessChange: (Handedness) -> Unit,
    onMonochromeChange: (Boolean) -> Unit,
    onDoubleTapLockChange: (Boolean) -> Unit,
    onAutoFocusSearchChange: (Boolean) -> Unit,
    onAmoledWorkChange: (Boolean) -> Unit,
    onPrivacyDimmerChange: (Boolean) -> Unit,
    onPrivacyKeyChange: (String) -> Unit
) {
    val view = LocalView.current
    val isWorkMode = state.mode == LauncherMode.WORK

    // Orologio aggiornato in tempo reale
    var now by remember { mutableStateOf(LocalDateTime.now()) }
    LaunchedEffect(Unit) {
        while (true) {
            now = LocalDateTime.now()
            delay(5_000)
        }
    }

    val timeFormatter = remember { DateTimeFormatter.ofPattern("HH:mm") }
    val dateFormatter = remember { DateTimeFormatter.ofPattern("EEEE d MMMM", Locale.ITALIAN) }

    // Gestione tasto indietro: chiude drawer / impostazioni senza uscire dal launcher
    BackHandler(enabled = state.isDrawerOpen || state.isSettingsOpen || state.selectedAppForMenu != null) {
        when {
            state.selectedAppForMenu != null -> onCloseContextMenu()
            state.isSettingsOpen -> onCloseSettings()
            state.isDrawerOpen -> onCloseDrawer()
        }
    }

    // Sfondo trasparente sullo wallpaper Galaxy in Modalita Normale;
    // scuro AMOLED (+ eventuale filtro privacy di riserva) in Modalita Lavoro
    val scrimAlpha by animateFloatAsState(
        targetValue = when {
            isWorkMode && state.prefs.amoledWorkBackground -> 0.94f
            isWorkMode && state.prefs.privacyFallbackDimmer -> 0.78f
            else -> 0.22f
        },
        animationSpec = ExpressiveMotion.effectsDefault(),
        label = "scrimAlpha"
    )

    val topScrim = Color.Black.copy(alpha = scrimAlpha)
    val bottomScrim = Color.Black.copy(alpha = (scrimAlpha + 0.18f).coerceAtMost(0.98f))

    var verticalDragAccumulator by remember { mutableFloatStateOf(0f) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(topScrim, bottomScrim)))
            .pointerInput(state.prefs.doubleTapToLock) {
                detectTapGestures(
                    onDoubleTap = {
                        if (state.prefs.doubleTapToLock) {
                            view.performHapticFeedback(HapticFeedbackConstants.CONTEXT_CLICK)
                            OneArcAccessibilityService.lockScreen()
                        }
                    },
                    onLongPress = {
                        view.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
                        onOpenSettings()
                    }
                )
            }
            .pointerInput(Unit) {
                detectVerticalDragGestures(
                    onDragStart = { verticalDragAccumulator = 0f },
                    onVerticalDrag = { _, dragAmount ->
                        verticalDragAccumulator += dragAmount
                    },
                    onDragEnd = {
                        when {
                            // Swipe su nella zona pollice -> App Drawer
                            verticalDragAccumulator < -95f -> {
                                view.performHapticFeedback(HapticFeedbackConstants.GESTURE_START)
                                onOpenDrawer()
                            }
                            // Swipe giu ovunque -> Tendina notifiche Samsung
                            verticalDragAccumulator > 95f -> {
                                view.performHapticFeedback(HapticFeedbackConstants.GESTURE_START)
                                OneArcAccessibilityService.expandNotificationShade()
                            }
                        }
                        verticalDragAccumulator = 0f
                    }
                )
            }
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(horizontal = 20.dp, vertical = 14.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // =====================================================================
            // ZONA SUPERIORE (60%): Solo informativa, zero tasti scomodi da raggiungere
            // =====================================================================
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 28.dp),
                horizontalAlignment = Alignment.Start
            ) {
                Text(
                    text = now.format(timeFormatter),
                    style = MaterialTheme.typography.displayLarge,
                    color = Color.White
                )

                Text(
                    text = now.format(dateFormatter).replaceFirstChar { it.uppercase() },
                    style = MaterialTheme.typography.titleMedium,
                    color = Color.White.copy(alpha = 0.82f)
                )

                Spacer(modifier = Modifier.height(14.dp))

                // Indicatori minimali: Stato Lavoro + Contatore globale notifiche
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (isWorkMode) {
                        StatusChip(
                            icon = Icons.Rounded.Shield,
                            text = if (state.hardwarePrivacyActive) "Privacy Display ON" else "Lavoro + Vibrazione",
                            containerColor = MaterialTheme.colorScheme.primaryContainer,
                            contentColor = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                    }

                    if (state.totalBadges > 0) {
                        StatusChip(
                            icon = Icons.Rounded.Notifications,
                            text = "${state.totalBadges} notifiche",
                            containerColor = MaterialTheme.colorScheme.surfaceContainerHigh.copy(alpha = 0.85f),
                            contentColor = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }

                // Banner feedback temporaneo
                AnimatedVisibility(
                    visible = state.statusBanner != null,
                    enter = fadeIn() + slideInVertically { -it / 2 },
                    exit = fadeOut() + slideOutVertically { -it / 2 }
                ) {
                    state.statusBanner?.let { msg ->
                        Surface(
                            modifier = Modifier.padding(top = 12.dp),
                            shape = ExpressiveShapes.Pill,
                            color = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.92f)
                        ) {
                            Text(
                                text = msg,
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSecondaryContainer,
                                modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)
                            )
                        }
                    }
                }
            }

            // =====================================================================
            // ZONA INFERIORE (40% - Thumb Zone): Controlli monomano + Tasto Lavoro + Arco
            // =====================================================================
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Barra Pillole Expressive (Tasto Lavoro + Ricerca + Drawer + Impostazioni)
                val controlsRow: @Composable () -> Unit = {
                    val workBg by animateColorAsState(
                        targetValue = if (isWorkMode) {
                            MaterialTheme.colorScheme.primary
                        } else {
                            MaterialTheme.colorScheme.surfaceContainerHigh.copy(alpha = 0.86f)
                        },
                        animationSpec = ExpressiveMotion.effectsDefault(),
                        label = "workBg"
                    )
                    val workFg by animateColorAsState(
                        targetValue = if (isWorkMode) {
                            MaterialTheme.colorScheme.onPrimary
                        } else {
                            MaterialTheme.colorScheme.onSurface
                        },
                        animationSpec = ExpressiveMotion.effectsDefault(),
                        label = "workFg"
                    )

                    // Tasto Lavoro Expressive (a portata di pollice)
                    Surface(
                        onClick = {
                            view.performHapticFeedback(HapticFeedbackConstants.CONFIRM)
                            onToggleWorkMode()
                        },
                        shape = ExpressiveShapes.Pill,
                        color = workBg,
                        tonalElevation = 4.dp
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 18.dp, vertical = 12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                imageVector = if (isWorkMode) Icons.Rounded.Work else Icons.Rounded.WbSunny,
                                contentDescription = "Modalita Lavoro",
                                tint = workFg,
                                modifier = Modifier.size(20.dp)
                            )
                            Text(
                                text = if (isWorkMode) "Lavoro" else "Normale",
                                style = MaterialTheme.typography.labelLarge,
                                color = workFg
                            )
                            if (isWorkMode) {
                                Icon(
                                    imageVector = Icons.Rounded.Vibration,
                                    contentDescription = "Vibrazione attiva",
                                    tint = workFg,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilledTonalIconButton(
                            onClick = {
                                view.performHapticFeedback(HapticFeedbackConstants.CONTEXT_CLICK)
                                onOpenDrawer()
                            },
                            colors = IconButtonDefaults.filledTonalIconButtonColors(
                                containerColor = MaterialTheme.colorScheme.surfaceContainerHigh.copy(alpha = 0.86f)
                            )
                        ) {
                            Icon(Icons.Rounded.Search, contentDescription = "Cerca app")
                        }

                        FilledTonalIconButton(
                            onClick = {
                                view.performHapticFeedback(HapticFeedbackConstants.CONTEXT_CLICK)
                                onOpenDrawer()
                            },
                            colors = IconButtonDefaults.filledTonalIconButtonColors(
                                containerColor = MaterialTheme.colorScheme.surfaceContainerHigh.copy(alpha = 0.86f)
                            )
                        ) {
                            Icon(Icons.Rounded.Apps, contentDescription = "Tutte le app")
                        }

                        FilledTonalIconButton(
                            onClick = {
                                view.performHapticFeedback(HapticFeedbackConstants.CONTEXT_CLICK)
                                onOpenSettings()
                            },
                            colors = IconButtonDefaults.filledTonalIconButtonColors(
                                containerColor = MaterialTheme.colorScheme.surfaceContainerHigh.copy(alpha = 0.86f)
                            )
                        ) {
                            Icon(Icons.Rounded.Settings, contentDescription = "Impostazioni")
                        }
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    controlsRow()
                }

                // Arco Interattivo Monomano con badge contatore notifiche e animazioni bounds
                ArcDock(
                    apps = state.arcApps,
                    badgeCounts = state.badgeCounts,
                    handedness = state.prefs.handedness,
                    monochromeIcons = state.prefs.monochromeIcons,
                    lastLaunchedPackage = state.lastLaunchedPackage,
                    returnPulseToken = state.returnPulseToken,
                    onLaunchApp = onLaunchApp,
                    onLongPressApp = onLongPressApp
                )
            }
        }

        // App Drawer Overlay con animazione fluida dal basso
        AnimatedVisibility(
            visible = state.isDrawerOpen,
            enter = slideInVertically(
                initialOffsetY = { it / 2 },
                animationSpec = ExpressiveMotion.spatialDefault()
            ) + fadeIn(),
            exit = slideOutVertically(
                targetOffsetY = { it / 2 },
                animationSpec = ExpressiveMotion.spatialDefault()
            ) + fadeOut()
        ) {
            AppDrawerSheet(
                apps = state.visibleApps,
                badgeCounts = state.badgeCounts,
                searchQuery = state.searchQuery,
                handedness = state.prefs.handedness,
                monochromeIcons = state.prefs.monochromeIcons,
                autoFocusSearch = state.prefs.autoFocusSearch,
                onSearchChange = onSearchChange,
                onLaunchApp = onLaunchApp,
                onLongPressApp = onLongPressApp,
                onOpenSettings = {
                    onCloseDrawer()
                    onOpenSettings()
                },
                onDismiss = onCloseDrawer
            )
        }

        // Sheet Azioni Rapide / Shortcuts app
        state.selectedAppForMenu?.let { selected ->
            AppContextSheet(
                app = selected,
                isPinnedInArc = state.arcApps.any { it.packageName == selected.packageName },
                shortcuts = state.selectedAppShortcuts,
                onTogglePin = { onTogglePinArc(selected) },
                onLaunchShortcut = onLaunchShortcut,
                onHideApp = { onHideApp(selected) },
                onAppInfo = { onAppInfo(selected) },
                onUninstall = { onUninstall(selected) },
                onDismiss = onCloseContextMenu
            )
        }

        // Sheet Impostazioni OneArc
        if (state.isSettingsOpen) {
            SettingsSheet(
                prefs = state.prefs,
                workModeController = workModeController,
                onHandednessChange = onHandednessChange,
                onMonochromeChange = onMonochromeChange,
                onDoubleTapLockChange = onDoubleTapLockChange,
                onAutoFocusSearchChange = onAutoFocusSearchChange,
                onAmoledWorkChange = onAmoledWorkChange,
                onPrivacyDimmerChange = onPrivacyDimmerChange,
                onPrivacyKeyChange = onPrivacyKeyChange,
                onDismiss = onCloseSettings
            )
        }
    }
}

@Composable
private fun StatusChip(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    text: String,
    containerColor: Color,
    contentColor: Color
) {
    Surface(
        shape = ExpressiveShapes.Pill,
        color = containerColor
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = contentColor,
                modifier = Modifier.size(15.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = text,
                style = MaterialTheme.typography.labelSmall,
                color = contentColor
            )
        }
    }
}
