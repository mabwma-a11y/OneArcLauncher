package com.onearc.launcher.ui.screens

import android.graphics.Rect
import android.net.Uri
import android.view.HapticFeedbackConstants
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Apps
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Notifications
import androidx.compose.material.icons.rounded.Palette
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.Shield
import androidx.compose.material.icons.rounded.Vibration
import androidx.compose.material.icons.rounded.WbSunny
import androidx.compose.material.icons.rounded.Work
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.dp
import com.onearc.launcher.data.AppCustomization
import com.onearc.launcher.data.AppEntry
import com.onearc.launcher.data.AppShortcutItem
import com.onearc.launcher.data.BadgeStyle
import com.onearc.launcher.data.Handedness
import com.onearc.launcher.data.IconColorMode
import com.onearc.launcher.data.IconContainerStyle
import com.onearc.launcher.data.IconShapeStyle
import com.onearc.launcher.data.LauncherMode
import com.onearc.launcher.data.LauncherPrefs
import com.onearc.launcher.data.LedAnimationMode
import com.onearc.launcher.service.OneArcAccessibilityService
import com.onearc.launcher.system.WorkModeController
import com.onearc.launcher.ui.components.AppContextSheet
import com.onearc.launcher.ui.components.AppDrawerSheet
import com.onearc.launcher.ui.components.ArcDock
import com.onearc.launcher.ui.components.DefaultLauncherPromptDialog
import com.onearc.launcher.ui.components.IconCustomizeSheet
import com.onearc.launcher.ui.components.IconStudioSheet
import com.onearc.launcher.ui.components.SettingsSheet
import com.onearc.launcher.ui.components.ledGlassSurface
import com.onearc.launcher.ui.theme.ExpressiveMotion
import com.onearc.launcher.ui.theme.ExpressiveShapes
import com.onearc.launcher.ui.theme.LocalLedPalette
import com.onearc.launcher.ui.viewmodel.LauncherUiState
import kotlinx.coroutines.delay
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale

@Composable
fun OneArcHomeScreen(
    state: LauncherUiState,
    workModeController: WorkModeController,
    onRequestDefaultLauncher: () -> Unit,
    onDismissDefaultPrompt: () -> Unit,
    onNeverAskDefaultPrompt: () -> Unit,
    onToggleWorkMode: () -> Unit,
    onLaunchApp: (AppEntry, Rect?) -> Unit,
    onOpenDrawer: () -> Unit,
    onCloseDrawer: () -> Unit,
    onSearchChange: (String) -> Unit,
    onOpenSettings: () -> Unit,
    onCloseSettings: () -> Unit,
    onOpenIconStudio: () -> Unit,
    onCloseIconStudio: () -> Unit,
    onLongPressApp: (AppEntry) -> Unit,
    onCloseContextMenu: () -> Unit,
    onOpenAppCustomizer: (AppEntry) -> Unit,
    onCloseAppCustomizer: () -> Unit,
    onSaveAppCustomization: (String, AppCustomization?) -> Unit,
    onPickGalleryIcon: (String, Uri, AppCustomization?) -> Unit,
    onTogglePinArc: (AppEntry) -> Unit,
    onLaunchShortcut: (AppShortcutItem, Rect?) -> Unit,
    onHideApp: (AppEntry) -> Unit,
    onAppInfo: (AppEntry) -> Unit,
    onUninstall: (AppEntry) -> Unit,
    onHandednessChange: (Handedness) -> Unit,
    onLedAnimationChange: (LedAnimationMode) -> Unit,
    onLedGlowChange: (Float) -> Unit,
    onLedBorderWidthChange: (Float) -> Unit,
    onDarkGlassOpacityChange: (Float) -> Unit,
    onPerIconLedChange: (Boolean) -> Unit,
    onIconPackChange: (String) -> Unit,
    onIconShapeChange: (IconShapeStyle) -> Unit,
    onIconContainerChange: (IconContainerStyle) -> Unit,
    onIconColorModeChange: (IconColorMode) -> Unit,
    onIconSizeChange: (Float) -> Unit,
    onIconInnerScaleChange: (Float) -> Unit,
    onIconSaturationChange: (Float) -> Unit,
    onIconOpacityChange: (Float) -> Unit,
    onArcIconCountChange: (Int) -> Unit,
    onArcCurvatureChange: (Float) -> Unit,
    onShowArcLabelsChange: (Boolean) -> Unit,
    onShowDrawerLabelsChange: (Boolean) -> Unit,
    onLabelSizeChange: (Float) -> Unit,
    onBadgeStyleChange: (BadgeStyle) -> Unit,
    onBadgeLedColorChange: (Boolean) -> Unit,
    onResetIconStyles: () -> Unit,
    onDoubleTapLockChange: (Boolean) -> Unit,
    onAutoFocusSearchChange: (Boolean) -> Unit,
    onAmoledWorkChange: (Boolean) -> Unit,
    onPrivacyDimmerChange: (Boolean) -> Unit,
    onPrivacyKeyChange: (String) -> Unit,
    onAskDefaultOnStartChange: (Boolean) -> Unit
) {
    val view = LocalView.current
    val led = LocalLedPalette.current
    val isWorkMode = state.mode == LauncherMode.WORK

    var now by remember { mutableStateOf(LocalDateTime.now()) }
    LaunchedEffect(Unit) {
        while (true) {
            now = LocalDateTime.now()
            delay(5_000)
        }
    }

    val timeFormatter = remember { DateTimeFormatter.ofPattern("HH:mm") }
    val dateFormatter = remember { DateTimeFormatter.ofPattern("EEEE d MMMM", Locale.ITALIAN) }

    BackHandler(
        enabled = state.isDrawerOpen ||
            state.isSettingsOpen ||
            state.isIconStudioOpen ||
            state.selectedAppForMenu != null ||
            state.customizingApp != null
    ) {
        when {
            state.customizingApp != null -> onCloseAppCustomizer()
            state.selectedAppForMenu != null -> onCloseContextMenu()
            state.isIconStudioOpen -> onCloseIconStudio()
            state.isSettingsOpen -> onCloseSettings()
            state.isDrawerOpen -> onCloseDrawer()
        }
    }

    val scrimAlpha by animateFloatAsState(
        targetValue = when {
            isWorkMode && state.prefs.amoledWorkBackground -> 0.94f
            isWorkMode && state.prefs.privacyFallbackDimmer -> 0.78f
            else -> 0.16f
        },
        animationSpec = ExpressiveMotion.effectsDefault(),
        label = "scrimAlpha"
    )

    val topScrim = Color.Black.copy(alpha = scrimAlpha)
    val bottomScrim = Color.Black.copy(alpha = (scrimAlpha + 0.22f).coerceAtMost(0.98f))
    var verticalDragAccumulator by remember { mutableFloatStateOf(0f) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(topScrim, bottomScrim)))
            .pointerInput(state.prefs.doubleTapToLock) {
                detectTapGestures(
                    onDoubleTap = {
                        if (state.prefs.doubleTapToLock) {
                            view.performHapticFeedback(HapticFeedbackConstants.CONTEXT_CLICK)
                            OneArcAccessibilityService.lockScreen()
                        }
                    },
                    onLongPress = {
                        view.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
                        onOpenIconStudio()
                    }
                )
            }
            .pointerInput(Unit) {
                detectVerticalDragGestures(
                    onDragStart = { verticalDragAccumulator = 0f },
                    onVerticalDrag = { _, dragAmount -> verticalDragAccumulator += dragAmount },
                    onDragEnd = {
                        when {
                            verticalDragAccumulator < -95f -> {
                                view.performHapticFeedback(HapticFeedbackConstants.GESTURE_START)
                                onOpenDrawer()
                            }
                            verticalDragAccumulator > 95f -> {
                                view.performHapticFeedback(HapticFeedbackConstants.GESTURE_START)
                                OneArcAccessibilityService.expandNotificationShade()
                            }
                        }
                        verticalDragAccumulator = 0f
                    }
                )
            }
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(horizontal = 18.dp, vertical = 14.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // =================================================================
            // ZONA SUPERIORE (60%): Orologio + Data + Pillole Stato a LED
            // =================================================================
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 26.dp),
                horizontalAlignment = Alignment.Start
            ) {
                Text(
                    text = now.format(timeFormatter),
                    style = MaterialTheme.typography.displayLarge,
                    color = Color.White
                )

                Text(
                    text = now.format(dateFormatter).replaceFirstChar { it.uppercase() },
                    style = MaterialTheme.typography.titleMedium,
                    color = led.secondary.copy(alpha = 0.92f)
                )

                Spacer(modifier = Modifier.height(14.dp))

                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (isWorkMode) {
                        LedStatusChip(
                            icon = Icons.Rounded.Shield,
                            text = if (state.hardwarePrivacyActive) "Privacy Display ON" else "Lavoro + Vibrazione",
                            prefs = state.prefs,
                            accent = led.primary
                        )
                    }

                    if (state.totalBadges > 0 && state.prefs.badgeStyle != BadgeStyle.HIDDEN) {
                        LedStatusChip(
                            icon = Icons.Rounded.Notifications,
                            text = "${state.totalBadges} notifiche",
                            prefs = state.prefs,
                            accent = led.secondary
                        )
                    }

                    // Se non e ancora predefinito, chip rapido 1-tap
                    if (!state.isDefaultLauncher) {
                        LedStatusChip(
                            icon = Icons.Rounded.Home,
                            text = "Imposta Home",
                            prefs = state.prefs,
                            accent = led.tertiary,
                            onClick = onRequestDefaultLauncher
                        )
                    }
                }

                AnimatedVisibility(
                    visible = state.statusBanner != null,
                    enter = fadeIn() + slideInVertically { -it / 2 },
                    exit = fadeOut() + slideOutVertically { -it / 2 }
                ) {
                    state.statusBanner?.let { msg ->
                        Box(
                            modifier = Modifier
                                .padding(top = 12.dp)
                                .ledGlassSurface(
                                    shape = ExpressiveShapes.Pill,
                                    glassOpacity = 0.78f,
                                    borderWidth = 1.2.dp,
                                    glowIntensity = state.prefs.ledGlowIntensity * 0.75f,
                                    animationMode = state.prefs.ledAnimationMode
                                )
                                .padding(horizontal = 14.dp, vertical = 8.dp)
                        ) {
                            Text(
                                text = msg,
                                style = MaterialTheme.typography.labelSmall,
                                color = Color.White
                            )
                        }
                    }
                }
            }

            // =================================================================
            // ZONA INFERIORE (40% - Thumb Zone): Controlli LED + Dock ad Arco LED
            // =================================================================
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Tasto Lavoro trasparente scuro con bordo LED
                    Box(
                        modifier = Modifier
                            .ledGlassSurface(
                                shape = ExpressiveShapes.Pill,
                                glassOpacity = if (isWorkMode) 0.84f else state.prefs.darkGlassOpacity,
                                borderWidth = if (isWorkMode) (state.prefs.ledBorderWidthDp + 0.5f).dp else state.prefs.ledBorderWidthDp.dp,
                                glowIntensity = if (isWorkMode) (state.prefs.ledGlowIntensity * 1.25f) else state.prefs.ledGlowIntensity * 0.85f,
                                animationMode = state.prefs.ledAnimationMode
                            )
                            .clip(ExpressiveShapes.Pill)
                            .clickable {
                                view.performHapticFeedback(HapticFeedbackConstants.CONFIRM)
                                onToggleWorkMode()
                            }
                            .padding(horizontal = 18.dp, vertical = 12.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                imageVector = if (isWorkMode) Icons.Rounded.Work else Icons.Rounded.WbSunny,
                                contentDescription = "Modalita Lavoro",
                                tint = if (isWorkMode) led.primary else Color.White,
                                modifier = Modifier.size(19.dp)
                            )
                            Text(
                                text = if (isWorkMode) "Lavoro" else "Normale",
                                style = MaterialTheme.typography.labelLarge,
                                color = if (isWorkMode) led.primary else Color.White
                            )
                            if (isWorkMode) {
                                Icon(
                                    imageVector = Icons.Rounded.Vibration,
                                    contentDescription = "Vibrazione",
                                    tint = led.secondary,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                    }

                    // Pulsanti circolari Vetro Scuro + LED (Ricerca, Drawer, Icon Studio, Impostazioni)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        LedCircleActionButton(
                            icon = Icons.Rounded.Search,
                            contentDescription = "Cerca app",
                            prefs = state.prefs,
                            tint = Color.White,
                            onClick = {
                                view.performHapticFeedback(HapticFeedbackConstants.CONTEXT_CLICK)
                                onOpenDrawer()
                            }
                        )
                        LedCircleActionButton(
                            icon = Icons.Rounded.Apps,
                            contentDescription = "Tutte le app",
                            prefs = state.prefs,
                            tint = Color.White,
                            onClick = {
                                view.performHapticFeedback(HapticFeedbackConstants.CONTEXT_CLICK)
                                onOpenDrawer()
                            }
                        )
                        LedCircleActionButton(
                            icon = Icons.Rounded.Palette,
                            contentDescription = "Icon & LED Studio",
                            prefs = state.prefs,
                            tint = led.primary,
                            onClick = {
                                view.performHapticFeedback(HapticFeedbackConstants.CONTEXT_CLICK)
                                onOpenIconStudio()
                            }
                        )
                        LedCircleActionButton(
                            icon = Icons.Rounded.Settings,
                            contentDescription = "Impostazioni",
                            prefs = state.prefs,
                            tint = Color.White,
                            onClick = {
                                view.performHapticFeedback(HapticFeedbackConstants.CONTEXT_CLICK)
                                onOpenSettings()
                            }
                        )
                    }
                }

                // Dock ad Arco trasparente scura con bordo LED
                ArcDock(
                    apps = state.arcApps,
                    badgeCounts = state.badgeCounts,
                    prefs = state.prefs,
                    lastLaunchedPackage = state.lastLaunchedPackage,
                    returnPulseToken = state.returnPulseToken,
                    onLaunchApp = onLaunchApp,
                    onLongPressApp = onLongPressApp
                )
            }
        }

        // App Drawer Overlay
        AnimatedVisibility(
            visible = state.isDrawerOpen,
            enter = slideInVertically(
                initialOffsetY = { it / 2 },
                animationSpec = ExpressiveMotion.spatialDefault()
            ) + fadeIn(),
            exit = slideOutVertically(
                targetOffsetY = { it / 2 },
                animationSpec = ExpressiveMotion.spatialDefault()
            ) + fadeOut()
        ) {
            AppDrawerSheet(
                apps = state.visibleApps,
                badgeCounts = state.badgeCounts,
                searchQuery = state.searchQuery,
                prefs = state.prefs,
                onSearchChange = onSearchChange,
                onLaunchApp = onLaunchApp,
                onLongPressApp = onLongPressApp,
                onOpenIconStudio = {
                    onCloseDrawer()
                    onOpenIconStudio()
                },
                onOpenSettings = {
                    onCloseDrawer()
                    onOpenSettings()
                },
                onDismiss = onCloseDrawer
            )
        }

        // Menu contestuale app
        state.selectedAppForMenu?.let { selected ->
            AppContextSheet(
                app = selected,
                prefs = state.prefs,
                isPinnedInArc = state.arcApps.any { it.packageName == selected.packageName },
                shortcuts = state.selectedAppShortcuts,
                onCustomizeIcon = { onOpenAppCustomizer(selected) },
                onTogglePin = { onTogglePinArc(selected) },
                onLaunchShortcut = onLaunchShortcut,
                onHideApp = { onHideApp(selected) },
                onAppInfo = { onAppInfo(selected) },
                onUninstall = { onUninstall(selected) },
                onDismiss = onCloseContextMenu
            )
        }

        // Editor personalizzazione singola icona
        state.customizingApp?.let { app ->
            val currentCustom = state.prefs.appCustomizations[app.packageName]
            IconCustomizeSheet(
                app = app,
                prefs = state.prefs,
                existing = currentCustom,
                onSave = { onSaveAppCustomization(app.packageName, it) },
                onPickGalleryImage = { uri -> onPickGalleryIcon(app.packageName, uri, currentCustom) },
                onDismiss = onCloseAppCustomizer
            )
        }

        // Icon & LED Studio
        if (state.isIconStudioOpen) {
            IconStudioSheet(
                prefs = state.prefs,
                previewApps = state.arcApps,
                iconPacks = state.iconPacks,
                onLedAnimationChange = onLedAnimationChange,
                onLedGlowChange = onLedGlowChange,
                onLedBorderWidthChange = onLedBorderWidthChange,
                onDarkGlassOpacityChange = onDarkGlassOpacityChange,
                onPerIconLedChange = onPerIconLedChange,
                onIconPackChange = onIconPackChange,
                onIconShapeChange = onIconShapeChange,
                onIconContainerChange = onIconContainerChange,
                onIconColorModeChange = onIconColorModeChange,
                onIconSizeChange = onIconSizeChange,
                onIconInnerScaleChange = onIconInnerScaleChange,
                onIconSaturationChange = onIconSaturationChange,
                onIconOpacityChange = onIconOpacityChange,
                onArcIconCountChange = onArcIconCountChange,
                onArcCurvatureChange = onArcCurvatureChange,
                onShowArcLabelsChange = onShowArcLabelsChange,
                onShowDrawerLabelsChange = onShowDrawerLabelsChange,
                onLabelSizeChange = onLabelSizeChange,
                onBadgeStyleChange = onBadgeStyleChange,
                onBadgeLedColorChange = onBadgeLedColorChange,
                onResetAll = onResetIconStyles,
                onDismiss = onCloseIconStudio
            )
        }

        // Impostazioni generali
        if (state.isSettingsOpen) {
            SettingsSheet(
                prefs = state.prefs,
                isDefaultLauncher = state.isDefaultLauncher,
                workModeController = workModeController,
                onRequestDefaultLauncher = onRequestDefaultLauncher,
                onOpenIconStudio = onOpenIconStudio,
                onHandednessChange = onHandednessChange,
                onDoubleTapLockChange = onDoubleTapLockChange,
                onAutoFocusSearchChange = onAutoFocusSearchChange,
                onAmoledWorkChange = onAmoledWorkChange,
                onPrivacyDimmerChange = onPrivacyDimmerChange,
                onPrivacyKeyChange = onPrivacyKeyChange,
                onAskDefaultOnStartChange = onAskDefaultOnStartChange,
                onDismiss = onCloseSettings
            )
        }

        // Dialog integrato scelta Launcher Predefinito all'apertura dell'app
        if (state.showDefaultLauncherPrompt) {
            DefaultLauncherPromptDialog(
                prefs = state.prefs,
                onRequestDefaultLauncher = onRequestDefaultLauncher,
                onLater = onDismissDefaultPrompt,
                onNeverAskAgain = onNeverAskDefaultPrompt
            )
        }
    }
}

@Composable
private fun LedCircleActionButton(
    icon: ImageVector,
    contentDescription: String,
    prefs: LauncherPrefs,
    tint: Color,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .size(44.dp)
            .ledGlassSurface(
                shape = CircleShape,
                glassOpacity = prefs.darkGlassOpacity,
                borderWidth = (prefs.ledBorderWidthDp * 0.8f).dp,
                glowIntensity = prefs.ledGlowIntensity * 0.8f,
                animationMode = prefs.ledAnimationMode
            )
            .clip(CircleShape)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = icon,
            contentDescription = contentDescription,
            tint = tint,
            modifier = Modifier.size(20.dp)
        )
    }
}

@Composable
private fun LedStatusChip(
    icon: ImageVector,
    text: String,
    prefs: LauncherPrefs,
    accent: Color,
    onClick: (() -> Unit)? = null
) {
    Box(
        modifier = Modifier
            .ledGlassSurface(
                shape = ExpressiveShapes.Pill,
                glassOpacity = prefs.darkGlassOpacity,
                borderWidth = 1.2.dp,
                glowIntensity = prefs.ledGlowIntensity * 0.7f,
                animationMode = prefs.ledAnimationMode,
                overrideAccentColor = accent
            )
            .clip(ExpressiveShapes.Pill)
            .let { m -> if (onClick != null) m.clickable(onClick = onClick) else m }
            .padding(horizontal = 12.dp, vertical = 6.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = accent,
                modifier = Modifier.size(14.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = text,
                style = MaterialTheme.typography.labelSmall,
                color = Color.White
            )
        }
    }
}
