package com.onearc.launcher.ui.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import com.onearc.launcher.data.LauncherPrefs
import com.onearc.launcher.ui.theme.ExpressiveShapes
import com.onearc.launcher.ui.theme.LocalLedPalette

/**
 * Dialog integrato all'apertura dell'app quando OneArc non e ancora il Launcher predefinito.
 * Con un solo tap apre la finestra nativa Android (RoleManager ROLE_HOME) direttamente sopra l'app.
 */
@Composable
fun DefaultLauncherPromptDialog(
    prefs: LauncherPrefs,
    onRequestDefaultLauncher: () -> Unit,
    onLater: () -> Unit,
    onNeverAskAgain: () -> Unit
) {
    val led = LocalLedPalette.current

    Dialog(onDismissRequest = onLater) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .ledGlassSurface(
                    shape = ExpressiveShapes.CardExpressive,
                    glassOpacity = 0.88f,
                    borderWidth = prefs.ledBorderWidthDp.dp,
                    glowIntensity = prefs.ledGlowIntensity,
                    animationMode = prefs.ledAnimationMode
                )
                .padding(24.dp)
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(58.dp)
                        .ledGlassSurface(
                            shape = CircleShape,
                            glassOpacity = 0.72f,
                            borderWidth = 1.6.dp,
                            glowIntensity = 1.0f,
                            animationMode = prefs.ledAnimationMode
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Home,
                        contentDescription = null,
                        tint = led.primary,
                        modifier = Modifier.size(30.dp)
                    )
                }

                Text(
                    text = "Imposta OneArc come Home",
                    style = MaterialTheme.typography.headlineMedium,
                    color = Color.White,
                    textAlign = TextAlign.Center
                )

                Text(
                    text = "Per usare OneArc con una mano, le animazioni delle icone e gli shortcut nativi, selezionalo come schermata Home predefinita del tuo Galaxy.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = Color.White.copy(alpha = 0.78f),
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(4.dp))

                Button(
                    onClick = onRequestDefaultLauncher,
                    shape = ExpressiveShapes.Pill,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = led.primary,
                        contentColor = Color(0xFF041018)
                    ),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "Imposta come predefinito",
                        style = MaterialTheme.typography.labelLarge
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    TextButton(onClick = onNeverAskAgain) {
                        Text(
                            text = "Non chiedere piu",
                            color = Color.White.copy(alpha = 0.55f)
                        )
                    }
                    TextButton(onClick = onLater) {
                        Text(
                            text = "Piu tardi",
                            color = led.secondary
                        )
                    }
                }
            }
        }
    }
}
