package com.onearc.launcher.ui.theme

import android.os.Build
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.onearc.launcher.system.LedPalette
import com.onearc.launcher.system.WallpaperLedEngine

val LocalLedPalette = compositionLocalOf { LedPalette() }

private val FallbackDarkColors = darkColorScheme(
    primary = Color(0xFF4CC9F0),
    onPrimary = Color(0xFF002433),
    primaryContainer = Color(0xFF003B52),
    onPrimaryContainer = Color(0xFFBDEEFF),
    secondary = Color(0xFF80FFDB),
    onSecondary = Color(0xFF002C21),
    secondaryContainer = Color(0xFF004736),
    onSecondaryContainer = Color(0xFFC2FFE9),
    tertiary = Color(0xFFC77DFF),
    surface = Color(0xFF090C12),
    surfaceContainer = Color(0xFF101520),
    surfaceContainerHigh = Color(0xFF171E2D),
    background = Color(0xFF000000)
)

private val ExpressiveTypography = Typography(
    displayLarge = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.ExtraBold,
        fontSize = 68.sp,
        lineHeight = 72.sp,
        letterSpacing = (-2.5).sp
    ),
    headlineMedium = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Bold,
        fontSize = 24.sp,
        lineHeight = 30.sp,
        letterSpacing = (-0.5).sp
    ),
    titleMedium = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.SemiBold,
        fontSize = 15.sp,
        lineHeight = 20.sp
    ),
    labelLarge = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Bold,
        fontSize = 14.sp,
        letterSpacing = 0.1.sp
    ),
    labelSmall = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Bold,
        fontSize = 11.sp,
        letterSpacing = 0.2.sp
    )
)

private val OneArcShapes = Shapes(
    small = RoundedCornerShape(16.dp),
    medium = RoundedCornerShape(24.dp),
    large = RoundedCornerShape(32.dp),
    extraLarge = RoundedCornerShape(40.dp)
)

/**
 * Tema scuro vetro + LED in Material 3 Expressive:
 * - Estrae colori dinamici dallo sfondo del Galaxy (Dynamic Color + WallpaperColors LED).
 * - Tutti i bordi LED ereditano automaticamente LocalLedPalette aggiornata live dallo sfondo.
 */
@Composable
fun OneArcTheme(
    isWorkMode: Boolean,
    amoledWorkSurface: Boolean,
    wallpaperLedPalette: LedPalette,
    content: @Composable () -> Unit
) {
    val context = LocalContext.current

    val baseScheme: ColorScheme = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        dynamicDarkColorScheme(context)
    } else {
        FallbackDarkColors
    }

    // Fonde la palette WallpaperColors con gli accenti Material You se necessario
    val activeLed = LedPalette(
        primary = wallpaperLedPalette.primary,
        secondary = wallpaperLedPalette.secondary,
        tertiary = wallpaperLedPalette.tertiary
    )

    val finalScheme = if (isWorkMode && amoledWorkSurface) {
        baseScheme.copy(
            background = Color(0xFF000000),
            surface = Color(0xFF05070B),
            surfaceContainer = Color(0xFF0C1017),
            surfaceContainerHigh = Color(0xFF141923)
        )
    } else {
        baseScheme.copy(
            surface = Color(0xFF090C12),
            surfaceContainer = Color(0xFF111622),
            surfaceContainerHigh = Color(0xFF182030)
        )
    }

    CompositionLocalProvider(LocalLedPalette provides activeLed) {
        MaterialTheme(
            colorScheme = finalScheme,
            typography = ExpressiveTypography,
            shapes = OneArcShapes,
            content = content
        )
    }
}
