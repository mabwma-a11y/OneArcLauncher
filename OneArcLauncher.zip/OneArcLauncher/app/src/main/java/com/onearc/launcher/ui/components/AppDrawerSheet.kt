package com.onearc.launcher.ui.components

import android.graphics.Rect
import android.view.HapticFeedbackConstants
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.ColorMatrix
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.boundsInRoot
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.onearc.launcher.data.AppEntry
import com.onearc.launcher.data.Handedness
import com.onearc.launcher.ui.theme.ExpressiveShapes
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

/**
 * App Drawer monomano:
 * - Barra di ricerca posizionata IN BASSO nella zona del pollice.
 * - Indice alfabetico laterale A-Z posizionabile a destra o sinistra.
 * - Mostra il badge contatore notifiche su ogni app.
 */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun AppDrawerSheet(
    apps: List<AppEntry>,
    badgeCounts: Map<String, Int>,
    searchQuery: String,
    handedness: Handedness,
    monochromeIcons: Boolean,
    autoFocusSearch: Boolean,
    onSearchChange: (String) -> Unit,
    onLaunchApp: (AppEntry, Rect?) -> Unit,
    onLongPressApp: (AppEntry) -> Unit,
    onOpenSettings: () -> Unit,
    onDismiss: () -> Unit
) {
    val view = LocalView.current
    val listState = rememberLazyListState()
    val scope = rememberCoroutineScope()
    val focusRequester = remember { FocusRequester() }
    val rowBounds = remember { mutableStateMapOf<String, Rect>() }

    val letters = remember(apps) {
        apps.map { it.sectionLetter }.distinct()
    }
    var activeBubbleLetter by remember { mutableStateOf<Char?>(null) }

    val colorFilter = remember(monochromeIcons) {
        if (monochromeIcons) ColorFilter.colorMatrix(ColorMatrix().apply { setToSaturation(0f) }) else null
    }

    LaunchedEffect(autoFocusSearch) {
        if (autoFocusSearch) {
            runCatching { focusRequester.requestFocus() }
        }
    }

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.surface.copy(alpha = 0.96f)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .navigationBarsPadding()
                .imePadding()
        ) {
            // Intestazione minimale
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(start = 24.dp, end = 12.dp, top = 44.dp, bottom = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "Tutte le app (${apps.size})",
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Row {
                    IconButton(onClick = onOpenSettings) {
                        Icon(
                            imageVector = Icons.Rounded.Settings,
                            contentDescription = "Impostazioni OneArc"
                        )
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(
                            imageVector = Icons.Rounded.Close,
                            contentDescription = "Chiudi drawer"
                        )
                    }
                }
            }

            // Lista app + Indice alfabetico laterale (lato pollice)
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
            ) {
                LazyColumn(
                    state = listState,
                    contentPadding = PaddingValues(
                        start = if (handedness == Handedness.LEFT) 44.dp else 18.dp,
                        end = if (handedness == Handedness.RIGHT) 44.dp else 18.dp,
                        top = 8.dp,
                        bottom = 16.dp
                    ),
                    verticalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(apps, key = { it.id }) { app ->
                        val count = badgeCounts[app.packageName] ?: 0
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(ExpressiveShapes.CardExpressive)
                                .onGloballyPositioned { coords ->
                                    val b = coords.boundsInRoot()
                                    val loc = IntArray(2)
                                    view.getLocationOnScreen(loc)
                                    rowBounds[app.packageName] = Rect(
                                        (b.left + loc[0]).roundToInt(),
                                        (b.top + loc[1]).roundToInt(),
                                        (b.right + loc[0]).roundToInt(),
                                        (b.bottom + loc[1]).roundToInt()
                                    )
                                }
                                .combinedClickable(
                                    onClick = {
                                        view.performHapticFeedback(HapticFeedbackConstants.CONTEXT_CLICK)
                                        onLaunchApp(app, rowBounds[app.packageName])
                                    },
                                    onLongClick = {
                                        view.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
                                        onLongPressApp(app)
                                    }
                                )
                                .padding(horizontal = 12.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(44.dp)
                                    .clip(ExpressiveShapes.IconSquircle)
                                    .background(MaterialTheme.colorScheme.surfaceContainerHigh),
                                contentAlignment = Alignment.Center
                            ) {
                                if (app.icon != null) {
                                    Image(
                                        bitmap = app.icon,
                                        contentDescription = app.label,
                                        colorFilter = colorFilter,
                                        modifier = Modifier.size(32.dp)
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.width(14.dp))

                            Text(
                                text = app.label,
                                style = MaterialTheme.typography.titleMedium,
                                color = MaterialTheme.colorScheme.onSurface,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.weight(1f)
                            )

                            NotificationCounterBadge(count = count)
                        }
                    }
                }

                // Scrubber alfabetico A-Z a portata di pollice
                if (letters.isNotEmpty() && searchQuery.isBlank()) {
                    Column(
                        modifier = Modifier
                            .align(if (handedness == Handedness.RIGHT) Alignment.CenterEnd else Alignment.CenterStart)
                            .fillMaxHeight(0.84f)
                            .width(34.dp)
                            .padding(horizontal = 4.dp)
                            .clip(ExpressiveShapes.Pill)
                            .background(MaterialTheme.colorScheme.surfaceContainerHigh.copy(alpha = 0.72f))
                            .pointerInput(letters, apps) {
                                detectVerticalDragGestures(
                                    onDragEnd = { activeBubbleLetter = null },
                                    onDragCancel = { activeBubbleLetter = null },
                                    onVerticalDrag = { change, _ ->
                                        change.consume()
                                        val idx = ((change.position.y / size.height) * letters.size)
                                            .toInt()
                                            .coerceIn(0, letters.lastIndex)
                                        val letter = letters[idx]
                                        if (letter != activeBubbleLetter) {
                                            activeBubbleLetter = letter
                                            view.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
                                            val targetIndex = apps.indexOfFirst { it.sectionLetter == letter }
                                            if (targetIndex >= 0) {
                                                scope.launch { listState.scrollToItem(targetIndex) }
                                            }
                                        }
                                    }
                                )
                            },
                        verticalArrangement = Arrangement.SpaceEvenly,
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        letters.forEach { ch ->
                            Text(
                                text = ch.toString(),
                                style = MaterialTheme.typography.labelSmall,
                                color = if (activeBubbleLetter == ch) {
                                    MaterialTheme.colorScheme.primary
                                } else {
                                    MaterialTheme.colorScheme.onSurfaceVariant
                                }
                            )
                        }
                    }
                }

                // Bolla Expressive centrale con lettera attiva durante lo scorrimento A-Z
                activeBubbleLetter?.let { ch ->
                    Surface(
                        modifier = Modifier
                            .align(Alignment.Center)
                            .size(84.dp),
                        shape = CircleShape,
                        color = MaterialTheme.colorScheme.primaryContainer,
                        tonalElevation = 8.dp
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Text(
                                text = ch.toString(),
                                style = MaterialTheme.typography.headlineMedium,
                                color = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                        }
                    }
                }
            }

            // Barra di ricerca Expressive IN BASSO (zona pollice)
            OutlinedTextField(
                value = searchQuery,
                onValueChange = onSearchChange,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 18.dp, vertical = 14.dp)
                    .focusRequester(focusRequester),
                placeholder = { Text("Cerca app con una mano...") },
                leadingIcon = { Icon(Icons.Rounded.Search, contentDescription = null) },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { onSearchChange("") }) {
                            Icon(Icons.Rounded.Close, contentDescription = "Pulisci ricerca")
                        }
                    }
                },
                singleLine = true,
                shape = ExpressiveShapes.Pill,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Go),
                keyboardActions = KeyboardActions(
                    onGo = {
                        apps.firstOrNull()?.let { firstApp ->
                            onLaunchApp(firstApp, rowBounds[firstApp.packageName])
                        }
                    }
                ),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = MaterialTheme.colorScheme.surfaceContainerHigh,
                    unfocusedContainerColor = MaterialTheme.colorScheme.surfaceContainer,
                    focusedBorderColor = MaterialTheme.colorScheme.primary,
                    unfocusedBorderColor = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f)
                )
            )
        }
    }
}
