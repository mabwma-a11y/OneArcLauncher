package com.onearc.launcher.ui.components

import android.graphics.Rect
import android.view.HapticFeedbackConstants
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Palette
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.boundsInRoot
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.onearc.launcher.data.AppEntry
import com.onearc.launcher.data.Handedness
import com.onearc.launcher.data.LauncherPrefs
import com.onearc.launcher.ui.theme.ExpressiveShapes
import com.onearc.launcher.ui.theme.LocalLedPalette
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun AppDrawerSheet(
    apps: List<AppEntry>,
    badgeCounts: Map<String, Int>,
    searchQuery: String,
    prefs: LauncherPrefs,
    onSearchChange: (String) -> Unit,
    onLaunchApp: (AppEntry, Rect?) -> Unit,
    onLongPressApp: (AppEntry) -> Unit,
    onOpenIconStudio: () -> Unit,
    onOpenSettings: () -> Unit,
    onDismiss: () -> Unit
) {
    val view = LocalView.current
    val led = LocalLedPalette.current
    val listState = rememberLazyListState()
    val scope = rememberCoroutineScope()
    val focusRequester = remember { FocusRequester() }
    val rowBounds = remember { mutableStateMapOf<String, Rect>() }

    val letters = remember(apps) { apps.map { it.sectionLetter }.distinct() }
    var activeBubbleLetter by remember { mutableStateOf<Char?>(null) }

    LaunchedEffect(prefs.autoFocusSearch) {
        if (prefs.autoFocusSearch) {
            runCatching { focusRequester.requestFocus() }
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF04060B).copy(alpha = 0.92f))
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .navigationBarsPadding()
                .imePadding()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(start = 22.dp, end = 10.dp, top = 44.dp, bottom = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "Tutte le app (${apps.size})",
                    style = MaterialTheme.typography.titleMedium,
                    color = led.primary
                )
                Row {
                    IconButton(onClick = onOpenIconStudio) {
                        Icon(
                            imageVector = Icons.Rounded.Palette,
                            contentDescription = "Icon & LED Studio",
                            tint = led.secondary
                        )
                    }
                    IconButton(onClick = onOpenSettings) {
                        Icon(
                            imageVector = Icons.Rounded.Settings,
                            contentDescription = "Impostazioni",
                            tint = Color.White
                        )
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(
                            imageVector = Icons.Rounded.Close,
                            contentDescription = "Chiudi",
                            tint = Color.White
                        )
                    }
                }
            }

            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
            ) {
                LazyColumn(
                    state = listState,
                    contentPadding = PaddingValues(
                        start = if (prefs.handedness == Handedness.LEFT) 46.dp else 16.dp,
                        end = if (prefs.handedness == Handedness.RIGHT) 46.dp else 16.dp,
                        top = 6.dp,
                        bottom = 14.dp
                    ),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(apps, key = { it.id }) { app ->
                        val count = badgeCounts[app.packageName] ?: 0
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(ExpressiveShapes.CardExpressive)
                                .background(Color.White.copy(alpha = 0.03f))
                                .onGloballyPositioned { coords ->
                                    val b = coords.boundsInRoot()
                                    val loc = IntArray(2)
                                    view.getLocationOnScreen(loc)
                                    rowBounds[app.packageName] = Rect(
                                        (b.left + loc[0]).roundToInt(),
                                        (b.top + loc[1]).roundToInt(),
                                        (b.right + loc[0]).roundToInt(),
                                        (b.bottom + loc[1]).roundToInt()
                                    )
                                }
                                .combinedClickable(
                                    onClick = {
                                        view.performHapticFeedback(HapticFeedbackConstants.CONTEXT_CLICK)
                                        onLaunchApp(app, rowBounds[app.packageName])
                                    },
                                    onLongClick = {
                                        view.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
                                        onLongPressApp(app)
                                    }
                                )
                                .padding(horizontal = 12.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            OneArcIconVisual(
                                label = app.label,
                                iconBitmap = app.icon,
                                customGlyphKey = app.customGlyphKey,
                                customLedColorArgb = app.customLedColorArgb,
                                prefs = prefs,
                                sizeOverride = (prefs.iconSizeDp * 0.84f).coerceIn(38f, 54f).dp
                            )

                            Spacer(modifier = Modifier.width(14.dp))

                            if (prefs.showDrawerLabels) {
                                Text(
                                    text = app.label,
                                    style = MaterialTheme.typography.titleMedium.copy(
                                        fontSize = (prefs.labelTextSizeSp + 4f).sp
                                    ),
                                    color = Color.White,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                    modifier = Modifier.weight(1f)
                                )
                            } else {
                                Spacer(modifier = Modifier.weight(1f))
                            }

                            NotificationCounterBadge(
                                count = count,
                                style = prefs.badgeStyle,
                                useLedColor = prefs.badgeUseLedColor
                            )
                        }
                    }
                }

                // Scrubber alfabetico A-Z con bordo LED
                if (letters.isNotEmpty() && searchQuery.isBlank()) {
                    Column(
                        modifier = Modifier
                            .align(if (prefs.handedness == Handedness.RIGHT) Alignment.CenterEnd else Alignment.CenterStart)
                            .padding(horizontal = 6.dp)
                            .fillMaxHeight(0.84f)
                            .width(34.dp)
                            .ledGlassSurface(
                                shape = ExpressiveShapes.Pill,
                                glassOpacity = prefs.darkGlassOpacity,
                                borderWidth = 1.2.dp,
                                glowIntensity = prefs.ledGlowIntensity * 0.7f,
                                animationMode = prefs.ledAnimationMode
                            )
                            .pointerInput(letters, apps) {
                                detectVerticalDragGestures(
                                    onDragEnd = { activeBubbleLetter = null },
                                    onDragCancel = { activeBubbleLetter = null },
                                    onVerticalDrag = { change, _ ->
                                        change.consume()
                                        val idx = ((change.position.y / size.height) * letters.size)
                                            .toInt()
                                            .coerceIn(0, letters.lastIndex)
                                        val letter = letters[idx]
                                        if (letter != activeBubbleLetter) {
                                            activeBubbleLetter = letter
                                            view.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
                                            val targetIndex = apps.indexOfFirst { it.sectionLetter == letter }
                                            if (targetIndex >= 0) {
                                                scope.launch { listState.scrollToItem(targetIndex) }
                                            }
                                        }
                                    }
                                )
                            },
                        verticalArrangement = Arrangement.SpaceEvenly,
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        letters.forEach { ch ->
                            Text(
                                text = ch.toString(),
                                style = MaterialTheme.typography.labelSmall,
                                color = if (activeBubbleLetter == ch) led.primary else Color.White.copy(alpha = 0.68f)
                            )
                        }
                    }
                }

                // Bolla centrale LED durante lo scorrimento alfabetico
                activeBubbleLetter?.let { ch ->
                    Box(
                        modifier = Modifier
                            .align(Alignment.Center)
                            .size(86.dp)
                            .ledGlassSurface(
                                shape = CircleShape,
                                glassOpacity = 0.85f,
                                borderWidth = 2.2.dp,
                                glowIntensity = 1.2f,
                                animationMode = prefs.ledAnimationMode
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = ch.toString(),
                            style = MaterialTheme.typography.headlineMedium,
                            color = led.primary
                        )
                    }
                }
            }

            // Barra ricerca trasparente scura con bordo LED in basso (zona pollice)
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 18.dp, vertical = 14.dp)
                    .ledGlassSurface(
                        shape = ExpressiveShapes.Pill,
                        glassOpacity = prefs.darkGlassOpacity,
                        borderWidth = prefs.ledBorderWidthDp.dp,
                        glowIntensity = prefs.ledGlowIntensity * 0.85f,
                        animationMode = prefs.ledAnimationMode
                    )
            ) {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = onSearchChange,
                    modifier = Modifier
                        .fillMaxWidth()
                        .focusRequester(focusRequester),
                    placeholder = { Text("Cerca app con una mano...", color = Color.White.copy(alpha = 0.55f)) },
                    leadingIcon = { Icon(Icons.Rounded.Search, contentDescription = null, tint = led.primary) },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = { onSearchChange("") }) {
                                Icon(Icons.Rounded.Close, contentDescription = "Pulisci", tint = Color.White)
                            }
                        }
                    },
                    singleLine = true,
                    shape = ExpressiveShapes.Pill,
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Go),
                    keyboardActions = KeyboardActions(
                        onGo = {
                            apps.firstOrNull()?.let { firstApp ->
                                onLaunchApp(firstApp, rowBounds[firstApp.packageName])
                            }
                        }
                    ),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = Color.Transparent,
                        unfocusedContainerColor = Color.Transparent,
                        focusedBorderColor = Color.Transparent,
                        unfocusedBorderColor = Color.Transparent,
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        cursorColor = led.primary
                    )
                )
            }
        }
    }
}
