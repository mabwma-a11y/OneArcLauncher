package com.onearc.launcher.ui.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.onearc.launcher.data.AppEntry
import com.onearc.launcher.data.BadgeStyle
import com.onearc.launcher.data.IconColorMode
import com.onearc.launcher.data.IconContainerStyle
import com.onearc.launcher.data.IconPackInfo
import com.onearc.launcher.data.IconShapeStyle
import com.onearc.launcher.data.LauncherPrefs
import com.onearc.launcher.data.LedAnimationMode
import com.onearc.launcher.ui.theme.ExpressiveShapes
import com.onearc.launcher.ui.theme.LocalLedPalette
import kotlin.math.roundToInt

/**
 * Icon & LED Studio:
 * Pannello completo con anteprima live della dock trasparente scura a LED e di tutte le
 * personalizzazioni di icone, forme, Icon Pack, colori, dimensioni, etichette, badge e arco.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun IconStudioSheet(
    prefs: LauncherPrefs,
    previewApps: List<AppEntry>,
    iconPacks: List<IconPackInfo>,
    onLedAnimationChange: (LedAnimationMode) -> Unit,
    onLedGlowChange: (Float) -> Unit,
    onLedBorderWidthChange: (Float) -> Unit,
    onDarkGlassOpacityChange: (Float) -> Unit,
    onPerIconLedChange: (Boolean) -> Unit,
    onIconPackChange: (String) -> Unit,
    onIconShapeChange: (IconShapeStyle) -> Unit,
    onIconContainerChange: (IconContainerStyle) -> Unit,
    onIconColorModeChange: (IconColorMode) -> Unit,
    onIconSizeChange: (Float) -> Unit,
    onIconInnerScaleChange: (Float) -> Unit,
    onIconSaturationChange: (Float) -> Unit,
    onIconOpacityChange: (Float) -> Unit,
    onArcIconCountChange: (Int) -> Unit,
    onArcCurvatureChange: (Float) -> Unit,
    onShowArcLabelsChange: (Boolean) -> Unit,
    onShowDrawerLabelsChange: (Boolean) -> Unit,
    onLabelSizeChange: (Float) -> Unit,
    onBadgeStyleChange: (BadgeStyle) -> Unit,
    onBadgeLedColorChange: (Boolean) -> Unit,
    onResetAll: () -> Unit,
    onDismiss: () -> Unit
) {
    val led = LocalLedPalette.current

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        shape = ExpressiveShapes.SheetTop,
        containerColor = Color(0xFF080B13)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 6.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Icon & LED Studio",
                    style = MaterialTheme.typography.headlineMedium,
                    color = Color.White
                )
                TextButton(onClick = onResetAll) {
                    Text("Reset", color = led.secondary)
                }
            }

            // ANTEPRIMA LIVE della Dock trasparente scura con bordo LED
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .ledGlassSurface(
                        shape = ExpressiveShapes.DockContainer,
                        glassOpacity = prefs.darkGlassOpacity,
                        borderWidth = prefs.ledBorderWidthDp.dp,
                        glowIntensity = prefs.ledGlowIntensity,
                        animationMode = prefs.ledAnimationMode
                    )
                    .padding(horizontal = 12.dp, vertical = 16.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    previewApps.take(4).forEachIndexed { i, app ->
                        Box(contentAlignment = Alignment.Center) {
                            OneArcIconVisual(
                                label = app.label,
                                iconBitmap = app.icon,
                                customGlyphKey = app.customGlyphKey,
                                customLedColorArgb = app.customLedColorArgb,
                                prefs = prefs
                            )
                            if (i == 0) {
                                NotificationCounterBadge(
                                    count = 3,
                                    style = prefs.badgeStyle,
                                    useLedColor = prefs.badgeUseLedColor,
                                    modifier = Modifier.align(Alignment.TopEnd)
                                )
                            }
                        }
                    }
                }
            }

            // ----------------------------------------------------------
            // SEZIONE 1: RIFINITURE LED & VETRO SCURO
            // ----------------------------------------------------------
            SectionTitle("Rifiniture LED (colori dello sfondo)", led.primary)

            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(LedAnimationMode.entries) { mode ->
                    FilterChip(
                        selected = prefs.ledAnimationMode == mode,
                        onClick = { onLedAnimationChange(mode) },
                        label = { Text(mode.displayName) }
                    )
                }
            }

            LabeledSlider(
                title = "Intensita Glow LED",
                valueText = "${(prefs.ledGlowIntensity * 100).roundToInt()}%",
                value = prefs.ledGlowIntensity,
                range = 0f..1.4f,
                accent = led.primary,
                onValueChange = onLedGlowChange
            )
            LabeledSlider(
                title = "Spessore bordo LED",
                valueText = String.format("%.1f dp", prefs.ledBorderWidthDp),
                value = prefs.ledBorderWidthDp,
                range = 0.8f..3.5f,
                accent = led.primary,
                onValueChange = onLedBorderWidthChange
            )
            LabeledSlider(
                title = "Opacita vetro scuro",
                valueText = "${(prefs.darkGlassOpacity * 100).roundToInt()}%",
                value = prefs.darkGlassOpacity,
                range = 0.25f..0.92f,
                accent = led.primary,
                onValueChange = onDarkGlassOpacityChange
            )
            StudioToggleRow(
                title = "Bordo LED su ogni icona",
                subtitle = "Illumina singolarmente ogni icona nella dock e nel drawer",
                checked = prefs.perIconLedEnabled,
                onCheckedChange = onPerIconLedChange
            )

            HorizontalDivider(color = Color.White.copy(alpha = 0.1f))

            // ----------------------------------------------------------
            // SEZIONE 2: ICON PACK DI TERZE PARTI
            // ----------------------------------------------------------
            SectionTitle("Icon Pack installati", led.primary)

            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                contentPadding = PaddingValues(vertical = 2.dp)
            ) {
                item {
                    FilterChip(
                        selected = prefs.selectedIconPackPackage.isBlank(),
                        onClick = { onIconPackChange("") },
                        label = { Text("Sistema Galaxy") }
                    )
                }
                items(iconPacks, key = { it.packageName }) { pack ->
                    FilterChip(
                        selected = prefs.selectedIconPackPackage == pack.packageName,
                        onClick = { onIconPackChange(pack.packageName) },
                        label = { Text(pack.label) }
                    )
                }
            }
            if (iconPacks.isEmpty()) {
                Text(
                    text = "Installa qualsiasi Icon Pack dal Play Store: comparira qui automaticamente.",
                    style = MaterialTheme.typography.bodySmall,
                    color = Color.White.copy(alpha = 0.6f)
                )
            }

            HorizontalDivider(color = Color.White.copy(alpha = 0.1f))

            // ----------------------------------------------------------
            // SEZIONE 3: FORMA, CONTENITORE, COLORE E DIMENSIONI ICONE
            // ----------------------------------------------------------
            SectionTitle("Forma delle icone", led.primary)
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(IconShapeStyle.entries) { shape ->
                    FilterChip(
                        selected = prefs.iconShape == shape,
                        onClick = { onIconShapeChange(shape) },
                        label = { Text(shape.displayName) }
                    )
                }
            }

            SectionTitle("Stile contenitore icona", led.primary)
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(IconContainerStyle.entries) { style ->
                    FilterChip(
                        selected = prefs.iconContainerStyle == style,
                        onClick = { onIconContainerChange(style) },
                        label = { Text(style.displayName) }
                    )
                }
            }

            SectionTitle("Stile colore icone", led.primary)
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(IconColorMode.entries) { mode ->
                    FilterChip(
                        selected = prefs.iconColorMode == mode,
                        onClick = { onIconColorModeChange(mode) },
                        label = { Text(mode.displayName) }
                    )
                }
            }

            LabeledSlider(
                title = "Dimensione icone",
                valueText = "${prefs.iconSizeDp.roundToInt()} dp",
                value = prefs.iconSizeDp,
                range = 40f..68f,
                accent = led.primary,
                onValueChange = onIconSizeChange
            )
            LabeledSlider(
                title = "Zoom disegno interno",
                valueText = "${(prefs.iconInnerScale * 100).roundToInt()}%",
                value = prefs.iconInnerScale,
                range = 0.50f..1.05f,
                accent = led.primary,
                onValueChange = onIconInnerScaleChange
            )
            LabeledSlider(
                title = "Saturazione icone",
                valueText = "${(prefs.iconSaturation * 100).roundToInt()}%",
                value = prefs.iconSaturation,
                range = 0f..1.5f,
                accent = led.primary,
                onValueChange = onIconSaturationChange
            )
            LabeledSlider(
                title = "Opacita icone",
                valueText = "${(prefs.iconOpacity * 100).roundToInt()}%",
                value = prefs.iconOpacity,
                range = 0.45f..1.0f,
                accent = led.primary,
                onValueChange = onIconOpacityChange
            )

            HorizontalDivider(color = Color.White.copy(alpha = 0.1f))

            // ----------------------------------------------------------
            // SEZIONE 4: GEOMETRIA ARCO, ETICHETTE & BADGE
            // ----------------------------------------------------------
            SectionTitle("Geometria Arco & Etichette", led.primary)

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(4, 5, 6, 7).forEach { count ->
                    FilterChip(
                        selected = prefs.arcIconCount == count,
                        onClick = { onArcIconCountChange(count) },
                        label = { Text("$count app") }
                    )
                }
            }

            LabeledSlider(
                title = "Curvatura Arco ergonomico",
                valueText = "${prefs.arcCurvatureDp.roundToInt()} dp",
                value = prefs.arcCurvatureDp,
                range = 0f..36f,
                accent = led.primary,
                onValueChange = onArcCurvatureChange
            )

            StudioToggleRow(
                title = "Etichette nell'Arco",
                subtitle = "Mostra i nomi sotto le icone nella Home",
                checked = prefs.showArcLabels,
                onCheckedChange = onShowArcLabelsChange
            )
            StudioToggleRow(
                title = "Etichette nel Drawer",
                subtitle = "Mostra i nomi nella lista completa delle app",
                checked = prefs.showDrawerLabels,
                onCheckedChange = onShowDrawerLabelsChange
            )
            LabeledSlider(
                title = "Dimensione testo etichette",
                valueText = "${prefs.labelTextSizeSp.roundToInt()} sp",
                value = prefs.labelTextSizeSp,
                range = 9f..15f,
                accent = led.primary,
                onValueChange = onLabelSizeChange
            )

            SectionTitle("Badge Contatore Notifiche", led.primary)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                BadgeStyle.entries.forEach { bs ->
                    FilterChip(
                        selected = prefs.badgeStyle == bs,
                        onClick = { onBadgeStyleChange(bs) },
                        label = { Text(bs.displayName) }
                    )
                }
            }
            StudioToggleRow(
                title = "Colore badge sincronizzato ai LED",
                subtitle = "Usa il colore dello sfondo invece del rosso classico",
                checked = prefs.badgeUseLedColor,
                onCheckedChange = onBadgeLedColorChange
            )

            Text(
                text = "Suggerimento: tieni premuta qualsiasi singola icona e scegli "Personalizza icona, nome e LED" per cambiarne l'immagine dalla Galleria, rinominarla o darle un LED dedicato.",
                style = MaterialTheme.typography.bodySmall,
                color = Color.White.copy(alpha = 0.6f)
            )

            Spacer(modifier = Modifier.height(22.dp))
        }
    }
}

@Composable
private fun SectionTitle(text: String, color: Color) {
    Text(
        text = text,
        style = MaterialTheme.typography.labelLarge,
        color = color
    )
}

@Composable
private fun LabeledSlider(
    title: String,
    valueText: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    accent: Color,
    onValueChange: (Float) -> Unit
) {
    Column(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(text = title, style = MaterialTheme.typography.bodyMedium, color = Color.White)
            Text(text = valueText, style = MaterialTheme.typography.labelLarge, color = accent)
        }
        Slider(
            value = value,
            onValueChange = onValueChange,
            valueRange = range,
            colors = SliderDefaults.colors(
                thumbColor = accent,
                activeTrackColor = accent
            )
        )
    }
}

@Composable
private fun StudioToggleRow(
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column(modifier = Modifier.weight(1f).padding(end = 12.dp)) {
            Text(text = title, style = MaterialTheme.typography.titleMedium, color = Color.White)
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = Color.White.copy(alpha = 0.65f)
            )
        }
        Switch(checked = checked, onCheckedChange = onCheckedChange)
    }
}
