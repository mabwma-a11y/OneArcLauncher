package com.onearc.launcher

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.runtime.getValue
import androidx.compose.ui.platform.LocalView
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.onearc.launcher.data.LauncherMode
import com.onearc.launcher.system.DefaultLauncherHelper
import com.onearc.launcher.ui.screens.OneArcHomeScreen
import com.onearc.launcher.ui.theme.OneArcTheme
import com.onearc.launcher.ui.viewmodel.LauncherViewModel

class MainActivity : ComponentActivity() {

    private val viewModel: LauncherViewModel by viewModels()

    // Selettore nativo Android (RoleManager ROLE_HOME) integrato direttamente nell'app
    private val requestDefaultLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) {
        viewModel.refreshSystemStatus()
    }

    private fun launchDefaultHomeChooser() {
        runCatching {
            val intent = DefaultLauncherHelper.createRequestDefaultIntent(this)
            requestDefaultLauncher.launch(intent)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
        )

        setContent {
            val state by viewModel.uiState.collectAsStateWithLifecycle()
            val rootView = LocalView.current

            OneArcTheme(
                isWorkMode = state.mode == LauncherMode.WORK,
                amoledWorkSurface = state.prefs.amoledWorkBackground,
                wallpaperLedPalette = state.ledPalette
            ) {
                OneArcHomeScreen(
                    state = state,
                    workModeController = viewModel.workModeController,
                    onRequestDefaultLauncher = ::launchDefaultHomeChooser,
                    onDismissDefaultPrompt = viewModel::dismissDefaultPromptForSession,
                    onNeverAskDefaultPrompt = viewModel::disableDefaultPromptForever,
                    onToggleWorkMode = viewModel::toggleWorkMode,
                    onLaunchApp = { app, bounds -> viewModel.launchApp(app, rootView, bounds) },
                    onOpenDrawer = viewModel::openDrawer,
                    onCloseDrawer = viewModel::closeDrawer,
                    onSearchChange = viewModel::updateSearchQuery,
                    onOpenSettings = viewModel::openSettings,
                    onCloseSettings = viewModel::closeSettings,
                    onOpenIconStudio = viewModel::openIconStudio,
                    onCloseIconStudio = viewModel::closeIconStudio,
                    onLongPressApp = viewModel::openAppContextMenu,
                    onCloseContextMenu = viewModel::closeAppContextMenu,
                    onOpenAppCustomizer = viewModel::openAppCustomizer,
                    onCloseAppCustomizer = viewModel::closeAppCustomizer,
                    onSaveAppCustomization = viewModel::saveAppCustomization,
                    onPickGalleryIcon = viewModel::pickGalleryIconForApp,
                    onTogglePinArc = viewModel::togglePinInCurrentArc,
                    onLaunchShortcut = viewModel::launchShortcut,
                    onHideApp = viewModel::toggleHideApp,
                    onAppInfo = viewModel::openAppInfo,
                    onUninstall = viewModel::requestUninstall,
                    onHandednessChange = viewModel::setHandedness,
                    onLedAnimationChange = viewModel::setLedAnimationMode,
                    onLedGlowChange = viewModel::setLedGlowIntensity,
                    onLedBorderWidthChange = viewModel::setLedBorderWidth,
                    onDarkGlassOpacityChange = viewModel::setDarkGlassOpacity,
                    onPerIconLedChange = viewModel::setPerIconLedEnabled,
                    onIconPackChange = viewModel::setIconPack,
                    onIconShapeChange = viewModel::setIconShape,
                    onIconContainerChange = viewModel::setIconContainerStyle,
                    onIconColorModeChange = viewModel::setIconColorMode,
                    onIconSizeChange = viewModel::setIconSize,
                    onIconInnerScaleChange = viewModel::setIconInnerScale,
                    onIconSaturationChange = viewModel::setIconSaturation,
                    onIconOpacityChange = viewModel::setIconOpacity,
                    onArcIconCountChange = viewModel::setArcIconCount,
                    onArcCurvatureChange = viewModel::setArcCurvature,
                    onShowArcLabelsChange = viewModel::setShowArcLabels,
                    onShowDrawerLabelsChange = viewModel::setShowDrawerLabels,
                    onLabelSizeChange = viewModel::setLabelTextSizeSp,
                    onBadgeStyleChange = viewModel::setBadgeStyle,
                    onBadgeLedColorChange = viewModel::setBadgeUseLedColor,
                    onResetIconStyles = viewModel::resetAllIconStyles,
                    onDoubleTapLockChange = viewModel::setDoubleTapToLock,
                    onAutoFocusSearchChange = viewModel::setAutoFocusSearch,
                    onAmoledWorkChange = viewModel::setAmoledWorkBackground,
                    onPrivacyDimmerChange = viewModel::setPrivacyFallbackDimmer,
                    onPrivacyKeyChange = viewModel::setPrivacySettingKey,
                    onAskDefaultOnStartChange = viewModel::setAskDefaultLauncherOnStart
                )
            }
        }
    }

    override fun onResume() {
        super.onResume()
        viewModel.notifyReturnedHome()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        viewModel.closeDrawer()
        viewModel.closeSettings()
        viewModel.closeIconStudio()
        viewModel.closeAppContextMenu()
        viewModel.closeAppCustomizer()
        viewModel.notifyReturnedHome()
    }
}
