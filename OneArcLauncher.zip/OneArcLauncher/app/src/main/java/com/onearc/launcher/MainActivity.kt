package com.onearc.launcher

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.runtime.getValue
import androidx.compose.ui.platform.LocalView
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.onearc.launcher.data.LauncherMode
import com.onearc.launcher.ui.screens.OneArcHomeScreen
import com.onearc.launcher.ui.theme.OneArcTheme
import com.onearc.launcher.ui.viewmodel.LauncherViewModel

class MainActivity : ComponentActivity() {

    private val viewModel: LauncherViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
        )

        setContent {
            val state by viewModel.uiState.collectAsStateWithLifecycle()
            val rootView = LocalView.current

            OneArcTheme(
                isWorkMode = state.mode == LauncherMode.WORK,
                amoledWorkSurface = state.prefs.amoledWorkBackground
            ) {
                OneArcHomeScreen(
                    state = state,
                    workModeController = viewModel.workModeController,
                    onToggleWorkMode = viewModel::toggleWorkMode,
                    onLaunchApp = { app, bounds ->
                        viewModel.launchApp(app, rootView, bounds)
                    },
                    onOpenDrawer = viewModel::openDrawer,
                    onCloseDrawer = viewModel::closeDrawer,
                    onSearchChange = viewModel::updateSearchQuery,
                    onOpenSettings = viewModel::openSettings,
                    onCloseSettings = viewModel::closeSettings,
                    onLongPressApp = viewModel::openAppContextMenu,
                    onCloseContextMenu = viewModel::closeAppContextMenu,
                    onTogglePinArc = viewModel::togglePinInCurrentArc,
                    onLaunchShortcut = viewModel::launchShortcut,
                    onHideApp = viewModel::toggleHideApp,
                    onAppInfo = viewModel::openAppInfo,
                    onUninstall = viewModel::requestUninstall,
                    onHandednessChange = viewModel::setHandedness,
                    onMonochromeChange = viewModel::setMonochromeIcons,
                    onDoubleTapLockChange = viewModel::setDoubleTapToLock,
                    onAutoFocusSearchChange = viewModel::setAutoFocusSearch,
                    onAmoledWorkChange = viewModel::setAmoledWorkBackground,
                    onPrivacyDimmerChange = viewModel::setPrivacyFallbackDimmer,
                    onPrivacyKeyChange = viewModel::setPrivacySettingKey
                )
            }
        }
    }

    override fun onResume() {
        super.onResume()
        viewModel.notifyReturnedHome()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        // Premendo il tasto/gesture Home torna pulito alla schermata principale
        viewModel.closeDrawer()
        viewModel.closeSettings()
        viewModel.closeAppContextMenu()
        viewModel.notifyReturnedHome()
    }
}
