package com.onearc.launcher.system

import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioManager
import android.os.Build
import android.provider.Settings
import androidx.core.content.ContextCompat

data class WorkModeActivationResult(
    val ringerChangedToVibrate: Boolean,
    val hardwarePrivacyToggled: Boolean,
    val routineBroadcastSent: Boolean,
    val statusMessage: String
)

class WorkModeController(private val context: Context) {

    private val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

    private var previousRingerMode: Int? = null

    fun isSamsungDevice(): Boolean = Build.MANUFACTURER.equals("samsung", ignoreCase = true)

    fun hasNotificationPolicyAccess(): Boolean = notificationManager.isNotificationPolicyAccessGranted

    fun hasWriteSecureSettings(): Boolean =
        ContextCompat.checkSelfPermission(
            context,
            android.Manifest.permission.WRITE_SECURE_SETTINGS
        ) == PackageManager.PERMISSION_GRANTED

    fun setWorkMode(
        enabled: Boolean,
        privacySettingKey: String
    ): WorkModeActivationResult {
        val ringerOk = applyRingerMode(enabled)
        val hwPrivacyOk = applyHardwarePrivacyDisplay(enabled, privacySettingKey)
        sendRoutineBroadcast(enabled)

        val message = when {
            enabled && hwPrivacyOk && ringerOk ->
                "Lavoro attivo: Vibrazione + Privacy Display hardware"
            enabled && ringerOk ->
                "Lavoro attivo: Vibrazione attiva (Privacy via Routine/Filtro)"
            enabled ->
                "Lavoro attivo: consenti accesso DND per la vibrazione"
            else ->
                "Modalita Normale ripristinata"
        }

        return WorkModeActivationResult(
            ringerChangedToVibrate = ringerOk,
            hardwarePrivacyToggled = hwPrivacyOk,
            routineBroadcastSent = true,
            statusMessage = message
        )
    }

    private fun applyRingerMode(workEnabled: Boolean): Boolean {
        return try {
            if (workEnabled) {
                if (previousRingerMode == null) {
                    previousRingerMode = audioManager.ringerMode
                }
                audioManager.ringerMode = AudioManager.RINGER_MODE_VIBRATE
            } else {
                val target = previousRingerMode ?: AudioManager.RINGER_MODE_NORMAL
                previousRingerMode = null
                audioManager.ringerMode = target
            }
            true
        } catch (_: SecurityException) {
            false
        }
    }

    private fun applyHardwarePrivacyDisplay(enabled: Boolean, customKey: String): Boolean {
        if (!isSamsungDevice() || !hasWriteSecureSettings()) return false
        val value = if (enabled) 1 else 0
        val keysToTry = listOf(
            customKey,
            "privacy_display_mode",
            "sem_privacy_display_enabled",
            "display_privacy_mode"
        ).distinct()

        for (key in keysToTry) {
            if (Settings.Secure.getString(context.contentResolver, key) != null) {
                val ok = runCatching {
                    Settings.Secure.putInt(context.contentResolver, key, value)
                }.getOrDefault(false)
                if (ok) return true
            }
            if (Settings.System.getString(context.contentResolver, key) != null) {
                val ok = runCatching {
                    Settings.System.putInt(context.contentResolver, key, value)
                }.getOrDefault(false)
                if (ok) return true
            }
        }
        return false
    }

    private fun sendRoutineBroadcast(workEnabled: Boolean) {
        val intent = Intent(ACTION_WORK_MODE_CHANGED).apply {
            putExtra(EXTRA_WORK_ENABLED, workEnabled)
        }
        context.sendBroadcast(intent)
    }

    companion object {
        const val ACTION_WORK_MODE_CHANGED = "com.onearc.launcher.ACTION_WORK_MODE_CHANGED"
        const val EXTRA_WORK_ENABLED = "work_enabled"
    }
}
