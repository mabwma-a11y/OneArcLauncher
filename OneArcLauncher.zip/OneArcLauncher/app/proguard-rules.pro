# Regole ProGuard per OneArc Launcher
-keep class com.onearc.launcher.service.** { *; }
-keep class com.onearc.launcher.system.** { *; }
