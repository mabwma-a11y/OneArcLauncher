# OneArc Launcher (Android Kotlin + Jetpack Compose)

Launcher minimale, interattivo e progettato per l'uso con una sola mano sui dispositivi Samsung Galaxy.

## Funzionalita incluse

- **Material 3 Expressive + Dynamic Color**: Palette estratta automaticamente dallo sfondo del Galaxy (Material You), forme arrotondate Expressive e animazioni con fisica a molla (`ExpressiveMotion`).
- **Ergonomia 60/40 monomano**: Area superiore puramente informativa (orologio, data, stato Lavoro e conteggio notifiche). Tutta l'interazione vive nella zona del pollice (Destrimano o Mancino).
- **Arco Interattivo (ArcDock)**: 5 app disposte ad arco con supporto al trascinamento continuo col pollice (*scrubbing*), feedback aptico fine e menu contestuale con App Shortcuts nativi.
- **Animazioni stile Samsung Home**: Apertura ancorata alle coordinate reali dell'icona (`ActivityOptions.makeClipRevealAnimation` + `sourceBounds` di `LauncherApps`) e rimbalzo elastico dell'icona al ritorno in Home.
- **Modalita Normale / Lavoro**:
  - **Normale**: Sfondo del Galaxy visibile, colori dinamici pieni, profilo audio standard.
  - **Lavoro**: Passa la suoneria in **Vibrazione** (ripristinandola automaticamente all'uscita), applica interfaccia AMOLED scura e attiva il **Privacy Display** sui Galaxy compatibili (via `WRITE_SECURE_SETTINGS` o broadcast per **Samsung Modes & Routines**).
- **Solo Contatore Notifiche (Badge)**: `BadgeNotificationListenerService` non sostituisce la tua app di gestione notifiche ma espone esclusivamente i contatori numerici sulle icone.
- **Funzioni moderne**: App Drawer con ricerca in basso e scrubber alfabetico A-Z, icone monocromatiche, app nascoste, swipe giu per tendina notifiche, doppio tap per bloccare lo schermo.

## Compilazione rapida

1. **Android Studio**: Apri la cartella `OneArcLauncher`, attendi il sync Gradle e premi **Run**.
2. **GitHub Actions**: Carica la cartella su un repository GitHub; il workflow `.github/workflows/android-build.yml` compila automaticamente `app-debug.apk` negli Artifacts.

## Configurazione Privacy Display su Galaxy (es. hardware Privacy Display)

Poiche Samsung non espone ancora un'API SDK pubblica per il toggle hardware del Privacy Display alle app di terze parti, OneArc supporta due strategie pulite (senza root):

1. **Samsung Modes & Routines / Tasker (Zero ADB)**:
   - OneArc invia il broadcast `com.onearc.launcher.ACTION_WORK_MODE_CHANGED` con extra booleano `work_enabled` (`true`/`false`).
   - Puoi collegare una Routine per attivare/disattivare il Privacy Display nativo in automatico.
2. **Toggle diretto via ADB / Shizuku**:
   ```bash
   adb shell pm grant com.onearc.launcher android.permission.WRITE_SECURE_SETTINGS
   ```
   Una volta concesso, puoi anche personalizzare il nome esatto della chiave firmware Samsung direttamente nelle Impostazioni di OneArc.
