# OneArc Launcher — LED Glass Edition (Android Kotlin + Jetpack Compose)

Launcher monomano minimale per Samsung Galaxy con rifiniture a LED reattive allo sfondo, dock trasparente scura, selettore Launcher predefinito integrato all'apertura e personalizzazione completa delle icone.

## Novita principali (v1.1.0-led)

- **Grafica Vetro Scuro + Bordi LED dinamici**: Dock ad arco, pulsanti, barra ricerca, scrubber A-Z e icone con sfondo scuro traslucido e filamento LED con alone luminoso sincronizzato in tempo reale ai colori dello sfondo Galaxy (`WallpaperManager.getWallpaperColors` + Material 3 Dynamic Color).
- **Scelta Launcher Predefinito integrata all'apertura**: Se OneArc non e ancora il launcher di sistema, mostra un dialog LED all'avvio che apre direttamente il selettore nativo Android (`RoleManager.ROLE_HOME`) con un tap.
- **Icon & LED Studio (Personalizzazione totale icone)**:
  - **Icon Pack di terze parti** (rileva automaticamente gli Icon Pack dal Play Store leggendo `appfilter.xml`).
  - **8 Forme icone** (Squircle, Cerchio, Arrotondato, Goccia, Esagono, Ottagono, Diamante, Libera).
  - **4 Stili contenitore** (Vetro + LED, Solo Vetro, Solo Bordo LED, Nessuno) e toggle LED per singola icona.
  - **4 Modalita colore** (Originale, Monocromatico, Tinta LED sfondo, Neon Duo-Tone) + slider Saturazione, Opacita, Dimensione e Zoom interno.
  - **Personalizzazione per singola app** (pressione prolungata -> *Personalizza icona, nome e LED*): rinomina app, carica un'immagine dalla Galleria, scegli tra 22 glifi minimali LED integrati o imposta un colore LED dedicato.
  - **Geometria Arco & Badge**: da 4 a 7 icone nell'arco, curvatura regolabile, etichette Home/Drawer, badge numerico o puntino LED sincronizzato ai colori dello sfondo.
- **Modalita Normale / Lavoro**: Vibrazione automatica + supporto Galaxy Privacy Display + nero AMOLED.
